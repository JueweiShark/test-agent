package xosc

import (
    "encoding/xml"
)

type OpenSCENARIO struct {
    XMLName               xml.Name              `xml:"OpenSCENARIO"`
    FileHeader            FileHeader            `xml:"FileHeader"`
    ParameterDeclarations ParameterDeclarations `xml:"ParameterDeclarations"`
    CatalogLocations      CatalogLocations      `xml:"CatalogLocations"`
    RoadNetwork           RoadNetwork           `xml:"RoadNetwork"`
    Entities              Entities              `xml:"Entities"`
    Storyboard            Storyboard            `xml:"Storyboard"`
}

type FileHeader struct {
    RevMajor    string `xml:"revMajor,attr"`
    RevMinor    string `xml:"revMinor,attr"`
    Date        string `xml:"date,attr"`
    Description string `xml:"description,attr"`
    Author      string `xml:"author,attr"`
}

type ParameterDeclarations struct {
    ParameterDeclarations []ParameterDeclaration `xml:"ParameterDeclaration"`
}

type ParameterDeclaration struct {
    Name          string `xml:"name,attr"`
    ParameterType string `xml:"parameterType,attr"`
    Value         string `xml:"value,attr"`
}

type CatalogLocations struct{}

type RoadNetwork struct {
    LogicFile      LogicFile      `xml:"LogicFile"`
    SceneGraphFile SceneGraphFile `xml:"SceneGraphFile"`
}

type LogicFile struct {
    Filepath string `xml:"filepath,attr"`
}

type SceneGraphFile struct {
    Filepath string `xml:"filepath,attr"`
}

type Entities struct {
    ScenarioObjects []ScenarioObject `xml:"ScenarioObject"`
}

type ScenarioObject struct {
    Name    string  `xml:"name,attr"`
    Vehicle Vehicle `xml:"Vehicle"`
}

type Vehicle struct {
    Name            string      `xml:"name,attr"`
    VehicleCategory string      `xml:"vehicleCategory,attr"`
    BoundingBox     BoundingBox `xml:"BoundingBox"`
    Performance     Performance `xml:"Performance"`
    Axles           Axles       `xml:"Axles"`
    Properties      Properties  `xml:"Properties"`
}

type BoundingBox struct {
    Center     Center     `xml:"Center"`
    Dimensions Dimensions `xml:"Dimensions"`
}

type Center struct {
    X float64 `xml:"x,attr"`
    Y float64 `xml:"y,attr"`
    Z float64 `xml:"z,attr"`
}

type Dimensions struct {
    Width  float64 `xml:"width,attr"`
    Length float64 `xml:"length,attr"`
    Height float64 `xml:"height,attr"`
}

type Performance struct {
    MaxSpeed        float64 `xml:"maxSpeed,attr"`
    MaxAcceleration float64 `xml:"maxAcceleration,attr"`
    MaxDeceleration float64 `xml:"maxDeceleration,attr"`
}

type Axles struct {
    FrontAxle FrontAxle `xml:"FrontAxle"`
    RearAxle  RearAxle  `xml:"RearAxle"`
}

type FrontAxle struct {
    MaxSteering   float64 `xml:"maxSteering,attr"`
    WheelDiameter float64 `xml:"wheelDiameter,attr"`
    TrackWidth    float64 `xml:"trackWidth,attr"`
    PositionX     float64 `xml:"positionX,attr"`
    PositionZ     float64 `xml:"positionZ,attr"`
}

type RearAxle struct {
    MaxSteering   float64 `xml:"maxSteering,attr"`
    WheelDiameter float64 `xml:"wheelDiameter,attr"`
    TrackWidth    float64 `xml:"trackWidth,attr"`
    PositionX     float64 `xml:"positionX,attr"`
    PositionZ     float64 `xml:"positionZ,attr"`
}

type Properties struct {
    Properties []Property `xml:"Property"`
}

type Property struct {
    Name  string `xml:"name,attr"`
    Value string `xml:"value,attr"`
}

type Storyboard struct {
    Init        Init        `xml:"Init"`
    Story       Story       `xml:"Story"`
    StopTrigger StopTrigger `xml:"StopTrigger"`
}

type Init struct {
    Actions Actions `xml:"Actions"`
}

type Actions struct {
    GlobalAction   GlobalAction    `xml:"GlobalAction"`
    PrivateActions []PrivateAction `xml:"Private"`
}

type GlobalAction struct {
    EnvironmentAction EnvironmentAction `xml:"EnvironmentAction"`
}

type EnvironmentAction struct {
    Environment Environment `xml:"Environment"`
}

type Environment struct {
    Name          string        `xml:"name,attr"`
    TimeOfDay     TimeOfDay     `xml:"TimeOfDay"`
    Weather       Weather       `xml:"Weather"`
    RoadCondition RoadCondition `xml:"RoadCondition"`
}

type TimeOfDay struct {
    Animation bool   `xml:"animation,attr"`
    DateTime  string `xml:"dateTime,attr"`
}

type Weather struct {
    CloudState    string        `xml:"cloudState,attr"`
    Sun           Sun           `xml:"Sun"`
    Fog           Fog           `xml:"Fog"`
    Precipitation Precipitation `xml:"Precipitation"`
}

type Sun struct {
    Intensity float64 `xml:"intensity,attr"`
    Azimuth   float64 `xml:"azimuth,attr"`
    Elevation float64 `xml:"elevation,attr"`
}

type Fog struct {
    VisualRange float64 `xml:"visualRange,attr"`
}

type Precipitation struct {
    PrecipitationType string  `xml:"precipitationType,attr"`
    Intensity         float64 `xml:"intensity,attr"`
}

type RoadCondition struct {
    FrictionScaleFactor float64 `xml:"frictionScaleFactor,attr"`
}

type PrivateAction struct {
    EntityRef          string              `xml:"entityRef,attr,omitempty"`
    ControllerAction   *ControllerAction   `xml:"ControllerAction,omitempty"`
    LongitudinalAction *LongitudinalAction `xml:"LongitudinalAction,omitempty"`
    TeleportAction     *TeleportAction     `xml:"TeleportAction,omitempty"`
}

type ControllerAction struct {
    AssignControllerAction        AssignControllerAction        `xml:"AssignControllerAction"`
    OverrideControllerValueAction OverrideControllerValueAction `xml:"OverrideControllerValueAction"`
}

type AssignControllerAction struct {
    Controller Controller `xml:"Controller"`
}

type Controller struct {
    Name       string     `xml:"name,attr"`
    Properties Properties `xml:"Properties"`
}

type OverrideControllerValueAction struct {
    Throttle      ValueAction `xml:"Throttle"`
    Brake         ValueAction `xml:"Brake"`
    Clutch        ValueAction `xml:"Clutch"`
    ParkingBrake  ValueAction `xml:"ParkingBrake"`
    SteeringWheel ValueAction `xml:"SteeringWheel"`
    Gear          Gear        `xml:"Gear"`
}

type ValueAction struct {
    Value  float64 `xml:"value,attr"`
    Active bool    `xml:"active,attr"`
}

type Gear struct {
    Number int  `xml:"number,attr"`
    Active bool `xml:"active,attr"`
}

type LongitudinalAction struct {
    SpeedAction SpeedAction `xml:"SpeedAction"`
}

type SpeedAction struct {
    SpeedActionDynamics SpeedActionDynamics `xml:"SpeedActionDynamics"`
    SpeedActionTarget   SpeedActionTarget   `xml:"SpeedActionTarget"`
}

type SpeedActionDynamics struct {
    DynamicsShape     string  `xml:"dynamicsShape,attr"`
    Value             float64 `xml:"value,attr"`
    DynamicsDimension string  `xml:"dynamicsDimension,attr"`
}

type SpeedActionTarget struct {
    AbsoluteTargetSpeed AbsoluteTargetSpeed `xml:"AbsoluteTargetSpeed"`
}

type AbsoluteTargetSpeed struct {
    Value float64 `xml:"value,attr"`
}

type TeleportAction struct {
    Position Position `xml:"Position"`
}

type Position struct {
    WorldPosition WorldPosition `xml:"WorldPosition"`
}

type WorldPosition struct {
    X float64 `xml:"x,attr"`
    Y float64 `xml:"y,attr"`
    Z float64 `xml:"z,attr"`
    H float64 `xml:"h,attr"`
    P float64 `xml:"p,attr"`
    R float64 `xml:"r,attr"`
}

type Story struct {
    Name string `xml:"name,attr"`
    Act  Act    `xml:"Act"`
}

type Act struct {
    Name           string          `xml:"name,attr"`
    ManeuverGroups []ManeuverGroup `xml:"ManeuverGroup"`
    StartTrigger   TriggerGroup    `xml:"StartTrigger"`
    StopTrigger    TriggerGroup    `xml:"StopTrigger"`
}

type ManeuverGroup struct {
    MaximumExecutionCount int        `xml:"maximumExecutionCount,attr"`
    Name                  string     `xml:"name,attr"`
    Actors                Actors     `xml:"Actors"`
    Maneuvers             []Maneuver `xml:"Maneuver"`
}

type Actors struct {
    SelectTriggeringEntities bool        `xml:"selectTriggeringEntities,attr"`
    EntityRefs               []EntityRef `xml:"EntityRef"`
}

type EntityRef struct {
    EntityRef string `xml:"entityRef,attr"`
}

type Maneuver struct {
    Name   string  `xml:"name,attr"`
    Events []Event `xml:"Event"`
}

type Event struct {
    Name         string       `xml:"name,attr"`
    Priority     string       `xml:"priority,attr"`
    Action       Action       `xml:"Action"`
    StartTrigger TriggerGroup `xml:"StartTrigger"`
}

type Action struct {
    Name          string        `xml:"name,attr"`
    PrivateAction PrivateAction `xml:"PrivateAction"`
}

type TriggerGroup struct {
    Conditions []Condition `xml:"ConditionGroup>Condition"`
}

type Condition struct {
    Name              string             `xml:"name,attr"`
    Delay             float64            `xml:"delay,attr"`
    ConditionEdge     string             `xml:"conditionEdge,attr"`
    ByValueCondition  *ByValueCondition  `xml:"ByValueCondition,omitempty"`
    ByEntityCondition *ByEntityCondition `xml:"ByEntityCondition,omitempty"`
}

type ByValueCondition struct {
    SimulationTimeCondition         SimulationTimeCondition          `xml:"SimulationTimeCondition"`
    StoryboardElementStateCondition *StoryboardElementStateCondition `xml:"StoryboardElementStateCondition,omitempty"`
}

type SimulationTimeCondition struct {
    Value float64 `xml:"value,attr"`
    Rule  string  `xml:"rule,attr"`
}

type StoryboardElementStateCondition struct {
    StoryboardElementRef  string `xml:"storyboardElementRef,attr"`
    State                 string `xml:"state,attr"`
    StoryboardElementType string `xml:"storyboardElementType,attr"`
}

type ByEntityCondition struct {
    TriggeringEntities TriggeringEntities `xml:"TriggeringEntities"`
    EntityCondition    EntityCondition    `xml:"EntityCondition"`
}

type TriggeringEntities struct {
    TriggeringEntitiesRule string      `xml:"triggeringEntitiesRule,attr"`
    EntityRefs             []EntityRef `xml:"EntityRef"`
}

type EntityCondition struct {
    RelativeDistanceCondition RelativeDistanceCondition `xml:"RelativeDistanceCondition"`
}

type RelativeDistanceCondition struct {
    EntityRef            string  `xml:"entityRef,attr"`
    RelativeDistanceType string  `xml:"relativeDistanceType,attr"`
    Value                float64 `xml:"value,attr"`
    FreeSpace            bool    `xml:"freespace,attr"`
    Rule                 string  `xml:"rule,attr"`
}

type StopTrigger struct {
    Conditions []Condition `xml:"ConditionGroup>Condition"`
}

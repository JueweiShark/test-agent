package xosc

import (
    "errors"
    "os"
    "path/filepath"
    "strings"
    "sync"

    "github.com/go-kratos/kratos/v2/log"

    "wuwen.com/wwsi/internal/biz/xosc/map"
)

type CAABB struct{}

func (aabb *CAABB) Expand(CVector3) {}

type CPoint3D struct {
    X, Y, Z float64
}

type CVector3 struct {
    X, Y, Z float64
}
type CMapFile struct {
    m_version        string
    m_roads          []*RoadData
    m_mapObjects     []*CMapObject
    m_roadJunctionId map[int]map[int]int
    m_lights         []*CSignLight
}
type MAP_DATA_TYPE int

var kHadmapTypeDict = map[string]MAP_DATA_TYPE{
    ".xodr": 1,
    // other extensions and their corresponding types
}

func (cmf *CMapFile) ParseMapV2(strMapFile string, bReadHadmapConfig bool) int {
    if strMapFile == "" {
        log.Error("map file name is null")
        return -1
    }

    pathMapFile := filepath.FromSlash(strMapFile)
    if _, err := os.Stat(pathMapFile); os.IsNotExist(err) {
        log.Error("map file %s not exist!", strMapFile)
        return -1
    }

    strExt := strings.ToLower(filepath.Ext(pathMapFile))
    nMapType, exists := kHadmapTypeDict[strExt]
    if !exists {
        log.Error("unknown map type: %s!", strMapFile)
        return -1
    }

    log.Debug("hadmap::hadmapConnect for file: %s, type: %d", strMapFile, nMapType)
    var pMapHandler HadMapHandler
    nRet := 0

    aabb := CAABB{}

    //nRet = checkEmptyFile()
    //if nRet != 0 {
    //    return nRet
    //}

    defer func() {
        if r := recover(); r != nil {
            log.Error("parse hadmap %s error!", strMapFile)
        }
    }()

    err := hadmapConnect(strMapFile, nMapType, pMapHandler, false)
    if err != nil {
        log.Error("hadmap file %s open failed!", strMapFile)
        return -1
    }

    headerPtr := getHeader(pMapHandler)
    if headerPtr != nil {
        switch headerPtr.Vendor {
        case "tadsim":
            cmf.m_version = "tadsim v1.0"
        case "tadsim v2.0":
            cmf.m_version = "tadsim v2.0"
        default:
            cmf.m_version = "three party"
        }
    }

    log.Debug("hadmap::getRoads")
    roads, err := pMapHandler.GetSearchInter().GetRoads()
    if err != nil {
        log.Error("hadmap::getRoads failed!")
        return -1
    }
    log.Debug("parse road data")
    for _, iter := range roads {
        cmf.m_roads = append(cmf.m_roads, iter)
        if iter == nil {
            continue
        }
        //aabb.Expand(rd->AabbLl().Min());
        //aabb.Expand(rd->AabbLl().Max());
    }

    log.Debug("hadmap::getObjects")
    objs, nRet := getObjects(pMapHandler)
    if nRet != 0 {
        log.Error("hadmap::getObjects failed!")
        // return -1;
    }

    log.Debug("parse object data")
    ClearMapObjects()
    // parse objects here

    // handle other logic like getting junctions and lanelinks

    if bReadHadmapConfig {
        // handle reading hadmap config here
    }

    log.Info("convert map points to local coordinate.")

    if bReadHadmapConfig {
        filename := filepath.Base(strMapFile)
        hadmapAttr := CEngineConfigInstance().HadmapAttr(filename)
        if hadmapAttr == nil {
            log.Error("hadmap file not exist in config file!")
            return -1
        }
        refPoint := CPoint3D{X: hadmapAttr.RefLon, Y: hadmapAttr.RefLat, Z: hadmapAttr.RefAlt}
        CoordConvertV2(aabb, refPoint)
    } else {
        CalculateBox(aabb)
    }

    log.Debug("parse map data finished!")

    return 0
}

func getObjects(handler HadMapHandler) (interface{}, interface{}) {

}

func getRoads(handler HadMapHandler, b *bool) (interface{}, interface{}) {
    handler.GetSearchInter().GetRoads()

}
func hadmapConnect(fileInfo string, dataType MAP_DATA_TYPE, ppHandle HadMapHandler, doubleRoad bool) error {
    if ppHandle != nil {
        ppHandle = nil
    }
    ppHandle = newHadMapHandler(dataType, GetSearchFactoryInstance().getSearchInterface(dataType, fileInfo, doubleRoad))
    if ppHandle.GetSearchInter().connSuccess() {
        return errors.New("hadmap connect success")
    } else {
        ppHandle = nil
        return errors.New("hadmap connect fail")
    }
}
func getHeader(handler HadMapHandler) *TxOdHeader {
    return handler.GetSearchInter().GetHeader()
}

type MapData struct {
    roadRelObjects map[uint64]map[uint64]struct{}
    objectDatas    map[uint64]*ObjData
    objdataMutex   sync.Mutex
}
type txLaneId struct {
    RoadId    uint64
    SectionId uint64
    LaneId    uint64
}

type tx_object_t struct {
    Pkid       uint64
    Type       uint64
    Subtype    uint64
    Length     float64
    Width      float64
    Height     float64
    Roll       float64
    Pitch      float64
    Yaw        float64
    X          float64
    Y          float64
    Z          float64
    S          float64
    T          float64
    Name       string
    Attribute  string
    RawType    string
    RawSubType string
}
type ObjData struct {
}

// 锁定对象数据互斥锁，确保并发安全
func (md *MapData) getObjects(relIds []txLaneId, objects []*ObjData) bool {
    // 清空 objects 切片
    objects = (objects)[:0]

    md.objdataMutex.Lock()
    defer md.objdataMutex.Unlock()

    objIds := make(map[uint64]struct{})
    for _, laneId := range relIds {
        if curObjIds, found := md.roadRelObjects[laneId.RoadId]; found {
            for id := range curObjIds {
                if objData, exists := md.objectDatas[id]; exists {
                    var objRelIds []txLaneId
                    // 假设 getReliedLaneIds 是一个方法，获取相关联的车道 ID
                    objRelIds = objData.r // 在实际实现中替换此行
                    for _, objRelId := range objRelIds {
                        if laneIdMatching(laneId, objRelId) {
                            if _, exists := objIds[id]; !exists {
                                objIds[id] = struct{}{}
                                *objects = append(*objects, objData)
                            }
                            break
                        }
                    }
                }
            }
        }
    }

    return len(*objects) > 0
}

// 假设 laneIdMatching 是一个比较两个 txLaneId 的函数
func laneIdMatching(laneId, objRelId txLaneId) bool {
    return laneId.RoadId == objRelId.RoadId // 实际实现中替换此行
}

// 假设 txObject 有一个方法 getReliedLaneIds
func (obj *hadmap.txObject) getReliedLaneIds() []txLaneId {
    // 返回关联的车道 ID 列表
    return []txLaneId{{RoadId: 1}} // 示例返回值，在实际实现中替换此行
}

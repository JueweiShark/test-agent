package xosc

// get SIGN_WARNING Type

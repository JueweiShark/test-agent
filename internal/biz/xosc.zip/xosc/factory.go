package xosc

type Factory struct {
}

func (f Factory) getSearchInterface(dataType MAP_DATA_TYPE, info string, road bool) Search {
    panic("implement me")
}

func GetSearchFactoryInstance() Factory {

    return Factory{}
}

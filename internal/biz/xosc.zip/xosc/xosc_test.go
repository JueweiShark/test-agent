package xosc

import (
    "encoding/json"
    "encoding/xml"
    "fmt"
    "os"
    "testing"
)

func TestParseXml(t *testing.T) {
    file, err := os.Open("jiasu.xosc")
    if err != nil {
        fmt.Printf("Error opening file: %v\n", err)
        return
    }
    defer file.Close()

    // 创建 OpenSCENARIO 结构体实例
    var scenario OpenSCENARIO

    // 解码 XML 文件到结构体
    if err := xml.NewDecoder(file).Decode(&scenario); err != nil {
        fmt.Printf("Error decoding XML: %v\n", err)
        return
    }
    marshal, _ := json.Marshal(scenario)
    // 输出解析结果
    fmt.Printf("%s\n", string(marshal))
}

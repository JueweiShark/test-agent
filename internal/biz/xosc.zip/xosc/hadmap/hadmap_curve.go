package hadmap

import (
    "errors"
    "math"
    "sort"
)

// 假设这些类型和常量在Go中定义

type txLineCurve struct {
    instancePtr *CurveData
    coordType   CoordType
    coords []txPoint3d
    //coords PointVec
}

func NewtxLineCurve(ct CoordType) *txLineCurve {
    return &txLineCurve{
        instancePtr: &CurveData{},
    }
}

const SL_BUFFER = 2.0

type Point2d struct {
    X, Y float64
}

type Point3d struct {
    X, Y, Z float64
}

type CurveData struct {
    Geom         PointVec
    DisFromBegin []float64
    PointsYaw    []float64
    PointsNormal []Point2d
    SlRefInfo    []Point3d
    Center       txPoint
}

func NewCurveData() *CurveData {
    return &CurveData{
        Center: txPoint{X: 0.0, Y: 0.0, Z: 0.0, W: 0.0, H: 0.0},
    }
}

func (cd *CurveData) ResetGeom(geom PointVec, ct CoordType) {
    cd.setCoords(geom)
    cd.calcLength(ct)
    cd.calcYaw(ct)
    cd.calcNormal(ct)
    cd.calcSLInfo(ct)
}

func (cd *CurveData) CalcSLInfo(ct CoordType) {
    if len(cd.Geom) <= 1 {
        return
    } else {
        if len(cd.PointsNormal) == 0 {
            cd.calcNormal(ct)
        }
        cd.SlRefInfo = make([]Point3d, len(cd.PointsNormal)-1)
        for i := 0; i < len(cd.SlRefInfo); i++ {
            begin, end, intersectP := cd.getBeginEndPoints(i, ct)
            if mapUtilIntersectPointNP(begin, cd.PointsNormal[i], end, cd.PointsNormal[i+1], &intersectP) {
                f := mapUtilPointSide(begin, end, intersectP)
                cd.SlRefInfo[i].X = intersectP.X
                cd.SlRefInfo[i].Y = intersectP.Y
                cd.SlRefInfo[i].Z = float64(f) * 1.0
            } else {
                cd.SlRefInfo[i].X = cd.PointsNormal[i].X
                cd.SlRefInfo[i].Y = cd.PointsNormal[i].Y
                cd.SlRefInfo[i].Z = 0.0
            }
        }
    }
}

func (cd *CurveData) getBeginEndPoints(index int, ct CoordType) (Point2d, Point2d, Point2d) {
    begin := Point2d{0.0, 0.0}
    end := Point2d{cd.Geom[index+1].X - cd.Geom[index].X, cd.Geom[index+1].Y - cd.Geom[index].Y}
    if ct == COORD_WGS84 {
        pos := txPoint{X: cd.Geom[index+1].X + cd.Center.X, Y: cd.Geom[index+1].Y + cd.Center.Y, Z: cd.Geom[index+1].Z + cd.Center.Z}
        coordTransLonlat2enu(pos.X, pos.Y, pos.Z, cd.Geom[index].X+cd.Center.X, cd.Geom[index].Y+cd.Center.Y, cd.Geom[index].Z+cd.Center.Z)
        begin.X = 0.0
        begin.Y = 0.0
        end.X = pos.X
        end.Y = pos.Y
    }
    return begin, end, Point2d{}
}

func (cd *CurveData) CalcNormal(ct CoordType) {
    if len(cd.Geom) <= 1 {
        return
    } else {
        if len(cd.PointsYaw) == 0 {
            cd.calcYaw(ct)
        }
        cd.PointsNormal = make([]Point2d, len(cd.PointsYaw))
        for i := 0; i < len(cd.PointsYaw); i++ {
            normalYaw := cd.PointsYaw[i] + 90
            mapUtilYaw2dir(normalYaw, true, &cd.PointsNormal[i])
        }
    }
}

func (cd *CurveData) CalcYaw(ct CoordType) {
    if len(cd.Geom) <= 1 {
        return
    } else {
        cd.PointsYaw = make([]float64, len(cd.Geom))
        for i := 0; i < len(cd.Geom); i++ {
            enu := ct != COORD_XYZ
            dir := cd.getDir(i, ct)
            cd.PointsYaw[i] = mapUtilDir2yaw(dir, enu)
        }
    }
}

func (cd *CurveData) getDir(index int, ct CoordType) Point2d {
    var dir Point2d
    if index == 0 || index == len(cd.Geom)-1 {
        bi := index
        ei := index + 1
        if index == len(cd.Geom)-1 {
            bi = index - 1
            ei = index
        }
        b := Point2d{cd.Geom[bi].X + cd.Center.X, cd.Geom[bi].Y + cd.Center.Y}
        e := Point2d{cd.Geom[ei].X + cd.Center.X, cd.Geom[ei].Y + cd.Center.Y}
        if ct == COORD_WGS84 {
            z := 0.0
            coordTransLonlat2enu(e.X, e.Y, z, b.X, b.Y, z)
            b.X = 0
            b.Y = 0
        }
        dir.X = e.X - b.X
        dir.Y = e.Y - b.Y
    } else {
        a := Point2d{cd.Geom[index-1].X + cd.Center.X, cd.Geom[index-1].Y + cd.Center.Y}
        b := Point2d{cd.Geom[index].X + cd.Center.X, cd.Geom[index].Y + cd.Center.Y}
        c := Point2d{cd.Geom[index+1].X + cd.Center.X, cd.Geom[index+1].Y + cd.Center.Y}
        if ct == COORD_WGS84 {
            z := 0.0
            coordTransLonlat2enu(a.X, a.Y, z, b.X, b.Y, z)
            coordTransLonlat2enu(c.X, c.Y, z, b.X, b.Y, z)
            b.X = 0
            b.Y = 0
        }
        dirba := Point2d{a.X - b.X, a.Y - b.Y}
        dirbc := Point2d{c.X - b.X, c.Y - b.Y}
        mapUtilNormalize(&dirba)
        mapUtilNormalize(&dirbc)
        dir.X = dirbc.X - dirba.X
        dir.Y = dirbc.Y - dirba.Y
    }
    return dir
}

func (cd *CurveData) CalcLastLength(ct CoordType) {
    if len(cd.Geom) == 0 {
        return
    } else if len(cd.Geom) == 1 {
        cd.DisFromBegin = []float64{0.0}
    } else {
        i := len(cd.DisFromBegin) - 1
        lastCoord := cd.getCoord(i, ct)
        for i++; i < len(cd.Geom); i++ {
            curCoord := cd.getCoord(i, ct)
            cd.DisFromBegin = append(cd.DisFromBegin, cd.DisFromBegin[i-1]+mapUtilDirectlyDis(lastCoord, curCoord))
            lastCoord = curCoord
        }
    }
}

func (cd *CurveData) CalcLength(ct CoordType) {
    if len(cd.Geom) <= 1 {
        return
    } else {
        cd.DisFromBegin = make([]float64, len(cd.Geom))
        lastCoord := cd.getCoord(0, ct)
        for i := 1; i < len(cd.Geom); i++ {
            curCoord := cd.getCoord(i, ct)
            cd.DisFromBegin[i] = cd.DisFromBegin[i-1] + mapUtilDirectlyDis(lastCoord, curCoord)
            lastCoord = curCoord
        }
    }
}

func (cd *CurveData) getCoord(index int, ct CoordType) [3]float64 {
    coord := [3]float64{cd.Geom[index].X + cd.Center.X, cd.Geom[index].Y + cd.Center.Y, cd.Geom[index].Z + cd.Center.Z}
    if ct == COORD_WGS84 {
        coordTransLonlat2global(coord[0], coord[1], coord[2])
    }
    return coord
}

func (cd *CurveData) SetCoords(points PointVec) {
    if len(points) < 1 {
        cd.Geom = nil
    } else {
        cd.Geom = make(PointVec, 0)
        cd.Center = points[0]
        for i := 0; i < len(points); i++ {
            p := txPoint{points[i].X - cd.Center.X, points[i].Y - cd.Center.Y, points[i].Z - cd.Center.Z, points[i].W, points[i].H}
            if i > 0 && math.Abs(p.X-cd.Geom[len(cd.Geom)-1].X) < 1e-9 && math.Abs(p.Y-cd.Geom[len(cd.Geom)-1].Y) < 1e-9 &&
                math.Abs(p.Z-cd.Geom[len(cd.Geom)-1].Z) < 1e-9 {
                continue
            }
            cd.Geom = append(cd.Geom, p)
        }
    }
}

func (cd *CurveData) GetLength() float64 {
    if len(cd.Geom) <= 1 {
        return 0.0
    } else {
        if len(cd.DisFromBegin) == 0 {
            return 0.0
        } else {
            return cd.DisFromBegin[len(cd.DisFromBegin)-1]
        }
    }
}

func (cd *CurveData) Size() int {
    return len(cd.Geom)
}

func (cd *CurveData) GetPointIndex(distance float64) int {
    if len(cd.Geom) == 0 {
        return -1
    } else {
        for i := 1; i < len(cd.Geom); i++ {
            if distance < cd.DisFromBegin[i] {
                if cd.DisFromBegin[i]-distance > distance-cd.DisFromBegin[i-1] {
                    return i - 1
                } else {
                    return i
                }
            }
        }
        return len(cd.Geom) - 1
    }
}

func (cd *CurveData) GetPoint(distance float64, ct CoordType) *txPoint {
    if len(cd.Geom) == 0 {
        return nil
    }
    if distance <= 0 {
        p := cd.Geom[0]
        p.X += cd.Center.X
        p.Y += cd.Center.Y
        p.Z += cd.Center.Z
        return p
    } else if distance >= cd.DisFromBegin[len(cd.DisFromBegin)-1] {
        p := cd.Geom[len(cd.Geom)-1]
        p.X += cd.Center.X
        p.Y += cd.Center.Y
        p.Z += cd.Center.Z
        return p
    } else {
        index := 1
        for ; index < len(cd.DisFromBegin); index++ {
            if distance < cd.DisFromBegin[index] {
                break
            }
        }
        if index >= len(cd.Geom) {
            return txPoint{}
        }
        distance -= cd.DisFromBegin[index-1]

        curPoint := cd.Geom[index-1]
        curPoint.X += cd.Center.X
        curPoint.Y += cd.Center.Y
        curPoint.Z += cd.Center.Z
        if ct == COORD_WGS84 {
            coordTransLonlat2global(curPoint.X, curPoint.Y, curPoint.Z)
        }
        nextPoint := cd.Geom[index]
        nextPoint.X += cd.Center.X
        nextPoint.Y += cd.Center.Y
        nextPoint.Z += cd.Center.Z
        if ct == COORD_WGS84 {
            coordTransLonlat2global(nextPoint.X, nextPoint.Y, nextPoint.Z)
        }

        dir := [3]float64{nextPoint.X - curPoint.X, nextPoint.Y - curPoint.Y, nextPoint.Z - curPoint.Z}
        mapUtilNormalize(&dir)
        curPoint.X += dir[0] * distance
        curPoint.Y += dir[1] * distance
        curPoint.Z += dir[2] * distance

        if ct == COORD_WGS84 {
            coordTransGlobal2lonlat(curPoint.X, curPoint.Y, curPoint.Z)
        }
        return curPoint
    }
}

//////////////////////////////
func (cd *CurveData) GetPointByIndex(index int) (txPoint, error) {
    if len(cd.Geom) == 0 {
        return txPoint{}, errors.New("txLineCurve::getPoint Geom is empty")
    }

    if index >= len(cd.Geom) {
        index = len(cd.Geom) - 1
    }

    p := cd.Geom[index]
    p.X += cd.Center.X
    p.Y += cd.Center.Y
    p.Z += cd.Center.Z
    return p, nil
}

func (cd *CurveData) Yaw(index int) (float64, error) {
    if len(cd.Geom) == 0 {
        return 0, errors.New("txLineCurve::yaw Geom is empty")
    }
    if len(cd.PointsYaw) == 0 {
        return 0, errors.New("txLineCurve::yaw yaw is empty")
    }

    if index >= len(cd.Geom) {
        index = len(cd.Geom) - 1
    }

    return cd.PointsYaw[index], nil
}

func (cd *CurveData) GetPoints(points *PointVec) {
    *points = append((*points)[:0], cd.Geom...)
    for i := range *points {
        (*points)[i].X += cd.Center.X
        (*points)[i].Y += cd.Center.Y
        (*points)[i].Z += cd.Center.Z
    }
}

func (cd *CurveData) GetGeometry(g *PointVec) {
    *g = append((*g)[:0], cd.Geom...)
    for i := range *g {
        (*g)[i].X += cd.Center.X
        (*g)[i].Y += cd.Center.Y
        (*g)[i].Z += cd.Center.Z
    }
}

func (cd *CurveData) GetPassedDistance(specifiedPoint txPoint, pedalPoint *txPoint, ct CoordType) (float64, error) {
    if len(cd.Geom) == 0 {
        return 0, errors.New("getPassedDistance error: Geom is empty")
    }

    minDis := math.MaxFloat64
    var u float64
    var minIndex int
    specP := Point3d{specifiedPoint.X, specifiedPoint.Y, specifiedPoint.Z}
    var pedalP Point3d

    for i := 1; i < len(cd.Geom); i++ {
        tmpU, tmpPedalP := projectPoint2Line(
            specP,
            Point3d{cd.Geom[i-1].X + cd.Center.X, cd.Geom[i-1].Y + cd.Center.Y, cd.Geom[i-1].Z + cd.Center.Z},
            Point3d{cd.Geom[i].X + cd.Center.X, cd.Geom[i].Y + cd.Center.Y, cd.Geom[i].Z + cd.Center.Z},
            ct == COORD_WGS84,
        )
        curDis := distanceBetweenPoints(specP, tmpPedalP, ct == COORD_WGS84)
        if curDis < minDis {
            minDis = curDis
            minIndex = i
            u = tmpU
            pedalP = tmpPedalP
        }
    }

    pedalPoint.X = pedalP.X
    pedalPoint.Y = pedalP.Y
    pedalPoint.Z = pedalP.Z

    if minIndex > 0 {
        return cd.DisFromBegin[minIndex-1] + u*(cd.DisFromBegin[minIndex]-cd.DisFromBegin[minIndex-1]), nil
    } else {
        return 0, errors.New("getPassedDistance error")
    }
}

///////////////////////
func (tl *txLineCurve) size() int {
    return len(tl.instancePtr.geom)
}

func (tl *txLineCurve) getPoint(index int) txPoint {
    return tl.instancePtr.geom[index]
}

func (tl *txLineCurve) yaw(index int) float64 {
    // Implementation depends on the specific calculation method
    return 0.0
}

func (tl *txLineCurve) getPoints(points *PointVec) {
    *points = tl.instancePtr.geom
}

func (tl *txLineCurve) addPoint(point txPoint, update bool) {
    if len(tl.instancePtr.geom) == 0 {
        tl.instancePtr.center = point
    }
    curP := point
    curP.x -= tl.instancePtr.center.x
    curP.y -= tl.instancePtr.center.y
    curP.z -= tl.instancePtr.center.z
    tl.instancePtr.geom = append(tl.instancePtr.geom, curP)
    tl.instancePtr.calcLastLength(tl.coordType)
    if update {
        tl.instancePtr.calcYaw(tl.coordType)
        tl.instancePtr.calcNormal(tl.coordType)
        tl.instancePtr.calcSLInfo(tl.coordType)
    }
}

func (tl *txLineCurve) setCoords(points PointVec) {
    tl.instancePtr.resetGeom(points, tl.coordType)
}

func (tl *txLineCurve) clone(curveIns txCurve) error {
    samplingCurveIns, ok := curveIns.(*txLineCurve)
    if !ok {
        return errors.New("Invalid curve type")
    }
    tl.coordType = samplingCurveIns.coordType
    tmpGeom := make(PointVec, len(samplingCurveIns.instancePtr.geom))
    copy(tmpGeom, samplingCurveIns.instancePtr.geom)
    tl.instancePtr.resetGeom(tmpGeom, tl.coordType)
    return nil
}

func (tl *txLineCurve) splice(curvePtr txCurve) error {
    samplingCurvePtr, ok := curvePtr.(*txLineCurve)
    if !ok {
        return errors.New("Invalid curve type")
    }
    if tl.coordType != samplingCurvePtr.coordType {
        return errors.New("txLineCurve::splice Coord Type Error")
    }
    tmpGeom := make(PointVec, len(samplingCurvePtr.instancePtr.geom))
    copy(tmpGeom, samplingCurvePtr.instancePtr.geom)
    newGeom := make(PointVec, len(tl.instancePtr.geom))
    copy(newGeom, tl.instancePtr.geom)
    for i := range newGeom {
        newGeom[i].x += tl.instancePtr.center.x
        newGeom[i].y += tl.instancePtr.center.y
        newGeom[i].z += tl.instancePtr.center.z
    }
    newGeom = append(newGeom, tmpGeom...)
    tl.instancePtr.resetGeom(newGeom, tl.coordType)
    return nil
}

func (tl *txLineCurve) reverse() {
    if len(tl.instancePtr.geom) < 2 {
        return
    }
    for i := range tl.instancePtr.geom {
        tl.instancePtr.geom[i].x += tl.instancePtr.center.x
        tl.instancePtr.geom[i].y += tl.instancePtr.center.y
        tl.instancePtr.geom[i].z += tl.instancePtr.center.z
    }
    tl.instancePtr.center = tl.instancePtr.geom[len(tl.instancePtr.geom)-1]
    for i, j := 0, len(tl.instancePtr.geom)-1; i < j; i, j = i+1, j-1 {
        tl.instancePtr.geom[i], tl.instancePtr.geom[j] = tl.instancePtr.geom[j], tl.instancePtr.geom[i]
    }
    for i := range tl.instancePtr.geom {
        tl.instancePtr.geom[i].x -= tl.instancePtr.center.x
        tl.instancePtr.geom[i].y -= tl.instancePtr.center.y
        tl.instancePtr.geom[i].z -= tl.instancePtr.center.z
    }
    tl.instancePtr.calcYaw(tl.coordType)
    tl.instancePtr.calcLength(tl.coordType)
    tl.instancePtr.calcNormal(tl.coordType)
}

func (tl *txLineCurve) transfer(oldEnuC, newEnuC txPoint) bool {
    if tl.coordType == COORD_WGS84 || tl.coordType == COORD_XYZ {
        return false
    } else {
        tl.instancePtr.center = tl.instancePtr.oriBegin
        // coord_trans_api::lonlat2enu(lc.instancePtr.center.x, lc.instancePtr.center.y, lc.instancePtr.center.z, newEnuC.x, newEnuC.y, newEnuC.z)
    coord_trans_api::enu2lonlat(tl.instancePtr.center.x, tl.instancePtr.center.y, tl.instancePtr.center.z, oldEnuC.x, oldEnuC.y, oldEnuC.z)
    coord_trans_api::lonlat2enu(tl.instancePtr.center.x, tl.instancePtr.center.y, tl.instancePtr.center.z, newEnuC.x, newEnuC.y, newEnuC.z)
        return true
    }
}

func (tl *txLineCurve) transfer2ENU(enuCenter txPoint) bool {
    if tl.coordType != COORD_WGS84 {
        return false
    } else {
        tl.coordType = COORD_ENU
        newCenter := tl.instancePtr.center
        // coord_trans_api::lonlat2enu(newCenter.x, newCenter.y, newCenter.z, enuCenter.x, enuCenter.y, enuCenter.z)
        for i := range tl.instancePtr.geom {
            curP := tl.instancePtr.geom[i]
            curP.x += tl.instancePtr.center.x
            curP.y += tl.instancePtr.center.y
            curP.z += tl.instancePtr.center.z
            // coord_trans_api::lonlat2enu(curP.x, curP.y, curP.z, enuCenter.x, enuCenter.y, enuCenter.z)
            curP.x -= newCenter.x
            curP.y -= newCenter.y
            curP.z -= newCenter.z
            tl.instancePtr.geom[i] = curP
        }
        tl.instancePtr.center = newCenter

        tl.instancePtr.calcNormal(COORD_ENU)
        tl.instancePtr.calcSLInfo(COORD_ENU)
        return true
    }
}


func (tl *txLineCurve) xy2sl(x, y float64, s, l, yaw *float64) bool {
    if tl.instancePtr.geom == nil || len(tl.instancePtr.geom) == 0 {
        return false
    }

    localPoints := make([]Point2d, len(tl.instancePtr.geom)+2)
    localXY := Point2d{x, y}
    for i, j := 1, 0; j < len(tl.instancePtr.geom); i, j = i+1, j+1 {
        localPoints[i].x = tl.instancePtr.geom[j].x + tl.instancePtr.center.x
        localPoints[i].y = tl.instancePtr.geom[j].y + tl.instancePtr.center.y
    }
    if tl.coordType == COORD_WGS84 {
        localXY.x = 0
        localXY.y = 0
        z := 0.0
        for i := 1; i < len(localPoints)-1; i++ {
            coord_trans_api.Lonlat2enu(localPoints[i].x, localPoints[i].y, z, &x, &y, &z)
        }
    }

    frontDir := Point2d{localPoints[1].x - localPoints[2].x, localPoints[1].y - localPoints[2].y}
    map_util.Normalize(&frontDir)
    localPoints[0].x = localPoints[1].x + 2*SL_BUFFER*frontDir.x
    localPoints[0].y = localPoints[1].y + 2*SL_BUFFER*frontDir.y

    backDir := Point2d{localPoints[len(localPoints)-2].x - localPoints[len(localPoints)-3].x,
        localPoints[len(localPoints)-2].y - localPoints[len(localPoints)-3].y}
    map_util.Normalize(&backDir)
    localPoints[len(localPoints)-1].x = localPoints[len(localPoints)-2].x + 2*SL_BUFFER*backDir.x
    localPoints[len(localPoints)-1].y = localPoints[len(localPoints)-2].y + 2*SL_BUFFER*backDir.y

    var nIndex int
    var nDis float64
    if map_util.NearestPoint2d(localPoints, localXY, false, &nIndex, &nDis) {
        if nIndex == 0 || nIndex == len(localPoints)-1 {
            return false
        }

        var index []int
        if nIndex > 0 {
            index = append(index, nIndex-1)
            index = append(index, nIndex)
            if nIndex < len(localPoints)-1 {
                index = append(index, nIndex+1)
            }
        } else {
            index = append(index, nIndex)
            index = append(index, nIndex+1)
        }

        for i := 0; i < len(index)-1; i++ {
            var tagP, intersectP Point2d
            curP := localPoints[index[i]]
            nexP := localPoints[index[i+1]]
            if index[i] == 0 {
                tagP.x = localXY.x + tl.instancePtr.pointsNormal[0].x
                tagP.y = localXY.y + tl.instancePtr.pointsNormal[0].y
            } else if index[i] == len(tl.instancePtr.geom) {
                tagP.x = localXY.x + tl.instancePtr.pointsNormal[len(tl.instancePtr.pointsNormal)-1].x
                tagP.y = localXY.y + tl.instancePtr.pointsNormal[len(tl.instancePtr.pointsNormal)-1].y
            } else {
                refInfo := tl.instancePtr.slRefInfo[index[i]-1]
                if math.Abs(refInfo.z) > 1e-5 {
                    preP := localPoints[index[i]]
                    tagP.x = refInfo.x + preP.x
                    tagP.y = refInfo.y + preP.y
                } else {
                    tagP.x = refInfo.x + localXY.x
                    tagP.y = refInfo.y + localXY.y
                }
            }

            if map_util.IntersectPointDP(curP, nexP, localXY, tagP, &intersectP) {
                if map_util.PointOnLine(curP, nexP, intersectP) {
                    if index[i] == 0 {
                        *s = -map_util.DirectlyDis(nexP, intersectP)
                    } else {
                        *s = tl.instancePtr.disFromBegin[index[i]-1] + map_util.DirectlyDis(curP, intersectP)
                    }
                    *l = map_util.DirectlyDis(localXY, intersectP) * map_util.PointSide(curP, nexP, localXY)
                    *yaw = map_util.Dir2yaw(Point2d{nexP.x - curP.x, nexP.y - curP.y}, tl.coordType == COORD_ENU || tl.coordType == COORD_WGS84)
                    return true
                }
            }
        }

        return false
    } else {
        return false
    }
}
//////////

func (tl *txLineCurve) sl2xy(s, l float64, x, y, yaw *float64) bool {
    disFromBegin := tl.instancePtr.disFromBegin
    if s < 0.0 || s > disFromBegin[len(disFromBegin)-1]+SL_BUFFER {
        return false
    }

    tag := 0
    if s > disFromBegin[1] {
        itr := sort.SearchFloat64s(disFromBegin, s)
        tag = itr - 1
    }

    if tl.coordType == COORD_WGS84 {
        localPoints := make([]Point2d, len(tl.instancePtr.geom))
        for i := range tl.instancePtr.geom {
            localPoints[i].x = tl.instancePtr.geom[i].x + tl.instancePtr.center.x
            localPoints[i].y = tl.instancePtr.geom[i].y + tl.instancePtr.center.y
        }
        refX := tl.instancePtr.geom[tag].x + tl.instancePtr.center.x
        refY := tl.instancePtr.geom[tag].y + tl.instancePtr.center.y
        z := 0.0
        for i := range localPoints {
            coord_trans_api.Lonlat2enu(localPoints[i].x, localPoints[i].y, z, refX, refY, 0)
        }

        front := tag
        if tag == len(localPoints)-1 {
            front--
        }
        back := front + 1
        dir := Point2d{localPoints[back].x - localPoints[front].x, localPoints[back].y - localPoints[front].y}
        offset := (s - disFromBegin[front]) / (disFromBegin[back] - disFromBegin[front])
        tagP := Point2d{localPoints[front].x + offset*dir.x, localPoints[front].y + offset*dir.y}

        *yaw = tl.instancePtr.pointsYaw[tag]
        curN := Point2d{}
        if tag == len(localPoints)-1 {
            curN.x = tl.instancePtr.pointsNormal[tag].x
            curN.y = tl.instancePtr.pointsNormal[tag].y
            if l > 0 {
                curN.x *= -1
                curN.y *= -1
            }
        } else {
            beginN := tl.instancePtr.pointsNormal[tag]
            endN := tl.instancePtr.pointsNormal[tag+1]
            intersectP := Point2d{}
            begin := Point2d{localPoints[tag].x, localPoints[tag].y}
            end := Point2d{localPoints[tag+1].x, localPoints[tag+1].y}

            if !map_util.IntersectPointNP(begin, beginN, end, endN, &intersectP) {
                intersectP.x = tagP.x + beginN.x
                intersectP.y = tagP.y + beginN.y
            }
            if l*map_util.PointSide(begin, end, intersectP) > 0 {
                curN.x = intersectP.x - tagP.x
                curN.y = intersectP.y - tagP.y
            } else {
                curN.x = tagP.x - intersectP.x
                curN.y = tagP.y - intersectP.y
            }
        }

        map_util.Normalize(&curN)
        *x = tagP.x + math.Abs(l)*curN.x
        *y = tagP.y + math.Abs(l)*curN.y
        z = 0.0
        coord_trans_api.Enu2lonlat(*x, *y, z, refX, refY, 0)

        return true
    } else {
        geom := tl.instancePtr.geom
        front := tag
        if tag == len(geom)-1 {
            front--
        }
        back := front + 1
        dir := Point2d{geom[back].x - geom[front].x, geom[back].y - geom[front].y}
        offset := (s - disFromBegin[front]) / (disFromBegin[back] - disFromBegin[front])
        tagP := Point2d{geom[front].x + offset*dir.x, geom[front].y + offset*dir.y}

        *yaw = tl.instancePtr.pointsYaw[tag]
        refInfo := Point3d{}
        if tag < len(geom)-1 {
            refInfo = tl.instancePtr.slRefInfo[tag]
        } else {
            refInfo.x = tl.instancePtr.pointsNormal[tag].x
            refInfo.y = tl.instancePtr.pointsNormal[tag].y
            refInfo.z = 0.0
        }

        if math.Abs(refInfo.z) > 1e-5 {
            curN := Point2d{refInfo.x - tagP.x, refInfo.y - tagP.y}
            map_util.Normalize(&curN)
            *x = tagP.x + l*refInfo.z*curN.x
            *y = tagP.y + l*refInfo.z*curN.y
        } else {
            *x = tagP.x + l*refInfo.x
            *y = tagP.y + l*refInfo.y
        }

        *x += tl.instancePtr.center.x
        *y += tl.instancePtr.center.y

        return true
    }
}
func (tl *txLineCurve) getYaw(s float64) float64 {
    ds := math.Min(math.Max(s, 0.1), tl.instancePtr.disFromBegin[len(tl.instancePtr.disFromBegin)-1] - 0.1)
    tag := 0
    for i := 0; i < len(tl.instancePtr.disFromBegin)-1; i++ {
        if tl.instancePtr.disFromBegin[i] < ds && ds < tl.instancePtr.disFromBegin[i+1] {
            tag = i
            break
        }
    }
    return tl.instancePtr.pointsYaw[tag]
    /*
       if s < 0.0 {
           return -1.0
       }
       tag := len(txLineCurve.instancePtr.disFromBegin) - 1
       for i := 0; i < len(txLineCurve.instancePtr.disFromBegin)-1; i++ {
           if txLineCurve.instancePtr.disFromBegin[i] < s && s < txLineCurve.instancePtr.disFromBegin[i+1] {
               tag = i
               break
           }
       }
       if tag == len(txLineCurve.instancePtr.disFromBegin)-1 {
           return -1.0
       }

       localPoints := make([]Point2d, len(txLineCurve.instancePtr.geom))
       localPoints[0] = Point2d{0.0, 0.0}
       for i := 1; i < len(txLineCurve.instancePtr.geom); i++ {
           localPoints[i] = Point2d{txLineCurve.instancePtr.geom[i].x + txLineCurve.instancePtr.center.x, txLineCurve.instancePtr.geom[i].y + txLineCurve.instancePtr.center.y}
       }
       if txLineCurve.coordType == COORD_WGS84 {
           var z float64
           for i := 1; i < len(localPoints); i++ {
               coord_trans_api.Lonlat2local(localPoints[i].x, localPoints[i].y, z, txLineCurve.instancePtr.center.x, txLineCurve.instancePtr.center.y, txLineCurve.instancePtr.center.z)
           }
       }

       dir := Point2d{localPoints[tag+1].x - localPoints[tag].x, localPoints[tag+1].y - localPoints[tag].y}
       map_util.Normalize(&dir)

       return map_util.Dir2yaw(Point2d{localPoints[tag+1].x - localPoints[tag].x, localPoints[tag+1].y - localPoints[tag].y}, txLineCurve.coordType == COORD_ENU)
    */
}
func (tl *txLineCurve) cut(begin, end float64, points *[]txPoint) bool {
    if begin > -1e-7 && end > -1e-7 && begin > end {
        return false
    }
    if begin > tl.instancePtr.disFromBegin[len(instancePtr.disFromBegin)-1] {
        return false
    }

    const CREATE_INTERVAL_T = 0.2
    startIndex, endIndex := 0, len(instancePtr.geom)-1
    startP, endP := (*txPoint)(nil), (*txPoint)(nil)

    if begin < 1e-1 {
        startIndex = 0
    } else {
        for i := 1; i < len(instancePtr.disFromBegin); i++ {
            if begin <= instancePtr.disFromBegin[i] {
                startIndex = i
                break
            }
        }
        if math.Abs(begin-instancePtr.disFromBegin[startIndex]) < CREATE_INTERVAL_T {
            startP = nil
        } else if math.Abs(begin-instancePtr.disFromBegin[startIndex-1]) < CREATE_INTERVAL_T {
            startIndex -= 1
        } else {
            offset := begin - instancePtr.disFromBegin[startIndex-1]
            startP = &txPoint{genIntervalP(startIndex-1, startIndex, offset)}
        }
    }

    if end < 1e-1 || end >= instancePtr.disFromBegin[len(instancePtr.disFromBegin)-1] {
        endIndex = len(instancePtr.geom)-1
    } else {
        for i := 1; i < len(instancePtr.disFromBegin); i++ {
            if end < instancePtr.disFromBegin[i] {
                endIndex = i - 1
                break
            }
        }
        if math.Abs(end-instancePtr.disFromBegin[endIndex]) < CREATE_INTERVAL_T {
            endP = nil
        } else if math.Abs(end-instancePtr.disFromBegin[endIndex+1]) < CREATE_INTERVAL_T {
            endIndex += 1
        } else {
            offset := end - instancePtr.disFromBegin[endIndex]
            endP = &txPoint{genIntervalP(endIndex, endIndex+1, offset)}
        }
    }

    *points = []txPoint{}
    if endIndex-startIndex+1 == len(instancePtr.geom) {
        *points = append(*points, instancePtr.geom...)
    } else {
        if startP != nil {
            *points = append(*points, *startP)
            startP = nil
        }
        *points = append(*points, instancePtr.geom[startIndex:endIndex+1]...)
        if endP != nil {
            *points = append(*points, *endP)
            endP = nil
        }
    }

    for i := range *points {
        (*points)[i].x += instancePtr.center.x
        (*points)[i].y += instancePtr.center.y
        (*points)[i].z += instancePtr.center.z
    }
    return true
}

func (tl *txLineCurve) genIntervalP(start, end uint, offset float64) txPoint {
    if start+1 != end {
        return txPoint{-1.0, -1.0, -1.0}
    }
    yaw := tl.instancePtr.pointsYaw[start]
    var dir Point2d
    map_util.yaw2dir(yaw, true, &dir)
    tagP := tl.instancePtr.geom[start]
    if tl.coordType == COORD_WGS84 {
        tagP = txPoint{0.0, 0.0, 0.0}
    }
    tagP.x += dir.x * offset
    tagP.y += dir.y * offset
    if tl.coordType == COORD_WGS84 {
        c := tl.instancePtr.geom[start]
        c.x += tl.instancePtr.center.x
        c.y += tl.instancePtr.center.y
        c.z += tl.instancePtr.center.z
        coord_trans_api.enu2lonlat(tagP.x, tagP.y, tagP.z, c.x, c.y, c.z)
        tagP.x -= tl.instancePtr.center.x
        tagP.y -= tl.instancePtr.center.y
        tagP.z -= tl.instancePtr.center.z
    }
    return tagP
}
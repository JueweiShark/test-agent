package hadmap

import (
    "errors"
    "strings"

    "wuwen.com/wwsi/internal/biz/xosc"
)
const (
    nSingleObjectTypeNumMax = 100
    nSingleSignTypeNumMax   = 1000
)
type ObjData struct {
    Data     tx_object_t
    OdData   tx_od_object_t
    Geoms    txObjGeoms
    Repeat   txLineCurvePtr
    RelIds   []xosc.txLaneId
    UserData map[string]string
}

type txObject struct {
    instancePtr *ObjData
}

func NewTxObject() *txObject {
    return &txObject{instancePtr: &ObjData{}}
}

func (t *txObject) GetTxData() xosc.tx_object_t {
    return t.instancePtr.Data
}

func (t *txObject) GetOdData() tx_od_object_t {
    return t.instancePtr.OdData
}

func (t *txObject) GetId() objectpkid {
    return t.instancePtr.Data.pkid
}

func (t *txObject) GetObjectType() OBJECT_TYPE {
    return OBJECT_TYPE(t.instancePtr.Data.Type)
}

func (t *txObject) GetObjectSubType() OBJECT_SUB_TYPE {
    return OBJECT_SUB_TYPE(t.instancePtr.Data.subtype)
}

func (t *txObject) GetName() string {
    return t.instancePtr.Data.name
}

func (t *txObject) GetReliedLaneIds() []xosc.txLaneId {
    return t.instancePtr.RelIds
}


func (t *txObject) GetGeomSize() int {
    return len(t.instancePtr.Geoms)
}

func (t *txObject) GetGeom(index int) *txObjGeom {
    if index >= len(t.instancePtr.Geoms) {
        panic("getGeom error, index out of range")
    }
    return t.instancePtr.Geoms[index]
}

func (t *txObject) Transform2OdData() {
    odData := t.instancePtr.OdData
    odData.ObjectPkid = t.instancePtr.Data.Pkid
    odData.Type = t.instancePtr.Data.Type
    odData.Subtype = t.instancePtr.Data.Subtype
    copy(odData.Name[:], t.instancePtr.Data.Name[:])
    // odData.Orientation = 1
    // odData.Validlength = 0.0
    // odData.Radius = 0.0
    // t.GetRPY(&odData.Roll, &odData.Pitch, &odData.Hdg)
    t.GetLWH(&odData.Length, &odData.Width, &odData.Height)
    odData.Roadid = t.instancePtr.Data.Roadid
    // if t.GetGeomSize() > 0 && t.GetGeom()->GetGeometry() != nil {
    //  point := t.GetPos()
    //  odData.S = point.X
    //  odData.T = point.Y
    // }
    userData := make(map[string]string)
    t.GetUserData(userData)
    strUserData := ""
    for key, value := range userData {
        strUserData += (key + ":" + value + ";")
    }
    copy(odData.Userdata[:], strUserData)

    t.instancePtr.OdData = odData
}

func (t *txObject) SetTxOdData(odData tx_od_object_t) {
    t.instancePtr.OdData = odData
    t.instancePtr.Data.Type = t.instancePtr.OdData.Type
    t.instancePtr.Data.Subtype = t.instancePtr.OdData.Subtype
    t.SetLWH(t.instancePtr.OdData.Length, t.instancePtr.OdData.Width, t.instancePtr.OdData.Height)
    // t.SetRPY(t.instancePtr.OdData.Roll, t.instancePtr.OdData.Pitch, t.instancePtr.OdData.Hdg)
    if t.GetGeomSize() > 0 && t.GetGeom(0).GetGeometry() != nil {
        point := t.GetPos()
        t.SetPos(point.X, point.Y, t.instancePtr.OdData.Zoffset)
    }
    userdata := string(odData.Userdata[:])
    // set userdata
    result := make([]string, 0)
    size := len(userdata)
    for i := 0; i < size; i++ {
        pos := strings.Index(userdata[i:], ";")
        if pos < size {
            s := userdata[i : i+pos]
            if s != "" {
                result = append(result, s)
            }
            i += pos
        }
    }
    userDataVec := make(map[string]string)
    for _, it := range result {
        pos := strings.Index(it, ":")
        key := it[:pos]
        value := it[pos+1:]
        userDataVec[key] = value
    }
    t.SetUserData(userDataVec)
}
func (t *txObject) GetRepeat() *txLineCurve {
    return t.instancePtr.Repeat
}

func (t *txObject) SetId(id objectpkid) *txObject {
    t.instancePtr.Data.Pkid = id
    return t
}

func (t *txObject) SetObjectType(type_ OBJECT_TYPE) *txObject {
    t.instancePtr.Data.Type = type_
    return t
}

func (t *txObject) SetName(name string) *txObject {
    copy(t.instancePtr.Data.Name[:], name)
    return t
}

func (t *txObject) AddReliedLaneId(laneId txLaneId) *txObject {
    for _, id := range t.instancePtr.RelIds {
        if id == laneId {
            return t
        }
    }
    t.instancePtr.RelIds = append(t.instancePtr.RelIds, laneId)
    return t
}

func (t *txObject) SetReliedLaneIds(laneIds []txLaneId) *txObject {
    t.instancePtr.RelIds = laneIds
    return t
}

func (t *txObject) AddGeom(geomPtr *txObjGeom) *txObject {
    t.instancePtr.Geoms = append(t.instancePtr.Geoms, geomPtr)
    return t
}

func (t *txObject) SetRepeat(geomPtr *txLineCurve) *txObject {
    t.instancePtr.Repeat = geomPtr
    return t
}

func (t *txObject) SetST(s, t float64) *txObject {
    t.instancePtr.Data.S = s
    t.instancePtr.Data.T = t
    return t
}

func (t *txObject) SetOdRoadId(id int) *txObject {
    t.instancePtr.Data.Roadid = id
    t.instancePtr.OdData.Roadid = id
    return t
}

func (t *txObject) SetLaneLinkid(id int) *txObject {
    t.instancePtr.OdData.Lanelinkid = id
    return t
}

func (t *txObject) Transfer(oldEnuC, newEnuC txPoint) *txObject {
    for _, geomPtr := range t.instancePtr.Geoms {
        geomPtr.Transfer(oldEnuC, newEnuC)
    }
    return t
}

func (t *txObject) Transfer2ENU(enuCenter txPoint) *txObject {
    for _, geomPtr := range t.instancePtr.Geoms {
        geomPtr.Transfer2ENU(enuCenter)
    }
    return t
}

func (t *txObject) GetRoadId() roadpkid {
    return t.instancePtr.Data.Roadid
}

func (t *txObject) GetPos() txPoint {
    return txPoint{t.instancePtr.Data.X, t.instancePtr.Data.Y, t.instancePtr.Data.Z}
}

func (t *txObject) GetST() (s, t float64) {
    s = t.instancePtr.Data.S
    t = t.instancePtr.Data.T
    return
}

func (t *txObject) GetLWH() (l, w, h float64) {
    l = t.instancePtr.Data.Length
    w = t.instancePtr.Data.Width
    h = t.instancePtr.Data.Height
    return
}

func (t *txObject) GetRPY() (r, p, y float64) {
    r = t.instancePtr.Data.Roll
    p = t.instancePtr.Data.Pitch
    y = t.instancePtr.Data.Yaw
    return
}

func (t *txObject) GetRawTypeString() (type_, subtype string) {
    type_ = t.instancePtr.Data.Rawtype
    subtype = t.instancePtr.Data.Rawsubtype
    return
}

func (t *txObject) SetUserData(userData map[string]string) *txObject {
    t.instancePtr.UserData = userData
    return t
}

func (t *txObject) SetData(data tx_object_t) *txObject {
    t.instancePtr.Data = data
    return t
}

 func setPoleType(name string , typ string , ntype *uint32, nsubtype *uint32)int {
if (name == "Vertical_Pole" || name == "UprightPole") {
*ntype = OBJECT_TYPE_Pole;
*nsubtype = POLE_VERTICAL;
} else if (name == "Cross_Pole" || name == "SingleArmPole") {
    *ntype = OBJECT_TYPE_Pole;
    *nsubtype = POLE_CROSS;
} else if (name == "Cantilever_Pole") {
    *ntype = OBJECT_TYPE_Pole;
    *nsubtype = POLE_Cantilever;
} else if (name == "Pillar_Pole_6m") {
    *ntype = OBJECT_TYPE_Pole;
    *nsubtype = POLE_Pillar_6m;
} else if (name == "Pillar_Pole_3m") {
    *ntype = OBJECT_TYPE_Pole;
    *nsubtype = POLE_Pillar_3m;
} else if (typ == "pole") {
         *ntype = OBJECT_TYPE_Pole;
         *nsubtype = POLE_VERTICAL;
} else {
return -1;
}
return 0;
}

func setTrafficType(name string, type_ string, subType string, st int, ntype *int, nsubtype *int) int {
    switch type_ {
    case "1000001", "1000011", "1000021":
        switch subType {
        case "60":
            *ntype = OBJECT_TYPE_TrafficLights
            *nsubtype = LIGHT_VERTICAL_STRAIGHTROUND
        case "10":
            *ntype = OBJECT_TYPE_TrafficLights
            *nsubtype = LIGHT_VERTICAL_LEFTTURN
        case "30":
            *ntype = OBJECT_TYPE_TrafficLights
            *nsubtype = LIGHT_VERTICAL_STRAIGHT
        case "20":
            *ntype = OBJECT_TYPE_TrafficLights
            *nsubtype = LIGHT_VERTICAL_RIGHTTURN
        case "70":
            *ntype = OBJECT_TYPE_TrafficLights
            *nsubtype = LIGHT_VERTICAL_UTURN
        default:
            return -1
        }
    case "1000002":
        *ntype = OBJECT_TYPE_TrafficLights
        *nsubtype = LIGHT_HORIZON_PEDESTRIAN
    case "1000003":
        *ntype = OBJECT_TYPE_TrafficLights
        *nsubtype = LIGHT_HORIZON_ALLDIRECT
    case "1000013":
        *ntype = OBJECT_TYPE_TrafficLights
        *nsubtype = LIGHT_BICYCLELIGHT
    case "1000009":
        *ntype = OBJECT_TYPE_TrafficLights
        *nsubtype = LIGHT_TWOCOLOR
    case "TrafficLights", "trafficLight":
        *ntype = OBJECT_TYPE_TrafficLights
        *nsubtype = LIGHT_VERTICAL_ALLDIRECT
    default:
        return -1
    }
    return 0
}


// set trafficlight type
func setSignType(name string , t string,subType string , st int , ntype *int ,  nsubtype *int) int{
*ntype = OBJECT_TYPE_TrafficSign;
if t== "1010103200001111" || t== "1010103200001110" || subType == "w30" {
*nsubtype = SIGN_WARNING_SLOWDOWN;
} else if (t== "1010100211001111" || t== "1010100211001110" || subType == "w43") {
*nsubtype = SIGN_WARNING_TURNLEFT;
} else if (t== "1010100212001111" || t== "1010100212001110" || subType == "w42") {
    *nsubtype = SIGN_WARNING_TURNRIGHT;
} else if (t== "1010100121001111" || t== "1010100121001110" || subType == "w22") {
    *nsubtype = SIGN_WARNING_T_RIGHT;
} else if (t== "1010100123001111" || t== "1010100123001110" || subType == "w20") {
    *nsubtype = SIGN_WARNING_T_DOWN;
} else if (t== "1010100111001111" || t== "1010100111001110" || subType == "w13") {
    *nsubtype = SIGN_WARNING_CROSS;
} else if (t== "1010101100001111" || t== "1010101100001110" || subType == "w55") {
    *nsubtype = SIGN_WARNING_CHILD;
} else if (t== "1010100511001111" || t== "1010100511001110" || subType == "w31") {
    *nsubtype = SIGN_WARNING_UP;
} else if (t== "1010103500001111" || t== "1010103500001110" || subType == "w32") {
    *nsubtype = SIGN_WARNING_BUILDING;
} else if (t== "1010100711001111" || t== "1010100711001110" || subType == "w18") {
    *nsubtype = SIGN_WARNING_NARROW_LEFT;
} else if (t== "1010100713001111" || t== "1010100713001110" || subType == "w8") {
    *nsubtype = SIGN_WARNING_NARROW_BOTH;
} else if (t== "1010102812001111" || t== "1010102812001110" || subType == "w40") {
    *nsubtype = SIGN_WARNING_RAILWAY;
} else if (t== "1010100122001111" || t== "1010100122001110" || subType == "w21") {
*nsubtype = SIGN_WARNING_T_LEFT;
} else if (t== "1010101811001111" || t== "1010101811001110" || subType == "w1") {
*nsubtype = SIGN_WARNING_STEEP_LEFT;
} else if (t== "1010101812001111" || t== "1010101812001110" || subType == "w2") {
*nsubtype = SIGN_WARNING_STEEP_RIGHT;
} else if (t== "1010102000001111" || t== "1010102000001110" || subType == "w3") {
*nsubtype = SIGN_WARNING_VILLAGE;
} else if (t== "1010101911001111" || t== "1010101911001110" || subType == "w4") {
*nsubtype = SIGN_WARNING_DIKE_LEFT;
} else if (t== "1010101912001111" || t== "1010101912001110" || subType == "w5") {
*nsubtype = SIGN_WARNING_DIKE_RIGHT;
} else if (t== "1010104012001111" || t== "1010104012001110" || subType == "w6") {
*nsubtype = SIGN_WARAING_T_CROSSED;
} else if (t== "1010102200001111" || t== "1010102200001110" || subType == "w7") {
*nsubtype = SIGN_WARAING_FERRY;
} else if (t== "1010101512001111" || t== "1010101512001110" || subType == "w9") {
*nsubtype = SIGN_WARAING_FALL_ROCK;
} else if (t== "1010100311001111" || t== "1010100311001110" || subType == "w10") {
*nsubtype = SIGN_WARAING_REVERSE_CURVE_LEFT;
} else if (t== "1010100312001111" || t== "1010100312001110" || subType == "w11") {
*nsubtype = SIGN_WARAING_REVERSE_CURVE_RIGHT;
} else if (t== "1010102700001111" || t== "1010102700001110" || subType == "w12") {
*nsubtype = SIGN_WARAING_WATER_PAVEMENT;
} else if (t== "1010100112001111" || t== "1010100112001110" || subType == "w14") {
*nsubtype = SIGN_WARNING_T_BOTH;
} else if (t== "1010100131001111" || t== "1010100131001110" || subType == "w15") {
*nsubtype = SIGN_WARNING_JOIN_LEFT;
} else if (t== "1010100132001111" || t== "1010100132001110" || subType == "w16") {
*nsubtype = SIGN_WARNING_JOIN_RIGHT;
} else if (t== "1010100134001111" || t== "1010100134001110" || subType == "w17") {
*nsubtype = SIGN_WARNING_Y_LEFT;
} else if (t== "1010100141001111" || t== "1010100134001110" || subType == "w23") {
*nsubtype = SIGN_WARNING_CIRCLE_CROSS;
} else if (t== "1010100400001111" || t== "1010100400001110" || subType == "w24") {
*nsubtype = SIGN_WARNING_CURVE_AHEAD;
} else if (t== "1010100600001111" || t== "1010100600001110" || subType == "w25") {
*nsubtype = SIGN_WARNING_LONG_DESCENT;
} else if (t== "1010102400001111" || t== "1010102400001110" || subType == "w26") {
*nsubtype = SIGN_WARNING_ROUGH_ROAD;
} else if (t== "1010104312001111" || t== "1010104312001110" || subType == "w27") {
*nsubtype = SIGN_WARNING_SNOW;
} else if (t== "1010103000001111" || t== "1010103000001110" || subType == "w52") {
*nsubtype = SIGN_WARNING_DISABLE;
} else if (t== "1010101300001111" || t== "1010101300001110" || subType == "w36") {
*nsubtype = SIGN_WARNING_ANIMALS;
} else if (t== "1010103100001111" || t== "1010103100001110" || subType == "w34") {
*nsubtype = SIGN_WARNING_ACCIDENT;
} else if (t== "1010103800001111" || t== "1010103800001110" || subType == "w53") {
*nsubtype = SIGN_WARNING_TIDALBU_LANE;
} else if (t== "1010104314001111" || t== "1010104314001110" || subType == "w51") {
*nsubtype = SIGN_WARNING_BAD_WEATHER;
} else if (t== "1010102600001111" || t== "1010102600001110" || subType == "w28") {
*nsubtype = SIGN_WARNING_LOWLYING;
} else if (t== "1010102500001111" || t== "1010102500001110" || subType == "w29") {
*nsubtype = SIGN_WARNING_HIGHLYING;
} else if (t== "1010100512001111" || t== "1010100512001110" || subType == "w41") {
*nsubtype = SIGN_WARNING_DOWNHILL;
} else if (t== "1010104400001111" || t== "1010104400001110" || subType == "w67") {
*nsubtype = SIGN_WARNING_QUEUESLIKELY;
} else if (t== "1010104011001111" || t== "1010104011001110" || subType == "w33") {
*nsubtype = SIGN_WARNING_CROSS_PLANE;
} else if (t== "1010102100001111" || t== "1010102100001110" || subType == "w37") {
*nsubtype = SIGN_WARNING_TUNNEL;
} else if (t== "1010103700001111" || t== "1010103700001110" || subType == "w38") {
*nsubtype = SIGN_WARNING_TUNNEL_LIGHT;
} else if (t== "1010102300001111" || t== "1010102300001110" || subType == "w39") {
*nsubtype = SIGN_WARNING_HUMPBACK_BRIDGE;
} else if (t== "1010100712001111" || t== "1010100712001110" || subType == "w47") {
*nsubtype = SIGN_WARNING_NARROW_RIGHT;
} else if (t== "1010102900001111" || t== "1010102900001110" || subType == "w56") {
*nsubtype = SIGN_WARNING_NON_MOTOR;
} else if (t== "1010101700001111" || t== "1010101700001110" || subType == "w44") {
*nsubtype = SIGN_WARNING_SLIPPERY;
} else if (t== "1010101400001111" || t== "1010101400001110" || subType == "w45") {
*nsubtype = SIGN_WARNING_TRIFFICLIGHT;
} else if (t== "1010103313001111" || t== "1010103313001110" || subType == "w48") {
*nsubtype = SIGN_WARNING_DETOUR_RIGHT;
} else if (t== "1010100800001111" || t== "1010100800001110" || subType == "w49") {
*nsubtype = SIGN_WARNING_NARROW_BRIDGE;
} else if (t== "1010103900001111" || t== "1010103900001110" || subType == "w50") {
*nsubtype = SIGN_WARNING_KEEP_DISTANCE;
} else if (t== "1010104111001111" || subType == "w58") {
*nsubtype = SIGN_WARNING_MERGE_LEFT;
} else if (t== "1010104111001111" || t== "1010104111001110" || subType == "w59") {
*nsubtype = SIGN_WARNING_MERGE_RIGHT;
} else if (t== "1010101600001111" || t== "1010101600001110" || subType == "w60") {
*nsubtype = SIGN_WARNING_CROSSWIND;
} else if (t== "1010104311001111" || t== "1010104311001110" || subType == "w61") {
*nsubtype = SIGN_WARNING_ICY_ROAD;
} else if (t== "1010101511001111" || t== "1010101511001110" || subType == "w62") {
*nsubtype = SIGN_WARNING_ROCKFALL;
} else if (t== "1010103400001111" || t== "1010103400001110" || subType == "w63") {
*nsubtype = SIGN_WARNING_CAUTION;
} else if (t== "1010104313001111" || t== "1010104313001110" || subType == "w54") {
*nsubtype = SIGN_WARNING_FOGGY;
} else if (t== "1010101200001111" || t== "1010101200001110" || subType == "w64") {
*nsubtype = SIGN_WARNING_LIVESTOCK;
} else if (t== "1010103312001111" || t== "1010103312001110" || subType == "w65") {
*nsubtype = SIGN_WARNING_DETOUR_LEFT;
} else if (t== "1010103311001111" || t== "1010103311001110" || subType == "w66") {
*nsubtype = SIGN_WARNING_DETOUR_BOTH;
} else if (t== "1010100900001111" || t== "1010100900001110" || subType == "w35") {
*nsubtype = SIGN_WARNING_BOTHWAY;
} else if (t== "1010202400001413" || t== "1010202400001410" || subType == "p14") {
*nsubtype = SIGN_BAN_STRAIGHT;
} else if (t== "1010200600001413" || t== "1010200600001410" || subType == "p10") {
*nsubtype = SIGN_BAN_VEHICLE;
} else if (((t== "1010203800001413" || t== "1010203800001410") && subType == "120") || subType == "pl120") {
*nsubtype = SIGN_BAN_SPPED_120;
} else if (((t== "1010203800001413" || t== "1010203800001410") && subType == "100") || subType == "pl100") {
*nsubtype = SIGN_BAN_SPPED_100;
} else if (((t== "1010203800001413" || t== "1010203800001410") && subType == "80") || subType == "pl80") {
*nsubtype = SIGN_BAN_SPPED_80;
}
if (((t== "1010203800001413" || t== "1010203800001410") && subType == "70") || subType == "pl70") {
*nsubtype = SIGN_BAN_SPPED_70;
} else if (((t== "1010203800001413" || t== "1010203800001410") && subType == "60") || subType == "pl60") {
*nsubtype = SIGN_BAN_SPPED_60;
} else if (((t== "1010203800001413" || t== "1010203800001410") && subType == "50") || subType == "pl50") {
*nsubtype = SIGN_BAN_SPPED_50;
} else if (((t== "1010203800001413" || t== "1010203800001410") && subType == "40") || subType == "pl40") {
*nsubtype = SIGN_BAN_SPPED_40;
} else if (((t== "1010203800001413" || t== "1010203800001410") && subType == "30") || subType == "pl30") {
*nsubtype = SIGN_BAN_SPPED_30;
} else if (t== "1010200100001914" || t== "1010200100001910" || subType == "ps") {
*nsubtype = SIGN_BAN_STOP_YIELD;
} else if (((t== "1010203500001413" || t== "1010203500001410") && subType == "5") || subType == "ph5") {
*nsubtype = SIGN_BAN_HEIGHT_5;
} else if (((t== "1010203800001413" || t== "1010203500001410") && subType == "20") || subType == "pl20") {
*nsubtype = SIGN_BAN_SPPED_20;
} else if (((t== "1010203800001413" || t== "1010203500001410") && subType == "5") || subType == "pl05") {
*nsubtype = SIGN_BAN_SPPED_05;
} else if (t== "1010200500001513" || t== "1010200500001510" || subType == "pne") {
*nsubtype = SIGN_BAN_DIVERINTO;
}
if (t== "1010201400001413" || t== "1010201400001410" || subType == "p12") {
*nsubtype = SIGN_BAN_MOTOR_BIKE;
} else if (((t== "1010203600001413" || t== "1010203700001410") && subType == "55") || subType == "pm55") {
*nsubtype = SIGN_BAN_WEIGHT_50;
}
if (((t== "1010203600001413" || t== "1010203700001410") && subType == "20") || subType == "pm20") {
*nsubtype = SIGN_BAN_WEIGHT_20;
} else if (t== "1010203300001413" || t== "1010203300001410" || subType == "p11") {
*nsubtype = SIGN_BAN_HONKING;
} else if (t== "1010200700001413" || t== "1010200700001410" || subType == "p26") {
*nsubtype = SIGN_BAN_TRUCK;
} else if (((t== "1010203600001413" || t== "1010203700001410") && subType == "30") || subType == "pm30") {
*nsubtype = SIGN_BAN_WEIGHT_30;
} else if (((t== "1010203600001413" || t== "1010203700001410") && subType == "10") || subType == "pm10") {
*nsubtype = SIGN_BAN_WEIGHT_10;
} else if (t== "1010203111001713" || t== "1010203111001710" || subType == "pn") {
*nsubtype = SIGN_BAN_TEMP_PARKING;
} else if (((t== "1010203700001413" || t== "1010203700001410") && subType == "14") || subType == "pa14") {
*nsubtype = SIGN_BAN_AXLE_WEIGHT_14;
} else if (((t== "1010203700001413" || t== "1010203700001410") && subType == "13") || subType == "pa13") {
*nsubtype = SIGN_BAN_AXLE_WEIGHT_13;
} else if (((t== "1010203700001413" || t== "1010203700001410") && subType == "40") || subType == "pm40") {
*nsubtype = SIGN_BAN_WEIGHT_40;
} else if (t== "1010200200002012" || t== "1010200200002010" || subType == "pg") {
*nsubtype = SIGN_BAN_SLOW;
}
if (t== "1010202211001413" || t== "1010202211001410" || subType == "p23") {
*nsubtype = SIGN_BAN_TURN_LEFT;
} else if (t== "1010204100001413" || t== "1010204100001410" || subType == "p27") {
*nsubtype = SIGN_BAN_DANGEROUS_GOODS;
} else if (t== "1010201200001413" || t== "1010201200001410" || subType == "p18") {
*nsubtype = SIGN_BAN_TRACTORS;
} else if (t== "1010201300001413" || t== "1010201300001410" || subType == "p22") {
*nsubtype = SIGN_BAN_TRICYCLE;
} else if (t== "1010201000001413" || t== "1010201000001410" || subType == "p25") {
*nsubtype = SIGN_BAN_MINIBUS;
} else if (t== "1010202600001413" || t== "1010202600001410" || subType == "p28") {
*nsubtype = SIGN_BAN_STRAIGHT_AND_LEFT;
} else if (t== "1010202000001413" || t== "1010202000001410" || subType == "p15") {
*nsubtype = SIGN_BAN_VEHICLE_BY_HUMAN;
} else if (t== "1010201800001413" || t== "1010201800001410" || subType == "p16") {
*nsubtype = SIGN_BAN_TRACYCLE01_BY_HUMAN;
} else if (t== "1010201900001413" || t== "1010201900001410" || subType == "p17") {
*nsubtype = SIGN_BAN_TRACYCLE02_BY_HUMAN;
} else if (t== "1010202311001413" || t== "1010202311001410" || subType == "p19") {
*nsubtype = SIGN_BAN_TURN_RIGHT;
} else if (t== "1010202500001413" || t== "1010202500001410" || subType == "p20") {
*nsubtype = SIGN_BAN_LEFT_AND_RIGHT;
} else if (t== "1010202700001413" || t== "1010202700001410" || subType == "p21") {
*nsubtype = SIGN_BAN_STRAIGHT_AND_RIGHT;
} else if (t== "1010200400001213" || t== "1010200400001210" || subType == "pb") {
*nsubtype = SIGN_BAN_GO;
} else if (t== "1010200300002113" || t== "1010200300002110" || subType == "pe") {
*nsubtype = SIGN_BAN_GIVE_WAY;
} else if (t== "1010202312001413" || t== "1010202312001410" || subType == "p24") {
*nsubtype = SIGN_BAN_BUS_TURN_RIGHT;
} else if (t== "1010202315001413" || t== "1010202315001410" || subType == "p31") {
*nsubtype = SIGN_BAN_TRUCK_TURN_RIGHT;
} else if (t== "1010203000001613" || t== "1010203000001610" || subType == "p30") {
*nsubtype = SIGN_BAN_NO_OVERTAKING;
} else if (t== "1010202212001413" || t== "1010202212001410" || subType == "p29") {
*nsubtype = SIGN_BAN_BUS_TURN_LEFT;
} else if (t== "1010202900001413" || t== "1010202900001410" || subType == "p1") {
*nsubtype = SIGN_BAN_OVERTAKING;
} else if (t== "1010201700001413" || t== "1010201700001410" || subType == "p2") {
*nsubtype = SIGN_BAN_ANIMALS;
} else if (t== "1010200900001413" || t== "1010200900001410" || subType == "p3") {
*nsubtype = SIGN_BAN_BUS;
} else if (t== "1010200800001413" || t== "1010200800001410" || subType == "p4") {
*nsubtype = SIGN_BAN_ELECTRO_TRICYCLE;
} else if (t== "1010201600001413" || t== "1010201600001410" || subType == "p6") {
*nsubtype = SIGN_BAN_NO_MOTOR;
} else if (t== "1010202215001413" || t== "1010202215001410" || subType == "p7") {
*nsubtype = SIGN_BAN_TRUCK_TURN_LEFT;
} else if (t== "1010201100001413" || t== "1010201100001410" || subType == "p8") {
*nsubtype = SIGN_BAN_TRAILER;
} else if (t== "1010202100001413" || t== "1010202100001410" || subType == "p9") {
*nsubtype = SIGN_BAN_HUMAN;
} else if (t== "1010201500001413" || subType == "p13") {
*nsubtype = SIGN_BAN_THE_TWO_TYPES;
} else if (((t== "1010203500001413" || t== "1010203500001410") && subType == "3.5") || subType == "ph3.5") {
*nsubtype = SIGN_BAN_HEIGHT_3_5;
} else if (((t== "1010203400001413" || t== "1010203400001410") && subType == "3") || subType == "pw3") {
*nsubtype = SIGN_BAN_HEIGHT_3;
} else if (((t== "1010203600001413" || t== "1010203700001410") && subType == "10") || subType == "pa10") {
*nsubtype = SIGN_BAN_AXLE_WEIGHT_10;
} else if (t== "1010204200001413" || t== "1010204200001410" || subType == "pd") {
*nsubtype = SIGN_BAN_CUSTOMS_MARK;
} else if (t== "1010204000001413" || t== "1010204000001410" || subType == "pc") {
*nsubtype = SIGN_BAN_STOP;
} else if (t== "1010203200001713" || t== "1010203200001710" || subType == "pnl") {
*nsubtype = SIGN_BAN_LONG_PARKING;
} else if (t== "1010203900001613" || t== "1010203900001610" || subType == "pr40") {
*nsubtype = SIGN_BAN_REMOVE_LIMIT_40;
} else if (t== "1010300100002413" || t== "1010300100002410" || subType == "i13") {
*nsubtype = SIGN_INDOCATION_STRAIGHT;
} else if (((t== "1010301500002413" || t== "1010301500002410") && subType == "60") || subType == "il60") {
*nsubtype = SIGN_INDOCATION_LOWEST_SPEED_60;
} else if (((t== "1010301500002413" || t== "1010301500002410") && subType == "40") || subType == "il40") {
*nsubtype = SIGN_INDOCATION_LOWEST_SPEED_40;
} else if (t== "1010300700002413" || t== "1010300700002410" || subType == "i5") {
*nsubtype = SIGN_INDOCATION_ALONG_RIGHT;
} else if (t== "1010301800002616" || t== "1010301800002610" || subType == "ip") {
*nsubtype = SIGN_INDOCATION_PEDESTRIAN_CROSSING;
} else if (t== "1010300300002413" || t== "1010300300002410" || subType == "i10") {
*nsubtype = SIGN_INDOCATION_TURN_RIGHT;
} else if (t== "1010301100002416" || t== "1010301100002410" || subType == "i3") {
*nsubtype = SIGN_INDOCATION_ROUNDABOUT;
} else if (t== "1010300200002413" || t== "1010300200002410" || subType == "i12") {
*nsubtype = SIGN_INDOCATION_TURN_LEFT;
} else if (t== "1010300500002413" || t== "1010300500002410" || subType == "i14") {
*nsubtype = SIGN_INDOCATION_STRAIGHT_RIGHT;
} else if (t== "1010300400002413" || t== "1010300400002410" || subType == "i15") {
*nsubtype = SIGN_INDOCATION_STRAIGHT_LEFT;
} else if (((t== "1010301500002413" || t== "1010301500002410") && subType == "50") || subType == "il50") {
*nsubtype = SIGN_INDOCATION_LOWEST_SPEED_50;
} else if (t== "1010301300002413" || t== "1010301300002410" || subType == "i1") {
*nsubtype = SIGN_INDOCATION_WALK;
} else if (t== "1010302014002413" || t== "1010302014002410" || subType == "i2") {
*nsubtype = SIGN_INDOCATION_NO_MOTOR;
} else if (t== "1010302012002413" || t== "1010302012002410" || subType == "i4") {
*nsubtype = SIGN_INDOCATION_MOTOR;
} else if (t== "1010300800002413" || t== "1010300800002410" || subType == "i6") {
*nsubtype = SIGN_INDOCATION_ALONG_LEFT;
} else if (t== "1010301000002413" || t== "1010301000002410" || subType == "i7") {
*nsubtype = SIGN_INDOCATION_PASS_STAIGHT_001;
} else if (t== "1010300900002413" || t== "1010300900002410" || subType == "i8") {
*nsubtype = SIGN_INDOCATION_PASS_STAIGHT_002;
} else if (t== "1010301400002413" || t== "1010301400002410" || subType == "i9") {
*nsubtype = SIGN_INDOCATION_WHISTLE;
} else if (t== "1010300600002413" || t== "1010300600002410" || subType == "i11") {
*nsubtype = SIGN_INDOCATION_LEFT_AND_RIGHT;
} else if (t== "1010302111002416" || t== "1010302111002410") {
*nsubtype = SIGN_INDOCATION_PARKING;
} else if (t== "1010101000001111" || t== "1010101000001110") {
*nsubtype = SIGN_WARNING_PED;
} else if (t== "1010202800001413" || t== "1010202800001410") {
*nsubtype = SIGN_BAN_UTURN;
} else {
return -1;
}
return 0;
}

// set warn type
func (t *txObject)setObjectType(name string ,typ string, subType string ,st  int ) {
if (0 == setPoleType(name, typ, t.instancePtr.Data.Type, t.instancePtr.Data.subtype)) {
// return;
} else if (0 == setTrafficType(name, typ, subType, st, t.instancePtr.Data.Type, t.instancePtr.Data.subtype)) {
// return;
} else if (len(typ)> 4 && strings.HasSuffix("1010") || st == OBJECT_SOURCE_SIGNAL) {  // warning sign
setSignType(name, typ, subType, st, t.instancePtr.Data.Type, t.instancePtr.Data.subtype);
} else if (name == "Arrow_Forward" || name == "ZS_11") {  // Arrow
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_Straight;
t.setRawTypeString("none", "-1");
} else if (name == "Arrow_Left_And_Forward" || name == "ZS_12") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_StraightLeft;
t.setRawTypeString("none", "-1");
} else if (name == "Arrow_Left" || name == "ZS_13") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_Left;
t.setRawTypeString("none", "");
} else if (name == "Arrow_Right" || name == "ZS_14") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_Right;
t.setRawTypeString("none", "");
} else if (name == "Arrow_Right_And_Forward" || name == "ZS_15") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_StraightRight;
t.setRawTypeString("none", "");
} else if (name == "Arrow_U_Turns" || name == "ZS_16") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_Uturn;
t.setRawTypeString("none", "");
} else if (name == "Arrow_Forward_And_U_Turns" || name == "ZS_17") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_StraightUturn;
t.setRawTypeString("none", "");
} else if (name == "Arrow_Left_And_U_Turns" || name == "ZS_18") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_LeftUturn;
t.setRawTypeString("none", "");
} else if (name == "Arrow_Left_And_Right" || name == "ZS_19") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_LeftRight;
t.setRawTypeString("none", "");
} else if (name == "Turn_And_Merge_Left" || name == "ZS_20") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_SkewLeft;
t.setRawTypeString("none", "");
} else if (name == "Turn_And_Merge_Right" || name == "ZS_21") {
t.instancePtr.Data.Type = OBJECT_TYPE_Arrow;
t.instancePtr.Data.subtype = Arrow_SkewRight;
t.setRawTypeString("none", "");
} else if (name == "Arrow_Turn_And_Straight") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = Arrow_TurnStraight;
t.setRawTypeString("none", "");
} else if (name == "Stop_Line" || name == "JZ_25") {  // stop line
t.instancePtr.Data.Type = OBJECT_TYPE_Stop;
t.instancePtr.Data.subtype = Stop_Line;
t.setRawTypeString("none", "-1");
} else if (name == "Stop_To_Give_Way" || name == "JZ_26") {
t.instancePtr.Data.Type = OBJECT_TYPE_Stop;
t.instancePtr.Data.subtype = Stop_Line_GiveWay;
t.setRawTypeString("none", "-1");
} else if (name == "Slow_Down_To_Give_Way" || name == "JZ_27") {
t.instancePtr.Data.Type = OBJECT_TYPE_Stop;
t.instancePtr.Data.subtype = Stop_Slow_Line_GiveWay;
t.setRawTypeString("none", "");
} else if (name == "Crosswalk_Line" || name == "ZS_04") {  // cross walk
t.instancePtr.Data.Type = OBJECT_TYPE_CrossWalk;
t.instancePtr.Data.subtype = CrossWalk_001;
t.setRawTypeString("none", "");
} else if (name == "Turn_Left_Waiting" || name == "ZS_01") {  // RoadSign
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Turn_Left_Waiting;
t.setRawTypeString("none", "");
} else if (name == "Crosswalk_Warning_Line" || name == "ZS_05") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Crosswalk_Warning_Line;
t.setRawTypeString("none", "");
} else if (name == "White_Broken_Line_Vehicle_Distance_Confirmation" || name == "ZS_07") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_White_Broken_Line;
t.setRawTypeString("none", "");
} else if (name == "White_Semicircle_Line_Vehicle_Distance_Confirmation" || name == "ZS_08") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_White_Semicircle_Line;
t.setRawTypeString("none", "");
} else if (name == "Word_Mark_100_120" || name == "ZS_22") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_100_120;
t.setRawTypeString("none", "");
} else if (name == "Word_Mark_80_100" || name == "ZS_22_2") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_80_100;
t.setRawTypeString("none", "");
} else if (name == "Non_Motor_Vehicle" || name == "ZS_23") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Non_Motor_Vehicle;
t.setRawTypeString("none", "");
} else if (name == "Disabled_Parking_Space_Road_Mark" || name == "ZS_24") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Disable_Parking;
t.setRawTypeString("none", "");
} else if (name == "Lateral_Deceleration_Marking" || name == "JG_38") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Lateral_Dec;
t.setRawTypeString("none", "");
} else if (name == "Longitudinal_Deceleration_Marking" || name == "JG_39") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Longitudinal_Dec;
t.setRawTypeString("none", "");
} else if (name == "Circular_Center_Circle" || name == "JZ_29") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Circular_Center;
t.setRawTypeString("none", "");
} else if (name == "Rhombus_Center_Circle" || name == "JZ_30") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Rhombus_Center;
t.setRawTypeString("none", "");
} else if (name == "Mesh_Line" || name == "JZ_31") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Mesh_Line;
t.setRawTypeString("none", "");
} else if (name == "Bus_Only_Lane_Line" || name == "JZ_32") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_BusOnly;
t.setRawTypeString("none", "");
} else if (name == "Small_Cars_Lane_Line" || name == "JZ_33") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_SmallCarOnly;
t.setRawTypeString("none", "");
} else if (name == "Big_Cars_Lane_Line" || name == "JZ_34") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_BigCarOnly;
t.setRawTypeString("none", "");
} else if (name == "Non_Motor_Vehicle_Line" || name == "JZ_35") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Non_Motor_Vehicle_Line;
t.setRawTypeString("none", "");
} else if (name == "Turning_Forbidden" || name == "JZ_37") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Turning_Forbidden;
t.setRawTypeString("none", "");
} else if (name == "White_Semicircle_Line") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_White_Semicircle_Line;
t.setRawTypeString("none", "");
} else if (name == "Crosswalk_with_Left_and_Right_Side") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Crosswalk_with_Left_and_Right_Side;
t.setRawTypeString("none", "");
} else if (name == "Road_Guide_Lane_Line") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Road_Guide_Lane_Line;
t.setRawTypeString("none", "");
} else if (name == "Variable_Direction_Lane_Line") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Variable_Direction_Lane_Line;
t.setRawTypeString("none", "");
} else if (name == "Intersection_Guide_Line") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Intersection_Guide_Line;
t.setRawTypeString("none", "");
} else if (name == "U_Turning_Forbidden") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_U_Turning_Forbidden;
t.setRawTypeString("none", "");
} else if (name == "Non_Motor_Vehicle_Area") {
t.instancePtr.Data.Type = OBJECT_TYPE_RoadSign;
t.instancePtr.Data.subtype = RoadSign_Non_Motor_Vehicle_Area;
t.setRawTypeString("none", "");
} else if (name == "D_001" || name == "Pothole") {  // road surtface
t.instancePtr.Data.Type = OBJECT_TYPE_Surface;
t.instancePtr.Data.subtype = Surface_Pothole;
} else if (name == "D_002" || name == "Patch") {
t.instancePtr.Data.Type = OBJECT_TYPE_Surface;
t.instancePtr.Data.subtype = Surface_Patch;
} else if (name == "D_003" || name == "Crack") {
t.instancePtr.Data.Type = OBJECT_TYPE_Surface;
t.instancePtr.Data.subtype = Surface_Crack;
} else if (name == "D_004" || name == "Asphalt_Line") {
t.instancePtr.Data.Type = OBJECT_TYPE_Surface;
t.instancePtr.Data.subtype = Surface_Asphalt_Line;
} else if (name == "D_005" || name == "Rut_Track") {
t.instancePtr.Data.Type = OBJECT_TYPE_Surface;
t.instancePtr.Data.subtype = Surface_Rut_Track;
} else if (name == "D_006" || name == "Stagnant_Water") {
t.instancePtr.Data.Type = OBJECT_TYPE_Surface;
t.instancePtr.Data.subtype = Surface_Stagnant_Water;
} else if (name == "J_003" || name == "Protrusion") {
t.instancePtr.Data.Type = OBJECT_TYPE_Surface;
t.instancePtr.Data.subtype = Surface_Protrusion;
} else if (name == "J_001" || name == "Well_Cover") {
t.instancePtr.Data.Type = OBJECT_TYPE_Surface;
t.instancePtr.Data.subtype = Surface_Well_Cover;
} else if (name == "J_002" || name == "Deceleration_Zone") {
t.instancePtr.Data.Type = OBJECT_TYPE_SpeedBump;
t.instancePtr.Data.subtype = SpeedBump_001;
} else if (name == "J_004" || name == "Reflective_Road_Sign") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Reflective_Road_Sign;
} else if (name == "J_005" || name == "Parking_Hole") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Parking_Hole;
} else if (name == "J_006" || name == "Parking_Lot") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Parking_Lot;
} else if (name == "J_007" || name == "Ground_Lock") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Ground_Lock;
} else if (name == "J_008" || name == "Plastic_Vehicle_Stopper") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Plastic_Vehicle_Stopper;
} else if (name == "J_009" || name == "Parking_Limit_Position_Pole_2m") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Parking_Limit_Position_Pole_2m;
} else if (name == "J_010" || name == "Support_Vehicle_Stopper") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Support_Vehicle_Stopper;
} else if (name == "J_014" || name == "Charging_Station") {
t.instancePtr.Data.Type = OBJECT_TYPE_ChargingPile;
t.instancePtr.Data.subtype = ChargingPile_001;
} else if (name == "J_011" || name == "Tree") {
t.instancePtr.Data.Type = OBJECT_TYPE_Tree;
t.instancePtr.Data.subtype = Tree_001;
} else if (name == "Shrub") {
t.instancePtr.Data.Type = OBJECT_TYPE_Tree;
t.instancePtr.Data.subtype = Shrub_001;
} else if (name == "Grass") {
t.instancePtr.Data.Type = OBJECT_TYPE_Tree;
t.instancePtr.Data.subtype = Grass_001;
} else if (name == "J_012" || name == "Building") {
t.instancePtr.Data.Type = OBJECT_TYPE_Building;
t.instancePtr.Data.subtype = Building_001;
} else if (name == "J_013" || name == "BusStation") {
t.instancePtr.Data.Type = OBJECT_TYPE_BusStation;
t.instancePtr.Data.subtype = BusStation_001;
} else if (name == "Traffic_Barrier") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Traffic_Barrier;
} else if (name == "Road_Curb") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Road_Curb;
} else if (name == "Lamp") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Lamp;
} else if (name == "Traffic_Cone") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Traffic_Cone;
} else if (name == "Traffic_Horse") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Traffic_Horse;
} else if (name == "GarbageCan") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_GarbageCan;
} else if (name == "Obstacle") {
t.instancePtr.Data.Type = OBJECT_TYPE_Obstacle;
t.instancePtr.Data.subtype = Obstacle_Obstacle;
} else if (subType == "l1" || type == "parkingSpace" || type == "parking" || st == OBJECT_SOURCE_PARKING) {
t.instancePtr.Data.Type = OBJECT_TYPE_ParkingSpace;
if (name == "Parking_Space_Mark") {
t.instancePtr.Data.subtype = Parking_Space_001;
} else if (name == "Parking_6m") {
t.instancePtr.Data.subtype = Parking_Space_003;
} else if (name == "Parking_5m") {
t.instancePtr.Data.subtype = Parking_Space_004;
} else if (name == "Parking_45deg") {
t.instancePtr.Data.subtype = Parking_Space_005;
} else if (name == "Parking_60deg") {
t.instancePtr.Data.subtype = Parking_Space_006;
} else if (name == "Time_Limit_Parking_Space_Mark") {
t.instancePtr.Data.subtype = Parking_Space_002;
} else {
t.instancePtr.Data.subtype = Parking_Space_001;
}
}
// other object(tadsim 1.0 is signals  but tadsim 2.0 is object)
if (subType == "camera" || name == "Camera") {
t.instancePtr.Data.Type = OBJECT_TYPE_V2X_Sensor;
t.instancePtr.Data.subtype = Sensors_Camera;
} else if (subType == "radar" || name == "Millimeter_Wave_Radar") {
t.instancePtr.Data.Type = OBJECT_TYPE_V2X_Sensor;
t.instancePtr.Data.subtype = Sensors_Radar;
} else if (subType == "rsu" || name == "RSU") {
t.instancePtr.Data.Type = OBJECT_TYPE_V2X_Sensor;
t.instancePtr.Data.subtype = Sensors_RSU;
} else if (name == "Lidar") {
t.instancePtr.Data.Type = OBJECT_TYPE_V2X_Sensor;
t.instancePtr.Data.subtype = Sensors_Lidar;
} else if (typ == "custom") {
t.instancePtr.Data.Type = OBJECT_TYPE_Custom;
t.instancePtr.Data.subtype = CustomSubType;
} else if (name == "Tunnel") {
t.instancePtr.Data.Type = OBJECT_TYPE_Tunnel;
t.instancePtr.Data.subtype = Tunnel_001;
} else if (name == "PedestrianBridge") {
t.instancePtr.Data.Type = OBJECT_TYPE_PedestrianBridge;
t.instancePtr.Data.subtype = PedestrianBridge;
}

t.instancePtr.od_data.type = t.instancePtr.Data.Type;
t.instancePtr.od_data.subtype = t.instancePtr.Data.subtype;
t.setRawTypeString(typ, subType);
    t.instancePtr.Data.name = name
    t.instancePtr.od_data.name = name
    copy(t.instancePtr.Data.Name, name)
    copy(t.instancePtr.OdData.Name, name)
//strcpy(t.instancePtr.Data.name, name.c_str());
//strcpy(t.instancePtr.od_data.name, name.c_str());
}
func getPole(dataSubtype uint32, name *string, typeP *string, subtype *string) {
    switch dataSubtype {
    case OtherSubtype:
        return
    case POLE_VERTICAL:
        *name = "Vertical_Pole"
        *typeP = "pole"
        *subtype = "none"
    case POLE_CROSS:
        *name = "Cross_Pole"
        *typeP = "pole"
        *subtype = "none"
    case POLE_Cantilever:
        *name = "Cantilever_Pole"
        *typeP = "pole"
        *subtype = "none"
    case POLE_Pillar_6m:
        *name = "Pillar_Pole_6m"
        *typeP = "pole"
        *subtype = "none"
    case POLE_Pillar_3m:
        *name = "Pillar_Pole_3m"
        *typeP = "pole"
        *subtype = "none"
    default:
        return
    }
}


// get SIGN_WARNING Type
func getSign(data_subtype uint32, name string, type_ string, subtype string) {
    name = "null"
    subtype = "-1"
    switch data_subtype {
    case SIGN_WARNING_SLOWDOWN:
        type_ = "1010103200001111"
        break
    case SIGN_WARNING_TURNLEFT:
        type_ = "1010100211001111"
        break
    case SIGN_WARNING_TURNRIGHT:
        type_ = "1010100212001111"
        break
    case SIGN_WARNING_T_RIGHT:
        type_ = "1010100121001111"
        break
    case SIGN_WARNING_T_DOWN:
        type_ = "1010100123001111"
        break
    case SIGN_WARNING_CROSS:
        type_ = "1010100111101111"
        break
    case SIGN_WARNING_CHILD:
        type_ = "1010101100001111"
        break
    case SIGN_WARNING_UP:
        type_ = "1010100511001111"
        break
    case SIGN_WARNING_BUILDING:
        type_ = "1010103500001111"
        break
    case SIGN_WARNING_NARROW_LEFT:
        type_ = "1010100711001111"
        break
    case SIGN_WARNING_NARROW_BOTH:
        type_ = "1010100713001111"
        break
    case SIGN_WARNING_RAILWAY:
        type_ = "1010102812001111"
        break
    case SIGN_WARNING_T_LEFT:
        type_ = "1010100122001111"
        break
    case SIGN_WARNING_STEEP_LEFT:
        type_ = "1010101811001111"
        break
    case SIGN_WARNING_STEEP_RIGHT:
        type_ = "1010101812001111"
        break
    case SIGN_WARNING_VILLAGE:
        type_ = "1010102000001111"
        break
    case SIGN_WARNING_DIKE_LEFT:
        type_ = "1010101911001111"
        break
    case SIGN_WARNING_DIKE_RIGHT:
        type_ = "1010101912001111"
        break
    case SIGN_WARAING_T_CROSSED:
        type_ = "1010104012001111"
        break
    case SIGN_WARAING_FERRY:
        type_ = "1010102200001111"
        break
    case SIGN_WARAING_FALL_ROCK:
        type_ = "1010101512001111"
        break
    case SIGN_WARAING_REVERSE_CURVE_LEFT:
        type_ = "1010100311001111"
        break
    case SIGN_WARAING_REVERSE_CURVE_RIGHT:
        type_ = "1010100312001111"
        break
    case SIGN_WARAING_WATER_PAVEMENT:
        type_ = "1010102700001111"
        break
    case SIGN_WARNING_T_BOTH:
        type_ = "1010100112001111"
        break
    case SIGN_WARNING_JOIN_LEFT:
        type_ = "1010100131001111"
        break
    case SIGN_WARNING_JOIN_RIGHT:
        type_ = "1010100132001111"
        break
    case SIGN_WARNING_Y_LEFT:
        type_ = "1010100134001111"
        break
    case SIGN_WARNING_Y_RIGHT:
        type_ = "1010100134001111"
        break
    case SIGN_WARNING_CIRCLE_CROSS:
        type_ = "1010100141001111"
        break
    case SIGN_WARNING_CURVE_AHEAD:
        type_ = "1010100400001111"
        break
    case SIGN_WARNING_LONG_DESCENT:
        type_ = "1010100600001111"
        break
    case SIGN_WARNING_ROUGH_ROAD:
        type_ = "1010102400001111"
        break
    case SIGN_WARNING_SNOW:
        type_ = "1010104312001111"
        break
    case SIGN_WARNING_DISABLE:
        type_ = "1010103000001111"
        break
    case SIGN_WARNING_ANIMALS:
        type_ = "1010101300001111"
        break
    case SIGN_WARNING_ACCIDENT:
        type_ = "1010103100001111"
        break
    case SIGN_WARNING_TIDALBU_LANE:
        type_ = "1010103800001111"
        break
    case SIGN_WARNING_BAD_WEATHER:
        type_ = "1010104314001111"
        break
    case SIGN_WARNING_LOWLYING:
        type_ = "1010102600001111"
        break
    case SIGN_WARNING_HIGHLYING:
        type_ = "1010102500001111"
        break
    case SIGN_WARNING_DOWNHILL:
        type_ = "1010100512001111"
        break
    case SIGN_WARNING_QUEUESLIKELY:
        type_ = "1010104400001111"
        break
    case SIGN_WARNING_CROSS_PLANE:
        type_ = "1010104011001111"
        break
    case SIGN_WARNING_TUNNEL:
        type_ = "1010102100001111"
        break
    case SIGN_WARNING_TUNNEL_LIGHT:
        type_ = "1010103700001111"
        break
    case SIGN_WARNING_HUMPBACK_BRIDGE:
        type_ = "1010102300001111"
        break
    case SIGN_WARNING_NARROW_RIGHT:
        type_ = "1010100712001111"
        break
    case SIGN_WARNING_NON_MOTOR:
        type_ = "1010102900001111"
        break
    case SIGN_WARNING_SLIPPERY:
        type_ = "1010101700001111"
        break
    case SIGN_WARNING_TRIFFICLIGHT:
        type_ = "1010101400001111"
        break
    case SIGN_WARNING_DETOUR_RIGHT:
        type_ = "1010103313001111"
        break
    case SIGN_WARNING_NARROW_BRIDGE:
        type_ = "1010100800001111"
        break
    case SIGN_WARNING_KEEP_DISTANCE:
        type_ = "1010103900001111"
        break
    case SIGN_WARNING_MERGE_LEFT:
        type_ = "1010104111001111"
        break
    case SIGN_WARNING_CROSSWIND:
        type_ = "1010101600001111"
        break
    case SIGN_WARNING_ICY_ROAD:
        type_ = "1010104311001111"
        break
    case SIGN_WARNING_ROCKFALL:
        type_ = "1010101511001111"
        break
    case SIGN_WARNING_CAUTION:
        type_ = "1010103400001111"
        break
    case SIGN_WARNING_FOGGY:
        type_ = "1010104313001111"
        break
    case SIGN_WARNING_LIVESTOCK:
        type_ = "1010101200001111"
        break
    case SIGN_WARNING_DETOUR_LEFT:
        type_ = "1010103312001111"
        break
    case SIGN_WARNING_DETOUR_BOTH:
        type_ = "1010103311001111"
        break
    case SIGN_WARNING_BOTHWAY:
        type_ = "1010100900001111"
        break
    case SIGN_BAN_STRAIGHT:
        type_ = "1010202400001413"
        break
    case SIGN_BAN_VEHICLE:
        type_ = "1010200600001413"
        break
    case SIGN_BAN_SPPED_120:
        type_ = "1010203800001413"
        subtype = "120"
        break
    case SIGN_BAN_SPPED_100:
        type_ = "1010203800001413"
        subtype = "100"
        break
    case SIGN_BAN_SPPED_80:
        type_ = "1010203800001413"
        subtype = "80"
        break
    case SIGN_BAN_SPPED_70:
        type_ = "1010203800001413"
        subtype = "70"
        break
    case SIGN_BAN_SPPED_60:
        type_ = "1010203800001413"
        subtype = "60"
        break
    case SIGN_BAN_SPPED_50:
        type_ = "1010203800001413"
        subtype = "50"
        break
    case SIGN_BAN_SPPED_40:
        type_ = "1010203800001413"
        subtype = "40"
        break
    case SIGN_BAN_SPPED_30:
        type_ = "1010203800001413"
        subtype = "30"
        break
    case SIGN_BAN_STOP_YIELD:
        type_ = "1010200100001914"
        break
    case SIGN_BAN_HEIGHT_5:
        type_ = "1010203500001413"
        subtype = "5"
        break
    case SIGN_BAN_SPPED_20:
        type_ = "1010203800001413"
        subtype = "20"
        break
    case SIGN_BAN_SPPED_05:
        type_ = "1010203800001413"
        subtype = "5"
        break
    case SIGN_BAN_DIVERINTO:
        type_ = "1010200500001513"
        break
    case SIGN_BAN_MOTOR_BIKE:
        type_ = "1010201400001413"
        break
    case SIGN_BAN_WEIGHT_50:
        type_ = "1010203600001413"
        subtype = "55"
        break
    case SIGN_BAN_WEIGHT_20:
        type_ = "1010203600001413"
        subtype = "20"
        break
    case SIGN_BAN_HONKING:
        type_ = "1010203300001413"
        break
    case SIGN_BAN_TRUCK:
        type_ = "1010200700001413"
        break
    case SIGN_BAN_WEIGHT_30:
        type_ = "1010203600001413"
        subtype = "30"
        break
    case SIGN_BAN_WEIGHT_10:
        type_ = "1010203600001413"
        subtype = "10"
        break
    case SIGN_BAN_TEMP_PARKING:
        type_ = "1010203111001713"
        break
    case SIGN_BAN_AXLE_WEIGHT_14:
        type_ = "1010203700001413"
        subtype = "14"
        break
    case SIGN_BAN_AXLE_WEIGHT_13:
        type_ = "1010203700001413"
        subtype = "13"
        break
    case SIGN_BAN_WEIGHT_40:
        type_ = "1010203700001413"
        subtype = "40"
        break
    case SIGN_BAN_SLOW:
        type_ = "1010200200002012"
        break
    case SIGN_BAN_TURN_LEFT:
        type_ = "1010202211001413"
        break
    case SIGN_BAN_DANGEROUS_GOODS:
        type_ = "1010204100001413"
        break
    case SIGN_BAN_TRACTORS:
        type_ = "1010201200001413"
        break
    case SIGN_BAN_TRICYCLE:
        type_ = "1010201300001413"
        break
    case SIGN_BAN_MINIBUS:
        type_ = "1010201000001413"
        break
    case SIGN_BAN_STRAIGHT_AND_LEFT:
        type_ = "1010202600001413"
        break
    case SIGN_BAN_VEHICLE_BY_HUMAN:
        type_ = "1010202000001413"
        break
    case SIGN_BAN_TRACYCLE01_BY_HUMAN:
        type_ = "1010201800001413"
        break
    case SIGN_BAN_TRACYCLE02_BY_HUMAN:
        type_ = "1010201900001413"
        break
    case SIGN_BAN_TURN_RIGHT:
        type_ = "1010202311001413"
        break
    case SIGN_BAN_LEFT_AND_RIGHT:
        type_ = "1010202500001413"
        break
    case SIGN_BAN_STRAIGHT_AND_RIGHT:
        type_ = "1010202700001413"
        break
    case SIGN_BAN_GO:
        type_ = "1010200400001213"
        break
    case SIGN_BAN_GIVE_WAY:
        type_ = "1010200300002113"
        break
    case SIGN_BAN_BUS_TURN_RIGHT:
        type_ = "1010202312001413"
        break
    case SIGN_BAN_TRUCK_TURN_RIGHT:
        type_ = "1010202315001413"
        break
    case SIGN_BAN_NO_OVERTAKING:
        type_ = "1010203000001613"
        break
    case SIGN_BAN_BUS_TURN_LEFT:
        type_ = "1010202212001413"
        break
    case SIGN_BAN_OVERTAKING:
        type_ = "1010202900001413"
        break
    case SIGN_BAN_ANIMALS:
        type_ = "1010201700001413"
        break
    case SIGN_BAN_BUS:
        type_ = "1010200900001413"
        break
    case SIGN_BAN_ELECTRO_TRICYCLE:
        type_ = "1010200800001413"
        break
    case SIGN_BAN_NO_MOTOR:
        type_ = "1010201600001413"
        break
    case SIGN_BAN_TRUCK_TURN_LEFT:
        type_ = "1010202215001413"
        break
    case SIGN_BAN_TRAILER:
        type_ = "1010201100001413"
        break
    case SIGN_BAN_HUMAN:
        type_ = "1010202100001413"
        break
    case SIGN_BAN_THE_TWO_TYPES:
        type_ = "1010201500001413"
        break
    case SIGN_BAN_HEIGHT_3_5:
        type_ = "1010203500001413"
        subtype = "3.5"
        break
    case SIGN_BAN_HEIGHT_3:
        type_ = "1010203400001413"
        subtype = "3"
        break
    case SIGN_BAN_AXLE_WEIGHT_10:
        type_ = "1010203600001413"
        subtype = "10"
        break
    case SIGN_BAN_CUSTOMS_MARK:
        type_ = "1010204200001413"
        break
    case SIGN_BAN_STOP:
        type_ = "1010204000001413"
        break
    case SIGN_BAN_LONG_PARKING:
        type_ = "1010203200001713"
        break
    case SIGN_BAN_REMOVE_LIMIT_40:
        type_ = "1010203900001613"
        break
    case SIGN_INDOCATION_STRAIGHT:
        type_ = "1010300100002413"
        break
    case SIGN_INDOCATION_LOWEST_SPEED_60:
        type_ = "1010301500002413"
        subtype = "60"
        break
    case SIGN_INDOCATION_LOWEST_SPEED_40:
        type_ = "1010301500002413"
        subtype = "40"
        break
    case SIGN_INDOCATION_ALONG_RIGHT:
        type_ = "1010300700002413"
        break
    case SIGN_INDOCATION_PEDESTRIAN_CROSSING:
        type_ = "1010301800002616"
        break
    case SIGN_INDOCATION_TURN_RIGHT:
        type_ = "1010300300002413"
        break
    case SIGN_INDOCATION_ROUNDABOUT:
        type_ = "1010301100002416"
        break
    case SIGN_INDOCATION_TURN_LEFT:
        type_ = "1010300200002413"
        break
    case SIGN_INDOCATION_STRAIGHT_RIGHT:
        type_ = "1010300500002413"
        break
    case SIGN_INDOCATION_STRAIGHT_LEFT:
        type_ = "1010300400002413"
        break
    case SIGN_INDOCATION_LOWEST_SPEED_50:
        type_ = "1010301500002413"
        subtype = "50"
        break
    case SIGN_INDOCATION_WALK:
        type_ = "1010301300002413"
        break
    case SIGN_INDOCATION_NO_MOTOR:
        type_ = "1010302014002413"
        break
    case SIGN_INDOCATION_MOTOR:
        type_ = "1010302012002413"
        break
    case SIGN_INDOCATION_ALONG_LEFT:
        type_ = "1010300800002413"
        break
    case SIGN_INDOCATION_PASS_STAIGHT_001:
        type_ = "1010301000002413"
        break
    case SIGN_INDOCATION_PASS_STAIGHT_002:
        type_ = "1010300900002413"
        break
    case SIGN_INDOCATION_WHISTLE:
        type_ = "1010301400002413"
        break
    case SIGN_INDOCATION_LEFT_AND_RIGHT:
        type_ = "1010300600002413"
        break
    case SIGN_BAN_UTURN:
        type_ = "1010202800001413"
        break
    case SIGN_WARNING_PED:
        type_ = "1010101000001111"
        break
    case SIGN_INDOCATION_PARKING:
        type_ = "1010302111002416"
        break
    default:
        break
    }
}

func getRoadSign(data_subtype uint32, name *string, typeStr *string, subtype *string) {
    *typeStr = "null"
    *subtype = "-1"
    switch data_subtype {
    case RoadSign_Turn_Left_Waiting:
        *name = "Turn_Left_Waiting"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Crosswalk_Warning_Line:
        *name = "Crosswalk_Warning_Line"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_White_Broken_Line:
        *name = "White_Broken_Line_Vehicle_Distance_Confirmation"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_White_Semicircle_Line:
        *name = "White_Semicircle_Line_Vehicle_Distance_Confirmation"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Disable_Parking:
        *name = "Disabled_Parking_Space_Road_Mark"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Lateral_Dec:
        *name = "Lateral_Deceleration_Marking"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Longitudinal_Dec:
        *name = "Longitudinal_Deceleration_Marking"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_100_120:
        *name = "Word_Mark_100_120"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_80_100:
        *name = "Word_Mark_80_100"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Non_Motor_Vehicle:
        *name = "Non_Motor_Vehicle"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Circular_Center:
        *name = "Circular_Center_Circle"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Rhombus_Center:
        *name = "Rhombus_Center_Circle"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Mesh_Line:
        *name = "Mesh_Line"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_BusOnly:
        *name = "Bus_Only_Lane_Line"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_SmallCarOnly:
        *name = "Small_Cars_Lane_Line"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_BigCarOnly:
        *name = "Big_Cars_Lane_Line"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Non_Motor_Vehicle_Line:
        *name = "Non_Motor_Vehicle_Line"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Turning_Forbidden:
        *name = "Turning_Forbidden"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Crosswalk_with_Left_and_Right_Side:
        *name = "Crosswalk_with_Left_and_Right_Side"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Road_Guide_Lane_Line:
        *name = "Road_Guide_Lane_Line"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Variable_Direction_Lane_Line:
        *name = "Variable_Direction_Lane_Line"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Intersection_Guide_Line:
        *name = "Intersection_Guide_Line"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_U_Turning_Forbidden:
        *name = "U_Turning_Forbidden"
        *typeStr = "none"
        *subtype = ""
    case RoadSign_Non_Motor_Vehicle_Area:
        *name = "Non_Motor_Vehicle_Area"
        *typeStr = "none"
        *subtype = ""
    }
}

func (t *txObject) getObjectFromatType(name, type_, subtype *string) {
    if t.instancePtr.data.subtype >= POLE_VERTICAL && t.instancePtr.data.subtype < POLE_VERTICAL+nSingleObjectTypeNumMax {
        t.getPole(t.instancePtr.data.subtype, name, type, subtype)
    } else if t.instancePtr.data.subtype >= SIGN_WARNING_SLOWDOWN && t.instancePtr.data.subtype < SIGN_WARNING_SLOWDOWN+nSingleSignTypeNumMax {
        t.getSign(t.instancePtr.data.subtype, name, type, subtype)
    } else if t.instancePtr.data.subtype >= RoadSign_Turn_Left_Waiting && t.instancePtr.data.subtype < RoadSign_Turn_Left_Waiting+nSingleObjectTypeNumMax {
        t.getRoadSign(t.instancePtr.data.subtype, name, type, subtype)
    } else {
        switch t.instancePtr.data.subtype {
        case OtherSubtype:
            return
        case LIGHT_VERTICAL_ALLDIRECT:
            *name = "verticalOmnidirectionalLight"
            *type_ = "1000001"
            *subtype = "-1"
        case LIGHT_VERTICAL_STRAIGHTROUND:
            *name = "verticalStraightRoundLight"
            *type_ = "1000011"
            *subtype = "60"
        case LIGHT_VERTICAL_LEFTTURN:
            *name = "verticalLeftTurnLigh"
            *type_ = "1000011"
            *subtype = "10"
        case LIGHT_VERTICAL_STRAIGHT:
            *name = "verticalStraightLight"
            *type_ = "1000011"
            *subtype = "30"
        case LIGHT_VERTICAL_RIGHTTURN:
            *name = "verticalRightTurnLight"
            *type_ = "1000011"
            *subtype = "20"
        case LIGHT_VERTICAL_UTURN:
            *name = "verticalUTurnLigh"
            *type_ = "1000011"
            *subtype = "70"
        case LIGHT_HORIZON_PEDESTRIAN:
            *name = "verticalPedestrianLight"
            *type_ = "1000002"
            *subtype = "-1"
        case LIGHT_HORIZON_ALLDIRECT:
            *name = "horizontalOmnidirectionalLight"
            *type_ = "1000003"
            *subtype = "-1"
        case LIGHT_HORIZON_STRAIGHTROUND:
            *name = "horizontalStraightRoundLight"
            *type_ = "1000021"
            *subtype = "60"
        case LIGHT_HORIZON_LEFTTURN:
            *name = "horizontalLeftTurnLight"
            *type_ = "1000021"
            *subtype = "10"
        case LIGHT_HORIZON_STRAIGHT:
            *name = "horizontalStraightLight"
            *type_ = "1000021"
            *subtype = "30"
        case LIGHT_HORIZON_RIGHTTURN:
            *name = "horizontalRightTurnLight"
            *type_ = "1000021"
            *subtype = "20"
        case LIGHT_HORIZON_UTURN:
            *name = "horizontalUTurnLight"
            *type_ = "1000021"
            *subtype = "70"
        case LIGHT_BICYCLELIGHT:
            *name = "bicycleLight"
            *type_ = "1000013"
            *subtype = "-1"
        case LIGHT_TWOCOLOR:
            *name = "twoColorIndicatorLight"
            *type_ = "1000009"
            *subtype = "-1"
        case CrossWalk_001:
            *name = "Crosswalk_Line"
            *type_ = "none"
            *subtype = ""
        case Arrow_Straight:
            *name = "Arrow_Forward"
            *type_ = "none"
            *subtype = ""
        case Arrow_StraightLeft:
            *name = "Arrow_Left_And_Forward"
            *type_ = "none"
            *subtype = ""
        case Arrow_Left:
            *name = "Arrow_Left"
            *type_ = "none"
            *subtype = ""
        case Arrow_Right:
            *name = "Arrow_Right"
            *type_ = "none"
            *subtype = ""
        case Arrow_StraightRight:
            *name = "Arrow_Right_And_Forward"
            *type_ = "none"
            *subtype = ""
        case Arrow_Uturn:
            *name = "Arrow_U_Turns"
            *type_ = "none"
            *subtype = ""
        case Arrow_StraightUturn:
            *name = "Arrow_Forward_And_U_Turns"
            *type_ = "none"
            *subtype = ""
        case Arrow_LeftUturn:
            *name = "Arrow_Left_And_U_Turns"
            *type_ = "none"
            *subtype = ""
        case Arrow_LeftRight:
            *name = "Arrow_Left_And_Right"
            *type_ = "none"
            *subtype = ""
        case Arrow_TurnStraight:
            *name = "Arrow_Turn_And_Straight"
            *type_ = "none"
            *subtype = ""
        case Arrow_SkewLeft:
            *name = "Turn_And_Merge_Left"
            *type_ = "none"
            *subtype = ""
        case Arrow_SkewRight:
            *name = "Turn_And_Merge_Right"
            *type_ = "none"
            *subtype = ""
        case Stop_Line:
            *name = "Stop_Line"
            *type_ = "none"
            *subtype = ""
        case Stop_Line_GiveWay:
            *name = "Stop_To_Give_Way"
            *type_ = "none"
            *subtype = ""
        case Stop_Slow_Line_GiveWay:
            *name = "Slow_Down_To_Give_Way"
            *type_ = "none"
            *subtype = ""
        case Parking_Space_001:
            *name = "Parking_Space_Mark"
            *type_ = "parkingSpace"
            *subtype = ""
        case Parking_Space_002:
            *name = "Time_Limit_Parking_Space_Mark"
            *type_ = "parkingSpace"
            *subtype = ""
        case Parking_Space_003:
            *name = "Parking_6m"
            *type_ = "parkingSpace"
            *subtype = ""
        case Parking_Space_004:
            *name = "Parking_5m"
            *type_ = "parkingSpace"
            *subtype = ""
        case Parking_Space_005:
            *name = "Parking_45deg"
            *type_ = "parkingSpace"
            *subtype = ""
        case Parking_Space_006:
            *name = "Parking_60deg"
            *type_ = "parkingSpace"
            *subtype = ""
        case Sensors_Camera:
            *name = "Camera"
            *type_ = "none"
            *subtype = ""
        case Sensors_Radar:
            *name = "Millimeter_Wave_Radar"
            *type_ = "none"
            *subtype = ""
        case Sensors_RSU:
            *name = "RSU"
            *type_ = "none"
            *subtype = ""
        case Sensors_Lidar:
            *name = "Lidar"
            *type_ = "none"
            *subtype = ""
        case Surface_Pothole:
            *name = "Pothole"
            *type_ = "none"
            *subtype = ""
        case Surface_Patch:
            *name = "Patch"
            *type_ = "patch"
            *subtype = ""
        case Surface_Crack:
            *name = "Crack"
            *type_ = "barrier"
            *subtype = ""
        case Surface_Asphalt_Line:
            *name = "Asphalt_Line"
            *type_ = "none"
            *subtype = ""
        case Surface_Rut_Track:
            *name = "Rut_Track"
            *type_ = "none"
            *subtype = ""
        case Surface_Stagnant_Water:
            *name = "Stagnant_Water"
            *type_ = "none"
            *subtype = ""
        case Surface_Protrusion:
            *name = "Protrusion"
            *type_ = "obstacle"
            *subtype = ""
        case Surface_Well_Cover:
            *name = "Well_Cover"
            *type_ = "none"
            *subtype = ""
        case SpeedBump_001:
            *name = "Deceleration_Zone"
            *type_ = "barrier"
            *subtype = ""
        case Obstacle_Reflective_Road_Sign:
            *name = "Reflective_Road_Sign"
            *type_ = "barrier"
            *subtype = ""
        case Obstacle_Parking_Hole:
            *name = "Parking_Hole"
            *type_ = "barrier"
            *subtype = ""
        case Obstacle_Parking_Lot:
            *name = "Parking_Lot"
            *type_ = "barrier"
            *subtype = ""
        case Obstacle_Ground_Lock:
            *name = "Ground_Lock"
            *type_ = "barrier"
            *subtype = ""
        case Obstacle_Plastic_Vehicle_Stopper:
            *name = "Plastic_Vehicle_Stopper"
            *type_ = "barrier"
            *subtype = ""
        case Obstacle_Parking_Limit_Position_Pole_2m:
            *name = "Parking_Limit_Position_Pole_2m"
            *type_ = "barrier"
            *subtype = ""
        case Obstacle_Traffic_Barrier:
            *name = "Traffic_Barrier"
            *type_ = "obstacle"
            *subtype = ""
        case Obstacle_Road_Curb:
            *name = "Road_Curb"
            *type_ = "barrier"
            *subtype = ""
        case Obstacle_Lamp:
            *name = "Lamp"
            *type_ = "none"
            *subtype = ""
        case Obstacle_Traffic_Cone:
            *name = "Traffic_Cone"
            *type_ = "obstacle"
            *subtype = ""
        case Obstacle_Traffic_Horse:
            *name = "Traffic_Horse"
            *type_ = "obstacle"
            *subtype = ""
        case Obstacle_GarbageCan:
            *name = "GarbageCan"
            *type_ = "obstacle"
            *subtype = ""
        case Obstacle_Obstacle:
            *name = "Obstacle"
            *type_ = "obstacle"
            *subtype = ""
        case Obstacle_Support_Vehicle_Stopper:
            *name = "Support_Vehicle_Stopper"
            *type_ = "barrier"
            *subtype = ""
        case ChargingPile_001:
            *name = "Charging_Station"
            *type_ = "barrier"
            *subtype = ""
        case Tree_001:
            *name = "Tree"
            *type_ = "tree"
            *subtype = ""
        case Shrub_001:
            *name = "Shrub"
            *type_ = "vegetation"
            *subtype = ""
        case Grass_001:
            *name = "Grass"
            *type_ = "vegetation"
            *subtype = ""
        case Building_001:
            *name = "Building"
            *type_ = "building"
            *subtype = ""
        case BusStation_001:
            *name = "BusStation"
            *type_ = "none"
            *subtype = ""
        case Tunnel_001:
            *name = "Tunnel"
            *type_ = "none"
            *subtype = ""
        case PedestrianBridge:
            *name = "PedestrianBridge"
            *type_ = "none"
            *subtype = ""
        case CustomSubType:
            *name = t.getName()
            *type_ = "custom"
            *subtype = ""
        default:
            return
        }
    }

    if *type_ == "null" {
        *type_ = t.getName()
    }
}

func (t *txObject) getPole(subtype int, name, type_, subtypeStr *string) {
// Implement getPole function
}

func (t *txObject) getSign(subtype int, name, type_, subtypeStr *string) {
// Implement getSign function
}

func (t *txObject) getRoadSign(subtype int, name, type_, subtypeStr *string) {
// Implement getRoadSign function
}

func (t *txObject) getName() string {
    // Implement getName function
    return "Custom Name"
}

func (obj *txObject) setPos(x, y, z float64) {
    obj.instancePtr.data.x = x
    obj.instancePtr.data.y = y
    obj.instancePtr.data.z = z
}

func (obj *txObject) setLWH(l, w, h float64) {
    obj.instancePtr.data.length = l
    obj.instancePtr.data.width = w
    obj.instancePtr.data.height = h
}

func (obj *txObject) setRPY(r, p, y float64) {
    obj.instancePtr.data.roll = r
    obj.instancePtr.data.pitch = p
    obj.instancePtr.data.yaw = y
}

func (obj *txObject) setRawTypeString(typeStr, subtypeStr string) {
    assert(len(typeStr) < len(obj.instancePtr.data.rawtype))
    assert(len(subtypeStr) < len(obj.instancePtr.data.rawsubtype))
    copy(obj.instancePtr.data.rawtype[:], typeStr)
    copy(obj.instancePtr.data.rawsubtype[:], subtypeStr)
}

func (obj *txObject) setUserData(userData map[string]string) {
    obj.instancePtr.userData = userData
}

type txParkingSpace struct {
    _access       string
    _restrictions string
    _mark         [4]ParkingMarking
}

func (space *txParkingSpace) getAccess() string {
    return space._access
}

func (space *txParkingSpace) getRestrictions() string {
    return space._restrictions
}

func (space *txParkingSpace) getFrontMarking() ParkingMarking {
    return space._mark[0]
}

func (space *txParkingSpace) getRearMarking() ParkingMarking {
    return space._mark[1]
}

func (space *txParkingSpace) getLeftMarking() ParkingMarking {
    return space._mark[2]
}

func (space *txParkingSpace) getRightMarking() ParkingMarking {
    return space._mark[3]
}

func (space *txParkingSpace) getAccessPtr() *string {
    return &space._access
}

func (space *txParkingSpace) getRestrictionsPtr() *string {
    return &space._restrictions
}

func (space *txParkingSpace) getFrontMarkingPtr() *ParkingMarking {
    return &space._mark[0]
}

func (space *txParkingSpace) getRearMarkingPtr() *ParkingMarking {
    return &space._mark[1]
}

func (space *txParkingSpace) getLeftMarkingPtr() *ParkingMarking {
    return &space._mark[2]
}

func (space *txParkingSpace) getRightMarkingPtr() *ParkingMarking {
    return &space._mark[3]
}

func assert(condition bool) {
    if !condition {
        panic("assertion failed")
    }
}

type ParkingMarking struct{}
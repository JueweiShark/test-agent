package hadmap

import (
    "errors"
    "sync"
)

type txLanes struct {
    lanes []txLanePtr
}

type txLanePtr struct {
    geometry txGeometry
}

type txGeometry interface {
    GetPoint(int) txPoint
    Size() int
}

type txController struct {
    id         controllerkid
    ctlSignals []objectpkid
}

type txJunction struct {
    jId           junctionpkid
    entranceRoads map[roadpkid]float64
    exitRoads     map[roadpkid]float64
    juncRoadsDir  map[roadpkid]DIR_TYPE
    juncRoads     map[roadpkid]pair
    roadPriority  map[roadpkid]map[roadpkid]struct{}
    controllers   []*txController
    laneLinkIds   map[lanelinkpkid]struct{}
    mu            sync.Mutex
}

type pair struct {
    fromRId roadpkid
    toRId   roadpkid
}

func NewTXController(cid controllerkid) *txController {
    return &txController{id: cid}
}

func (c *txController) GetId() controllerkid {
    return c.id
}

func (c *txController) GetSignals() []objectpkid {
    return c.ctlSignals
}

func (c *txController) SetSignals(signals []objectpkid) {
    c.ctlSignals = signals
}

func NewTXJunction(jId junctionpkid) *txJunction {
    return &txJunction{
        jId:           jId,
        entranceRoads: make(map[roadpkid]float64),
        exitRoads:     make(map[roadpkid]float64),
        juncRoadsDir:  make(map[roadpkid]DIR_TYPE),
        juncRoads:     make(map[roadpkid]pair),
        roadPriority:  make(map[roadpkid]map[roadpkid]struct{}),
        controllers:   make([]*txController, 0),
        laneLinkIds:   make(map[lanelinkpkid]struct{}),
    }
}




func NewtxJunction(id junctionpkid) *txJunction {
    return &txJunction{
        jId:            id,
        entranceRoads:  make(map[roadpkid]float64),
        exitRoads:      make(map[roadpkid]float64),
        juncRoadsDir:   make(map[roadpkid]DIR_TYPE),
        juncRoads:      make(map[roadpkid]pair),
        roadPriority:   make(map[roadpkid]map[roadpkid]struct{}),
        laneLinkIds:    make(map[lanelinkpkid]struct{}),
        controllers:    []*txController{},
    }
}

func (j *txJunction) Copy() *txJunction {
    newJunction := &txJunction{
        jId:            j.jId,
        entranceRoads:  make(map[roadpkid]float64),
        exitRoads:      make(map[roadpkid]float64),
        juncRoadsDir:   make(map[roadpkid]DIR_TYPE),
        juncRoads:      make(map[roadpkid]pair),
        roadPriority:   make(map[roadpkid]map[roadpkid]struct{}),
        laneLinkIds:    make(map[lanelinkpkid]struct{}),
        controllers:    make([]*txController, len(j.controllers)),
    }
    for i, c := range j.controllers {
        newJunction.controllers[i] = c.Copy()
    }
    return newJunction
}

func (j *txJunction) GetId() junctionpkid {
    return j.jId
}

func (j *txJunction) GetEntranceRoads() []roadpkid {
    var rIds []roadpkid
    for id := range j.entranceRoads {
        rIds = append(rIds, id)
    }
    return rIds
}

func (j *txJunction) GetExitRoads() []roadpkid {
    var rIds []roadpkid
    for id := range j.exitRoads {
        rIds = append(rIds, id)
    }
    return rIds
}

func (j *txJunction) GetJuncRoads() []roadpkid {
    var rIds []roadpkid
    for id := range j.juncRoads {
        rIds = append(rIds, id)
    }
    return rIds
}

func (j *txJunction) GetControllers() []*txController {
    return j.controllers
}

func (j *txJunction) GetLaneLink() []lanelinkpkid {
    var linkIds []lanelinkpkid
    for id := range j.laneLinkIds {
        linkIds = append(linkIds, id)
    }
    return linkIds
}

func (j *txJunction) PriorityCmp(curRId, cmpRId roadpkid) (int, error) {
    _, curExist := j.juncRoads[curRId];
    _, cmpExist := j.juncRoads[cmpRId]
    if !curExist || !cmpExist {
        return 0, errors.New("isIntersection error, not in the same intersection")
    }else {
        curPriorityAry := j.roadPriority[curRId]
        cmpPriorityAry := j.roadPriority[cmpRId]
        if _, ok := curPriorityAry[cmpRId]; ok {
            return 1, nil
        }
        if _, ok := cmpPriorityAry[curRId]; ok {
            return -1, nil
        }
        return 0, nil
    }
}

func (j *txJunction) InsertJuncRoad(juncRoadPtr *txJunctionRoad) error {
    if juncRoadPtr.GetJuncId() != j.jId {
        return errors.New("insertJuncRoad Error, jId not match")
    }

    if _, ok := j.juncRoads[juncRoadPtr.GetId()]; ok {
        return errors.New("insertJuncRoad Error, road already inserted")
    }

    j.juncRoads[juncRoadPtr.GetId()] = pair{juncRoadPtr.fromRoadId(), juncRoadPtr.toRoadId()}
    j.juncRoadsDir[juncRoadPtr.GetId()] = juncRoadPtr.turnDirection()
    j.roadPriority[juncRoadPtr.GetId()] = make(map[roadpkid]bool)

    j.updateRoadYaw(juncRoadPtr)
    j.juncRoadsDir[juncRoadPtr.GetId()] = juncRoadPtr.turnDirection()

    j.updateRoadPriority(juncRoadPtr.GetId())

    return nil
}

func (j *txJunction) SetControllers(ctls []*txController) {
    j.controllers = ctls
}

func (j *txJunction) InsertLaneLink(linkId lanelinkpkid) {
    j.laneLinkIds[linkId] = struct{}{}
}

func (j *txJunction) IsInteraction(curRId, cmpRId roadpkid) (bool, error) {
    _, curExist := j.juncRoads[curRId];
    _, cmpExist := j.juncRoads[cmpRId]
    if !curExist || !cmpExist {
        return false, errors.New("isIntersection error, not in the same intersection")
    }

    curFromRId, curToRId := j.juncRoads[curRId].first, j.juncRoads[curRId].second
    cmpFromRId, cmpToRId := j.juncRoads[cmpRId].first, j.juncRoads[cmpRId].second
    curRoadDir, cmpRoadDir := j.juncRoadsDir[curRId], j.juncRoadsDir[cmpRId]

    if curFromRId == cmpFromRId {
        return true, nil
    } else if curToRId == cmpToRId {
        if (curRoadDir == DIR_Left && cmpRoadDir == DIR_Straight) || (curRoadDir == DIR_Straight && cmpRoadDir == DIR_Left) {
            return false, nil
        } else {
            return true, nil
        }
    } else {
        curFromYaw, cmpFromYaw := j.entranceRoads[curFromRId], j.entranceRoads[cmpFromRId]
        curFromDir, cmpFromDir := yawToDir(curFromYaw), yawToDir(cmpFromYaw)
        yawOffset := angle(curFromDir, cmpFromDir)
        if yawOffset > 120.0 {
            return true, nil
        } else {
            return false, nil
        }
    }
}

func (j *txJunction) UpdateRoadPriority(curJuncRoadId roadpkid) {
    for id := range j.juncRoads {
        if id == curJuncRoadId {
            continue
        }

        if j.isInteraction(curJuncRoadId, id) {
            curFromRId, curToRId := j.juncRoads[curJuncRoadId].first, j.juncRoads[curJuncRoadId].second
            cmpFromRId, cmpToRId := j.juncRoads[id].first, j.juncRoads[id].second
            curDir, cmpDir := j.juncRoadsDir[curJuncRoadId], j.juncRoadsDir[id]

            if curFromRId == cmpFromRId {
                continue
            } else if curToRId == cmpToRId {
                if curDir == DIR_Uturn {
                    j.roadPriority[id][curJuncRoadId] = struct{}{}
                } else if cmpDir == DIR_Uturn {
                    j.roadPriority[curJuncRoadId][id] =  struct{}{}
                } else if curDir == DIR_Straight {
                    j.roadPriority[curJuncRoadId][id] =  struct{}{}
                } else if cmpDir == DIR_Straight {
                    j.roadPriority[id][curJuncRoadId] =  struct{}{}
                } else if curDir == DIR_Right {
                    j.roadPriority[id][curJuncRoadId] =  struct{}{}
                } else if cmpDir == DIR_Right {
                    j.roadPriority[curJuncRoadId][id] =  struct{}{}
                }
            } else {
                if curDir == DIR_Straight && cmpDir == DIR_Left {
                    j.roadPriority[curJuncRoadId][id] =  struct{}{}
                } else if curDir == DIR_Left && cmpDir == DIR_Straight {
                    j.roadPriority[id][curJuncRoadId] =  struct{}{}
                }
            }
        }
    }
}

func (j *txJunction) UpdateRoadYaw(juncRoadPtr *txJunctionRoad) {
    curLanes := juncRoadPtr.GetSections()[0].GetLanes()
    curLanePtr := curLanes[len(curLanes)/2]

    geomPtr := curLanePtr.GetGeometry().(*txLineCurve)
    center := geomPtr.GetPoint(0)
    frontDir, backDir := geomPtr.GetPoint(1), geomPtr.GetPoint(geomPtr.Size()-1)
    frontDir, backDir = lonlat2enu(frontDir, center), lonlat2enu(backDir, center)

    frontYaw, backYaw := dir2yaw(frontDir), dir2yaw(backDir)
    type := turnDir(frontYaw, backYaw)
    if juncRoadPtr.turnDirection() == DIR_None {
        juncRoadPtr.setTurnDir(type)
    }

    fromRId := juncRoadPtr.fromRoadId
    if _, ok := j.entranceRoads[fromRId]; !ok {
        j.entranceRoads[fromRId] = frontYaw
    } else if juncRoadPtr.turnDirection() == DIR_Straight {
        j.entranceRoads[fromRId] = frontYaw
    }

    toRId := juncRoadPtr.toRoadId
    if _, ok := j.exitRoads[toRId]; !ok {
        j.exitRoads[toRId] = backYaw
    } else if juncRoadPtr.turnDirection() == DIR_Straight {
        j.exitRoads[toRId] = backYaw
    }
}

func NewtxController(cid controllerkid) *txController {
    return &txController{
        id:         cid,
        ctlSignals: []objectpkid{},
    }
}

func (c *txController) Copy() *txController {
    newController := &txController{
        id:         c.id,
        ctlSignals: make([]objectpkid, len(c.ctlSignals)),
    }
    copy(newController.ctlSignals, c.ctlSignals)
    return newController
}


package hadmap

import (
    "sync"

    "wuwen.com/wwsi/internal/biz/xosc/common"

    openDrive "wuwen.com/wwsi/internal/biz/xosc/hadmap/odp"
)

type ODParse struct {
    North, South, East, West float64
    BoundPKID                Laneboundarypkid
    ODHeader                 ODHeader
    ODRoads                  ODRoads
    TargetGeoRef             string
    WebMercatorGeo           string
    TxRoads                  map[Roadpkid]*openDrive.OpenDRIVERoad
    TxLinks                  map[string]TXLaneLinks
    TxObjects                map[Roadpkid]TXObjects
    TxJunctions              map[Junctionpkid]*openDrive.OpenDRIVEJunction
    LaneIDToStartAndEndPoint map[TXLaneId][2]TxPoint
    TxHeader                 TxOdHeaderPtr
    TxRefPoint               TxPoint
    MaxBoundPKID             Laneboundarypkid
    MaxLinkPKID              Lanelinkpkid
    MaxGeomPKID              Objectgeompkid
    LinkPKID                 Lanelinkpkid
    LinkOfJunction           map[Lanelinkpkid]Junctionpkid
    ToEraseIDs               []Roadpkid
    Mutex                    sync.Mutex
}
type ODHeader struct {
    *ODNode
    GeoRef                   string `xml:"geoRef"`
    north, south, east, west float64
    coordStr                 string
    remajor, reminor         uint8
    vendor, date             string
}
type ODNode struct {
    nodeName string
}
type ODRoadPtr = *ODRoad
type ODRoads = []ODRoadPtr
type ODRoad struct {
    ODNode
    SpeedLimit int
    Id         string         `xml:"id"`
    Sections   []ODSectionPtr `xml:"sections>section"`
}
type ODSectionPtr struct {
    Lanes []ODLanePtr `xml:"lanes>lane"`
}
type ODLanePtr *ODLane

type ODLane struct {
    ODNode              `xml:"ODNode"`
    Lid                 int          `xml:"lid"`
    LaneSurface         LANE_SURFACE `xml:"laneSurface"`
    Params              []GeomParam  `xml:"params"`
    LaneType            int          `xml:"lane_Type"`
    FromLid             int64        `xml:"from_Lid"`
    ToLid               int64        `xml:"to_Lid"`
    LaneBoundaryWidth   float64      `xml:"lane_boundary_Width"`
    LaneInterval        float64      `xml:"laned_Interval"`
    LaneSpace           float64      `xml:"laned_Space"`
    LaneSOffset         float64      `xml:"laned_Soffset"`
    LaneLen             float64      `xml:"laned_Len"`
    LaneMark            int          `xml:"lane_Mark"`
    SpeedLimit          int          `xml:"speed_Limit"`
    LaneFriction        float64      `xml:"lane_Friction"`
    LaneMaterialSOffset float64      `xml:"lane_Material_SOffset"`
}
type GeomParam struct {
    s, a, b, c, d float64
}
type TXLaneId struct {
    roadId    Roadpkid
    sectionId common.sectionpkid
    laneId    common.lanepkid
}

package hadmap

import (
    "math"
    "sort"
    "strings"
)

func getHdgFrmPoints(p1, p2 txPoint) float64 {
    deg := math.Atan2(p2.y-p1.y, p2.x-p1.x)
    deg = deg * 180.0 / math.Pi
    return deg
}

func getDistance(p1, p2 txPoint) float64 {
    fDistance := math.Sqrt((p2.y-p1.y)*(p2.y-p1.y) + (p2.x-p1.x)*(p2.x-p1.x))
    return fDistance
}

func fitCenterByLeastSquares(mapPoint []struct{ x, y float64 }, radius *float64) {
    if len(mapPoint) < 3 {
        *radius = 0.0
        return
    }
    var radiusVecSum float64

    for i := 0; i < len(mapPoint)-2; i++ {
        P1 := mapPoint[i]
        P2 := mapPoint[i+1]
        P3 := mapPoint[i+2]
        if P1.x == P2.x && P2.x == P3.x {
            *radius = 0
        } else {
            dis1, dis2, dis3 := math.Sqrt((P1.x-P2.x)*(P1.x-P2.x)+(P1.y-P2.y)*(P1.y-P2.y)),
                math.Sqrt((P1.x-P3.x)*(P1.x-P3.x)+(P1.y-P3.y)*(P1.y-P3.y)),
                math.Sqrt((P2.x-P3.x)*(P2.x-P3.x)+(P2.y-P3.y)*(P2.y-P3.y))
            dis := dis1*dis1 + dis3*dis3 - dis2*dis2

            if dis1 == 0 || dis2 == 0 || dis3 == 0 || dis == 0 {
                *radius = 0
            } else {
                cosA := dis / (2 * dis1 * dis3)
                if math.Abs(1-cosA*cosA) < 1e-6 || math.Abs(dis2) < 1e-6 {
                    *radius = 0
                } else {
                    sinA := math.Sqrt(1 - cosA*cosA)
                    *radius = 0.5 * dis2 / sinA
                    *radius = 1 / *radius
                }
            }
        }
        radiusVecSum += *radius
    }
    *radius = radiusVecSum / float64(len(mapPoint)-2)
}

func stringSplit(str, splits string) []string {
    if str == "" {
        return nil
    }
    strs := str + splits
    var res []string
    for {
        pos := strings.Index(strs, splits)
        if pos == -1 {
            break
        }
        temp := strs[:pos]
        res = append(res, temp)
        strs = strs[pos+len(splits):]
    }
    return res
}

// Calculate the Euclidean distance between two points in 3D space
func directlyDis(a, b []float64, len int) float64 {
    var seqDis float64
    for i := 0; i < len; i++ {
        seqDis += math.Pow(a[i]-b[i], 2)
    }
    return math.Sqrt(seqDis)
}

// Calculate the squared Euclidean distance between two points in 3D space
func directlySeqDis(a, b []float64, len int) float64 {
    var seqDis float64
    for i := 0; i < len; i++ {
        seqDis += math.Pow(a[i]-b[i], 2)
    }
    return seqDis
}

// Calculate the Euclidean distance between two points in 2D space
func directlyDis2D(a, b Point2d) float64 {
    return math.Sqrt(math.Pow(a.X-b.X, 2) + math.Pow(a.Y-b.Y, 2))
}

// Calculate the squared Euclidean distance between two points in 2D space
func directlySeqDis2D(a, b Point2d) float64 {
    return math.Pow(a.X-b.X, 2) + math.Pow(a.Y-b.Y, 2)
}

// Calculate the distance between two points in 3D space, considering the WGS84 coordinate system
func distanceBetweenPoints(p0, p1 Point3d, WGS84 bool) float64 {
    var x1, y1, z1, x2, y2, z2 float64
    x1, y1, z1 = p0.X, p0.Y, p0.Z
    x2, y2, z2 = p1.X, p1.Y, p1.Z
    if WGS84 {
        lonlat2global(&x1, &y1, &z1)
        lonlat2global(&x2, &y2, &z2)
    }
    return math.Sqrt(math.Pow(x1-x2, 2) + math.Pow(y1-y2, 2) + math.Pow(z1-z2, 2))
}

// Normalize a vector in 3D space
func normalize(v []float64, len int) {
    var b = make([]float64, len)
    for i := range b {
        b[i] = 0
    }
    length := directlyDis(v, b, len)
    for i := 0; i < len; i++ {
        v[i] /= length
    }
}

// Normalize a vector in 2D space
func normalize2D(n *Point2d) {
    var v = []float64{n.X, n.Y}
    normalize(v, 2)
    n.X, n.Y = v[0], v[1]
}

// Calculate the direction vector of a point on a curve
func dirVector(points []Point2d, index int, dirVec *Point2d) {
    if index > len(points) {
        return
    }
    if index == 0 {
        dirVec.X = -(points[index+1].Y - points[index].Y)
        dirVec.Y = points[index+1].X - points[index].X
    } else if index == len(points)-1 {
        dirVec.X = -(points[index].Y - points[index-1].Y)
        dirVec.Y = points[index].X - points[index-1].X
    } else {
        var fN = []float64{points[index-1].X - points[index].X, points[index-1].Y - points[index].Y}
        var bN = []float64{points[index+1].X - points[index].X, points[index+1].Y - points[index].Y}
        normalize(fN, 2)
        normalize(bN, 2)
        dirVec.X = fN[0] + bN[0]
        dirVec.Y = fN[1] + bN[1]
    }
}

// Find the nearest point on a curve to a given point in 3D space
func nearestPoint(curve []Point3d, loc Point3d, WGS84 bool, nearestIndex *int, distance *float64) bool {
    *distance = math.MaxFloat64
    *nearestIndex = 0
    var oriLoc = []float64{loc.X, loc.Y, loc.Z}
    if WGS84 {
        lonlat2global(&oriLoc[0], &oriLoc[1], &oriLoc[2])
    }
    for i, p := range curve {
        var a = []float64{p.X, p.Y, p.Z}
        if WGS84 {
            lonlat2global(&a[0], &a[1], &a[2])
        }
        curDis := directlySeqDis(a, oriLoc)
        if curDis < *distance {
            *distance = curDis
            *nearestIndex = i
        }
    }
    *distance = math.Sqrt(*distance)
    return true
}

// Find the nearest point on a curve to a given point in 2D space
func nearestPoint2D(curve []Point2d, loc Point2d, WGS84 bool, nearestIndex *int, distance *float64) bool {
    *distance = math.MaxFloat64
    *nearestIndex = 0
    var oriLoc = []float64{loc.X, loc.Y, 0.0}
    if WGS84 {
        lonlat2global(&oriLoc[0], &oriLoc[1], &oriLoc[2])
    }
    for i, p := range curve {
        var a = []float64{p.X, p.Y, 0.0}
        if WGS84 {
            lonlat2global(&a[0], &a[1], &a[2])
        }
        curDis := directlySeqDis(a, oriLoc)
        if curDis < *distance {
            *distance = curDis
            *nearestIndex = i
        }
    }
    *distance = math.Sqrt(*distance)
    return true
}

// Calculate the intersection point of two line segments in 2D space
func intersectPointDP(firstP0, firstP1, secondP0, secondP1, intersectP Point2d) bool {
    a0, b0, c0 := firstP0.Y-firstP1.Y, firstP1.X-firstP0.X, firstP0.X*firstP1.Y-firstP1.X*firstP0.Y
    a1, b1, c1 := secondP0.Y-secondP1.Y, secondP1.X-secondP0.X, secondP0.X*secondP1.Y-secondP1.X*secondP0.Y
    D := a0*b1 - a1*b0
    if math.Abs(D) < 1e-5 {
        return false
    }
    intersectP.X = (b0*c1 - b1*c0) / D
    intersectP.Y = (a1*c0 - a0*c1) / D
    return true
}

// Calculate the intersection point of two line segments in 2D space, using direction vectors
func intersectPointNP(firstP, firstN, secondP, secondN, intersectP Point2d) bool {
    return intersectPointDP(firstP, Point2d{firstP.X + firstN.X, firstP.Y + firstN.Y}, secondP, Point2d{secondP.X + secondN.X, secondP.Y + secondN.Y}, intersectP)
}

// Calculate the distance from a point to a line segment in 3D space
func calcPoint2LinesegDis(point, segBegin, segEnd Point3d, WGS84 bool) float64 {
    var projP Point3d
    t := projectPoint2Line(point, segBegin, segEnd, WGS84, &projP)
    t = max(0.0, min(1.0, t))
    var a = []float64{point.X, point.Y, point.Z}
    var b = []float64{projP.X, projP.Y, projP.Z}
    if WGS84 {
        lonlat2global(&a[0], &a[1], &a[2])
        lonlat2global(&b[0], &b[1], &b[2])
    }
    return directlyDis(a, b)
}

// Calculate the distance from a point to a polyline in 3D space
func calcPoint2PolylineDis(point Point3d, polyline []Point3d, WGS84, countZ bool) float64 {
    size := len(polyline)
    var dis float64 = math.MaxFloat64
    for i := 0; i < size-1; i++ {
        var curDis float64 = math.MaxFloat64
        if countZ {
            curDis = calcPoint2LinesegDis(point, polyline[i], polyline[i+1], WGS84)
        } else {
            var pNZ = Point3d{point.X, point.Y, 0.0}
            var polyI = Point3d{polyline[i].X, polyline[i].Y, 0.0}
            var polyI1 = Point3d{polyline[i+1].X, polyline[i+1].Y, 0.0}
            curDis = calcPoint2LinesegDis(pNZ, polyI, polyI1, WGS84)
        }
        if curDis < dis {
            dis = curDis
        }
    }
    return dis
}

// Calculate the lane width based on left and right boundary geometries
func calcLaneWidth(leftBoundaryGeom, rightBoundaryGeom []Point3d, WGS84 bool) float64 {
    var leftGeomGlobal, rightGeomGlobal []Point3d
    for _, p := range leftBoundaryGeom {
        var loc = []float64{p.X, p.Y, p.Z}
        if WGS84 {
            lonlat2global(&loc[0], &loc[1], &loc[2])
        }
        leftGeomGlobal = append(leftGeomGlobal, Point3d{loc[0], loc[1], loc[2]})
    }
    for _, p := range rightBoundaryGeom {
        var loc = []float64{p.X, p.Y, p.Z}
        if WGS84 {
            lonlat2global(&loc[0], &loc[1], &loc[2])
        }
        rightGeomGlobal = append(rightGeomGlobal, Point3d{loc[0], loc[1], loc[2]})
    }
    var dis []float64
    for _, p := range leftGeomGlobal {
        dis = append(dis, calcPoint2PolylineDis(p, rightGeomGlobal, false, true))
    }
    sort.Float64s(dis)
    var r float64
    var c int
    m := dis[len(dis)/2]
    for _, d := range dis {
        if math.Abs(d-m) < 0.5 {
            r += d
            c++
        }
    }
    if c == 0 {
        return 0.0
    }
    return r / float64(c)
}

// Project a point onto a line and return the projection parameter
func projectPoint2Line(p, start, end Point3d, WGS84 bool, projectP *Point3d) float64 {
    var x1, y1, z1, x2, y2, z2, x3, y3, z3 float64
    x1, y1, z1 = start.X, start.Y, start.Z
    x2, y2, z2 = end.X, end.Y, end.Z
    x3, y3, z3 = p.X, p.Y, p.Z
    if WGS84 {
        lonlat2global(&x1, &y1, &z1)
        lonlat2global(&x2, &y2, &z2)
        lonlat2global(&x3, &y3, &z3)
    }
    var seX, seY, seZ, seL2 float64
    seX, seY, seZ = x2-x1, y2-y1, z2-z1
    seL2 = seX*seX + seY*seY + seZ*seZ
    var u, ru float64
    ru = 0
    if seL2 < 1e-7 {
        u = 0
    } else {
        u = ((x3-x1)*seX + (y3-y1)*seY + (z3-z1)*seZ) / seL2
        ru = u
        if u > 1.0 {
            u = 1.0
        } else if u < 0.0 {
            u = 0.0
        }
    }
    projectP.X, projectP.Y, projectP.Z = x1+u*seX, y1+u*seY, z1+u*seZ
    if WGS84 {
        global2lonlat(&projectP.X, &projectP.Y, &projectP.Z)
    }
    return ru
}

// Project a 2D point onto a 2D line and return the projection parameter
func projectPoint2Line2D(p, start, end Point2d, WGS84 bool, projectP *Point2d) float64 {
    var p3d = Point3d{p.X, p.Y, 0.0}
    var start3d = Point3d{start.X, start.Y, 0.0}
    var end3d = Point3d{end.X, end.Y, 0.0}
    var projectp3d Point3d
    u := projectPoint2Line(p3d, start3d, end3d, WGS84, &projectp3d)
    projectP.X, projectP.Y = projectp3d.X, projectp3d.Y
    return u
}

// Sort lane data based on specific criteria
func sortLaneData(lanes []TxLane) {
    sort.Slice(lanes, func(i, j int) bool {
        if lanes[i].RoadPKID == lanes[j].RoadPKID {
            if lanes[i].SectionID == lanes[j].SectionID {
                return lanes[i].LaneID > lanes[j].LaneID
            }
            return lanes[i].SectionID < lanes[j].SectionID
        }
        return lanes[i].RoadPKID < lanes[j].RoadPKID
    })
}

// Check if a point is on a line segment in 2D space
func pointOnLine(begin, end, intersectP Point2d) bool {
    dx, dy := math.Abs(begin.X-end.X)*1e-4, math.Abs(begin.Y-end.Y)*1e-4
    return (intersectP.X > min(begin.X, end.X)-dx && intersectP.X < max(begin.X, end.X)+dx) ||
        (intersectP.Y > min(begin.Y, end.Y)-dy && intersectP.Y < max(begin.Y, end.Y)+dy)
}

// Determine which side of a line a point is on
func pointSide(begin, end, intersectP Point2d) int {
    dir := Point2d{end.X - begin.X, end.Y - begin.Y}
    pV := Point2d{intersectP.X - begin.X, intersectP.Y - begin.Y}
    z := pV.X*dir.Y - pV.Y*dir.X
    if z > 0 {
        return -1
    }
    return 1
}

// Convert a direction vector to a yaw angle
func dir2yaw(dir Point2d, ENU bool) float64 {
    yaw := math.Atan2(dir.Y, dir.X)
    if !ENU {
        yaw += math.Pi / 2
    }
    yaw = yaw * 180 / math.Pi
    if yaw < 0 {
        yaw += 360
    }
    return yaw
}

// Convert a yaw angle to a direction vector
func yaw2dir(yaw float64, ENU bool, dir *Point2d) {
    if !ENU {
        yaw -= 90
    }
    yaw = yaw * math.Pi / 180
    dir.X, dir.Y = math.Cos(yaw), math.Sin(yaw)
}

// Calculate the angle between two vectors
func angle(v1, v2 Point2d) float64 {
    var nv1, nv2 Point2d
    normalize2D(&nv1)
    normalize2D(&nv2)
    arccos := nv1.X*nv2.X + nv1.Y*nv2.Y
    return math.Acos(arccos) * 180 / math.Pi
}

// Convert an angle to radians
func angle2radian(a float64) float64 {
    if a > 180.0 {
        a -= 360
    }
    return a * math.Pi / 180.0
}

// Convert radians to an angle
func radian2angle(r float64) float64 {
    r = r * 180 / math.Pi
    if r < 0 {
        r += 360
    }
    return r
}

// Determine the turn direction based on entrance and exit yaw angles
func turnDir(entranceYaw, exitYaw float64) DIR_TYPE {
    yawOffset := math.Mod(exitYaw-entranceYaw+720.0, 360.0)
    if yawOffset > 180.0 {
        yawOffset -= 360
    }
    if math.Abs(yawOffset) < 30.0 {
        return DIR_Straight
    } else if math.Abs(yawOffset) > 135.0 {
        return DIR_Uturn
    } else if yawOffset > 0 {
        return DIR_Left
    }
    return DIR_Right
}

// Check if a point is inside a polygon
func posInPolygon(pos Point2d, polygon []Point2d, wgs84 bool) bool {
    var total float64
    if wgs84 {
        for i, p := range polygon {
            j := (i + 1) % len(polygon)
            var a, b Point2d
            lonlat2enu(&a.X, &a.Y, &a.Z, p.X, p.Y, pos.X, pos.Y, &a.Z)
            lonlat2enu(&b.X, &b.Y, &b.Z, polygon[j].X, polygon[j].Y, pos.X, pos.Y, &b.Z)
            total += angle(a, b)
        }
    } else {
        for i, p := range polygon {
            j := (i + 1) % len(polygon)
            a := Point2d{polygon[i].X - pos.X, polygon[i].Y - pos.Y}
            b := Point2d{polygon[j].X - pos.X, polygon[j].Y - pos.Y}
            total += angle(a, b)
        }
    }
    return math.Abs(total-360.0) < 1.0
}

func pointToRectDistance(v1, leftBottom, rightTop Point2d) int {
    if v1.x >= leftBottom.x && v1.y >= leftBottom.y && v1.x <= rightTop.x && v1.y <= rightTop.y {
        return 0
    } else if v1.x < leftBottom.x {
        if v1.y > rightTop.y {
            return directlyDis(v1, Point2d{leftBottom.x, rightTop.y})
        } else if v1.y < leftBottom.y {
            return directlyDis(v1, leftBottom)
        } else {
            return int(leftBottom.x - v1.x)
        }
    } else if v1.x > rightTop.x {
        if v1.y > rightTop.y {
            return directlyDis(v1, rightTop)
        } else if v1.y < leftBottom.y {
            return directlyDis(v1, Point2d{rightTop.x, leftBottom.y})
        } else {
            return int(v1.x - leftBottom.x)
        }
    } else if v1.y > rightTop.y {
        return int(v1.y - rightTop.y)
    } else if v1.y < leftBottom.y {
        return int(leftBottom.y - v1.y)
    }
    return 0
}

func isPointInRect(v1, leftBottom, rightTop Point2d) int {
    if v1.x >= leftBottom.x && v1.y >= leftBottom.y && v1.x <= rightTop.x && v1.y <= rightTop.y {
        return 1
    }
    return 0
}

func isInRect(point, A, B, C, D Point2d) bool {
    x := point.x
    y := point.y

    a := (B.x-A.x)*(y-A.y) - (B.y-A.y)*(x-A.x)
    b := (C.x-B.x)*(y-B.y) - (C.y-B.y)*(x-B.x)
    c := (D.x-C.x)*(y-C.y) - (D.y-C.y)*(x-C.x)
    d := (A.x-D.x)*(y-D.y) - (A.y-D.y)*(x-D.x)
    if (a > 0 && b > 0 && c > 0 && d > 0) || (a < 0 && b < 0 && c < 0 && d < 0) {
        return true
    }
    return false
}

func calcCircumcircleRadius(A, B, C Point2d, WGS84 bool) float64 {
    const eps = 1E-6

    if WGS84 {
        // Assuming coord_trans_api::lonlat2enu is available in Go
        z := 0.0
        coord_trans_api.lonlat2enu(B.x, B.y, z, A.x, A.y, z)
        coord_trans_api.lonlat2enu(C.x, C.y, z, A.x, A.y, z)
        A.x = 0.0
        A.y = 0.0
    }

    yawAB := dir2yaw(Point2d{B.x, B.y}, true)
    yawAC := dir2yaw(Point2d{C.x, C.y}, true)
    radianA := math.Abs(angle2radian(yawAB) - angle2radian(yawAC))

    if math.Abs(radianA) < eps {
        return math.Inf(1)
    }

    if radianA > math.Pi {
        radianA = 2*math.Pi - radianA
    }
    return directlyDis(B, C) / (2*math.Sin(radianA/2) + eps)
}

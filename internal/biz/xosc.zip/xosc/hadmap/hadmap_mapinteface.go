package hadmap

import "sync"

type txProjectionInterface interface {
    Transform(x, y *float64)
    Untransform(x, y *float64)
}

type txProjection struct {
    pId      pkid_t
    originLL txPoint
    dx       float64
    dy       float64
}

func (p *txProjection) lonlat2enu(lonlat txPoint, enu *txPoint) {
    enu.X = lonlat.X
    enu.Y = lonlat.Y
    enu.Z = lonlat.Z
    coord_trans_api.Lonlat2enu(&enu.X, &enu.Y, &enu.Z, &p.originLL.X, &p.originLL.Y, &p.originLL.Z)
}

func (p *txProjection) enu2lonlat(enu txPoint, lonlat *txPoint) {
    lonlat.X = enu.X
    lonlat.Y = enu.Y
    lonlat.Z = enu.Z
    coord_trans_api.Enu2lonlat(&lonlat.X, &lonlat.Y, &lonlat.Z, &p.originLL.X, &p.originLL.Y, &p.originLL.Z)
}

func (p *txProjection) transform(x, y *float64) {
    ll := txPoint{*x, *y, 0.0}
    var r txPoint
    p.lonlat2enu(ll, &r)
    *x = r.X
    *y = r.Y
}

func (p *txProjection) untransform(x, y *float64) {
    enu := txPoint{*x, *y, 0.0}
    var r txPoint
    p.enu2lonlat(enu, &r)
    *x = r.X
    *y = r.Y
}

func (p *txProjection) dX() float64 {
    return p.dx
}

func (p *txProjection) dY() float64 {
    return p.dy
}

func (p *txProjection) pID() pkid_t {
    return p.pId
}

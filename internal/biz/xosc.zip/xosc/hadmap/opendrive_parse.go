package hadmap

import (
    "encoding/xml"
    "fmt"
    "io/ioutil"
    "math"
    "os"
    "sort"
    "strconv"
    "strings"
    "sync"

    "wuwen.com/wwsi/internal/biz/xosc/common"
)

type ODRoadObject struct {
    st, access, restrictions string
    parkingmark              []ParkingMark
    len, wid, hei            float64
    roll, pitch, yaw         float64
    hdg, zoffset, s, t       float64
    markwidth                float64
    repetaData               string
    x, y, z                  float64
    id, name, Type, subtype  string
    userData                 string
    boundary                 []Point
    geom                     []Geometry
    repeat                   []Point
}

type Geometry struct {
    first  bool
    second []Point
}

type TxObject interface {
    setObjectType(ObjectType)
    setId(uint64)
    setName(string)
    setLWH(float64, float64, float64)
    setRPY(float64, float64, float64)
    setRawTypeString(string, string)
    setObjectType(string, string, string, string)
    getOdData() txOdObject
    setST(float64, float64)
    setTxOdData(txOdObject)
    setUserData(string)
    setPos(float64, float64, float64)
    transform2OdData()
    addGeom(TxObjGeomPtr)
    setRepeat(TxLineCurvePtr)
}
type TxObjGeomPtr interface {
    setId(int)
    setType(ObjectGeometryType)
    setStyle(ObjectStyle)
    setGeometry([]Point, CoordType)
    setColor(ObjectColor)
}

type TxLineCurvePtr interface {
    setCoords([]Point)
}

type TxParkingSpace struct {
    frontMarking, rearMarking, leftMarking, rightMarking ParkingMarking
}

type ParkingMarking struct {
    valid bool
    Type  string
    width float64
    color ObjectColor
}

type TxObjectImpl struct {
    odData txOdObject
}
type TxOdObject struct {
    length, width, height, roll, pitch, hdg, zoffset, s, t float64
    orientation                                            int
    markWidth                                              float64
    repeatdata                                             [256]byte
}

type WidData struct {
    Sec              ODLaneSection
    SecEle           []float64
    DisFromSec       []float64
    SecRefLine       [][]float64
    SecRefNormal     [][]float64
    BdyWidth         [][]float64
    LaneWidth        [][]float64
    BdyMark          []LANE_MARK
    BdyLaneWidth     []float64
    BdyLanedinterval []float64
    BdyLanedspace    []float64
    BdyLanedsoffset  []float64
    BdyLanedlen      []float64
}

type AreaPointVec [][]txPoint

type Point struct {
    X, Y float64
}

//type ODParse struct {
//    _bound_pkid                  int
//    _link_pkid                   int
//    tx_roads                     map[string]ODRoadPtr
//    tx_links                     map[string]ODLinkPtr
//    tx_junctions                 map[string]ODJunctionPtr
//    tx_objects                   map[string]TXObjectPtr
//    _north, _south, _east, _west float64
//    od_header                    ODHeader
//}

type ODSectionPtr struct {
    Lanes []ODLanePtr `xml:"lanes>lane"`
}

type txLineCurve struct {
    Points []txPoint `xml:"points>point"`
}

type txBoundary struct {
    Geometry *txLineCurve `xml:"geometry"`
}

type ODJunctionPtr struct {
    id string `xml:"id"`
}

type TXObjectPtr struct {
    id     string `xml:"id"`
    roadId string `xml:"roadId"`
}

func shpOut(path string, geom []Point) {
    out, err := os.Create(path)
    if err != nil {
        fmt.Println("Error creating file:", err)
        return
    }
    defer out.Close()

    for _, point := range geom {
        _mx, _my := mercator2lonlat(point.X, point.Y)
        _, err := out.WriteString(fmt.Sprintf("%.10f %.10f 50.0\n", _mx, _my))
        if err != nil {
            fmt.Println("Error writing to file:", err)
            return
        }
    }
}

func mercator2lonlat(mx, my float64) (float64, float64) {
    // Placeholder for actual mercator to lonlat conversion
    return mx, my
}

// XML document related functions

type Controller struct{}

func (c *Controller) id() int64 {
    return 0
}
func (c *Controller) parse(elem xml.StartElement) error { return nil }

//func (odp *ODParse) parseArea(dataPath string, vec AreaPointVec) bool {
//  }

func mergeSections(sections []txSection, secPtr **txSection) {
    *secPtr = &txSection{Lanes: make(txLanes, 1)}
    (*secPtr).Lanes[0] = &txLane{Geometry: sections[0].Lanes[0].Geometry}
    if len(sections) == 1 {
        return
    } else {
        lanes := (*secPtr).getLanes()
        for i := 1; i < len(sections); i++ {
            for _, lanePtr := range lanes {
                if lanePtr.getGeometry() == nil {
                    continue
                }
                end := lanePtr.getGeometry().GetEnd()
                curLanes := sections[i].getLanes()
                for _, curLanePtr := range curLanes {
                    if curLanePtr.getGeometry() == nil {
                        continue
                    }
                    start := curLanePtr.getGeometry().GetStart()
                    if math.Abs(start.x-end.x) < 0.1 && math.Abs(start.y-end.y) < 0.1 {
                        var oriPts, curPts PointVec
                        lanePtr.getGeometry().GetPoints(oriPts)
                        curLanePtr.getGeometry().GetPoints(curPts)

                        oriPts = append(oriPts, curPts[1:]...)
                        lanePtr.setGeometry(oriPts, curLanePtr.getGeometry().GetCoordType())
                        break
                    }
                }
            }
        }
    }
}
func parseObjectType(obj ODRoadObject) ObjectType {
    switch obj.Type {
    case "sensor":
        return OBJECT_TYPE_V2X_Sensor
    case "parkingSpace":
        return OBJECT_TYPE_ParkingSpace
    case "TrafficLights", "trafficLight":
        return OBJECT_TYPE_TrafficLights
    case "roadmark":
        if strings.Contains(obj.Name, "Arrow") {
            return OBJECT_TYPE_Arrow
        }
        return OBJECT_TYPE_RoadSign
    case "Curb", "curb":
        return OBJECT_TYPE_Curb
    case "railling":
        return OBJECT_TYPE_TrafficBarrier
    case "arrow", "LeftArrow", "RightArrow", "StraightArrow", "StraightLeftArrow", "StraightRightArrow":
        return OBJECT_TYPE_Arrow
    case "StopLine":
        return OBJECT_TYPE_Stop
    case "crosswalk", "ZebraCrossing":
        return OBJECT_TYPE_CrossWalk
    case "Poles", "pole", "streetlamp", "streetLamp", "RoadSignPole", "gantry":
        return OBJECT_TYPE_Pole
    case "TrafficSign", "trafficSign", "SpeedBump", "PedsstrianWarning", "HoriSlowMarking":
        return OBJECT_TYPE_TrafficSign
    case "Toll":
        return OBJECT_TYPE_TollBooth
    case "Belt":
        return OBJECT_TYPE_TrafficBarrier
    case "Text":
        return OBJECT_TYPE_Text
    case "ConcreteSlab":
        return OBJECT_TYPE_Building
    case "parking":
        return OBJECT_TYPE_RR_Parking
    case "2":
        if obj.Name == "J_014" {
            return OBJECT_TYPE_ChargingPile
        }
    }

    switch obj.St {
    case ODRoadObject.SIGNAL:
        return OBJECT_TYPE_TrafficSign
    case ODRoadObject.PARKING:
        return OBJECT_TYPE_ParkingSpace
    case ODRoadObject.SIGNAL_DYNAMIC:
        return OBJECT_TYPE_TrafficLights
    }

    return OBJECT_TYPE_None
}
func parseObjectGeomType(obj ODRoadObject, typeRef *OBJECT_GEOMETRY_TYPE, styleRef *OBJECT_STYLE) {
    *typeRef = OBJECT_GEOMETRY_TYPE_None
    *styleRef = OBJECT_STYLE_None
    switch obj.Type {
    case "parkingSpace":
        *typeRef = OBJECT_GEOMETRY_TYPE_Polygon
        *styleRef = OBJECT_STYLE_Polyline
    case "LeftArrow":
        *typeRef = OBJECT_GEOMETRY_TYPE_Polygon
        *styleRef = OBJECT_STYLE(LANE_ARROW_Left)
    case "RightArrow":
        *typeRef = OBJECT_GEOMETRY_TYPE_Polygon
        *styleRef = OBJECT_STYLE(LANE_ARROW_Right)
    case "StraightArrow":
        *typeRef = OBJECT_GEOMETRY_TYPE_Polygon
        *styleRef = OBJECT_STYLE(LANE_ARROW_Straight)
    case "StraightLeftArrow":
        *typeRef = OBJECT_GEOMETRY_TYPE_Polygon
        *styleRef = OBJECT_STYLE(LANE_ARROW_StraightLeft)
    case "StraightRightArrow":
        *typeRef = OBJECT_GEOMETRY_TYPE_Polygon
        *styleRef = OBJECT_STYLE(LANE_ARROW_StraightRight)
    case "roadmark", "arrow":
        *typeRef = OBJECT_GEOMETRY_TYPE_Polygon
        switch obj.Name {
        case "ArrowForwardLeft":
            *styleRef = OBJECT_STYLE(LANE_ARROW_StraightLeft)
        case "ArrowForwardRight":
            *styleRef = OBJECT_STYLE(LANE_ARROW_StraightRight)
        case "ArrowForward":
            *styleRef = OBJECT_STYLE(LANE_ARROW_Straight)
        case "ArrowLeft":
            *styleRef = OBJECT_STYLE(LANE_ARROW_Left)
        case "ArrowRight":
            *styleRef = OBJECT_STYLE(LANE_ARROW_Right)
        }
    case "StopLine":
        *typeRef = OBJECT_GEOMETRY_TYPE_Polyline
    case "Poles":
        *typeRef = OBJECT_GEOMETRY_TYPE_Polygon
        *styleRef = OBJECT_STYLE_Circle
    case "2":
        if obj.Name == "J_014" {
            *typeRef = OBJECT_GEOMETRY_TYPE_Polygon
            *styleRef = OBJECT_STYLE_Polygon
        }
    }
    if obj.Name == "Intersection_Guide_Line" {
        *styleRef = OBJECT_STYLE_Polyline
    }
}

func strtoull(s string, base int, bitSize int) uint64 {
    result, err := strconv.ParseUint(s, base, bitSize)
    if err != nil {
        fmt.Println("Error converting string to uint64:", err)
        return 0
    }
    return result
}

type Pair struct {
    first  float64
    second float64
}

func generateRoadPtr(id roadpkid, roadType ROAD_TYPE, speedLimit int, roadGeom []Point, roadEle []float64, roadPtr *txRoad) {
    if len(roadGeom) != len(roadEle) {
        return
    }
    roadPtr = &txRoad{
        id:         id,
        roadType:   roadType,
        speedLimit: speedLimit,
    }
    points := make([]Point, len(roadGeom))
    for i := range roadGeom {
        x, y := roadGeom[i].x, roadGeom[i].y
        z := 0.0
        if i < len(roadEle) {
            z = roadEle[i]
        }
        points[i] = Point{x: x, y: y, z: z}
    }
    roadPtr.geometry = points
}

func generateBoundaryPtr(id laneboundarypkid, mark LANE_MARK, laneWidth, doubleInterval, dotSpace, dotOffset, dotLen float64, boundGeom []Point, boundEle []float64, boundPtr *txLaneBoundary) {
    boundPtr = &txLaneBoundary{
        id:             id,
        laneMark:       mark,
        laneWidth:      laneWidth,
        doubleInterval: doubleInterval,
        dotOffset:      dotOffset,
        dotLen:         dotLen,
        dotSpace:       dotSpace,
    }
    points := make([]Point, len(boundGeom))
    for i := range boundGeom {
        x, y := boundGeom[i].x, boundGeom[i].y
        z := 0.0
        if i < len(boundEle) {
            z = boundEle[i]
        }
        points[i] = Point{x: x, y: y, z: z}
    }
    boundPtr.geometry = points
}

func generateLanePtr(rId roadpkid, sId sectionpkid, lId lanepkid, laneType LANE_TYPE, speedLimit int, laneWidth float64, surface int, friction float64, materialOffset float64, laneGeom []Point, laneEle []float64, laneWidths []float64, lanePtr *txLane) {
    lanePtr = &txLane{
        roadId:         rId,
        sectionId:      sId,
        id:             lId,
        laneType:       laneType,
        speedLimit:     speedLimit,
        laneWidth:      laneWidth,
        laneSurface:    surface,
        laneFriction:   friction,
        materialOffset: materialOffset,
    }
    points := make([]Point, len(laneGeom))
    for i := range laneGeom {
        x, y := laneGeom[i].x, laneGeom[i].y
        z := 0.0
        if i < len(laneEle) {
            z = laneEle[i]
        }
        points[i] = Point{x: x, y: y, z: z}
        if i < len(laneWidths) {
            points[i].w = laneWidths[i]
        }
    }
    if len(points) > 1 {
        m_laneidToStartAndEndPoint[lanePtr.id] = []Point{points[0], points[len(points)-1]}
    }
    lanePtr.geometry = points
}

func isInRecVecAreaSections(_sections txSections, ptr [][]txPoint) bool {
    for _, iter := range _sections {
        txBoundaries := iter.getBoundaries()
        for _, boundary := range txBoundaries {
            curveptr := boundary.getGeometry()
            if curveptr != nil {
                var points []txPoint
                curveptr.sample(1, &points)
                for _, point := range points {
                    for _, rect := range ptr {
                        if isPointInRect(point, rect[0], rect[2]) {
                            return true
                        }
                    }
                }
            }
        }
    }
    return false
}

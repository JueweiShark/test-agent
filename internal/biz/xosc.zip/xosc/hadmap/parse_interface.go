package hadmap

import (
    "wuwen.com/wwsi/internal/biz/xosc/common"
)

type ParserFactory struct{}

type DataParse interface {
    parse(dataPath string) bool
    parseArea(dataPath string, vec AreaPointVec) bool
    getData(roads TXRoads, links TXLaneLinks, objs TXObjects, juncs TxJunctions, header TxOdHeaderPtr,
        refPoint txPoint, doubleRoad bool) bool
    //Type MapDataType
}

func (f *ParserFactory) GetParser(type_ DataParseType) DataParse {
    switch type_ {
    case OPENDRIVE:
        return NewODParse()
    default:
        return nil
    }
}

type DataParseType int

const (
    OPENDRIVE DataParseType = iota
)

func (p *ParserFactory) getParser(parseType string) DataParse {
    // This is a placeholder. Actual implementation depends on how parsers are created.
    return nil
}

func parseOpenDrive(dataPath string, roads []TxRoad, links TXLaneLinks, objs TXObjects, juncs TxJunctions, header *TxOdHeaderPtr, refPoint txPoint, doubleRoad bool) bool {
    parser := ParserFactory{}.getParser("OPENDRIVE")
    if parser == nil {
        return false
    }
    return parser.parse(dataPath) && parser.getData(roads, links, objs, juncs, *header, refPoint, doubleRoad)
}

func parseOpenDriveArea(dataPath string, roads txRoads, links TXLaneLinks, objs TXObjects, juncs common.txJunctions, ptr AreaPointVec, header *txOdHeaderPtr, refPoint txPoint) bool {
    parser := ParserFactory{}.getParser("OPENDRIVE")
    if parser == nil {
        return false
    }
    return parser.parseArea(dataPath, ptr) && parser.getData(roads, links, objs, juncs, *header, refPoint, true)
}

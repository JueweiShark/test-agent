package hadmap

import "math"

type txLinkObject struct {
    prev []string
    next []string
}

func (t *txLinkObject) AddPrev(preId string) {
    for _, id := range t.prev {
        if id == preId {
            return
        }
    }
    t.prev = append(t.prev, preId)
}

func (t *txLinkObject) AddNext(nextId string) {
    for _, id := range t.next {
        if id == nextId {
            return
        }
    }
    t.next = append(t.next, nextId)
}

func (t *txLinkObject) GetPrev(ids *[]string) bool {
    *ids = t.prev
    return len(*ids) > 0
}

func (t *txLinkObject) GetNext(ids *[]string) bool {
    *ids = t.next
    return len(*ids) > 0
}

func (t *txLinkObject) GetUniqueId() string {
    return "base_class"
}

// Enum for coordinate types

// Point class
type txPoint struct {
    X, Y, Z, W, H, Hdg float64
}

// New txPoint constructor
func NewTxPoint() *txPoint {
    return &txPoint{}
}

func NewTxPointWithCoords(x, y, z, w, h float64) *txPoint {
    return &txPoint{X: x, Y: y, Z: z, W: w, H: h}
}

func NewTxPointWithCoordsAndHeading(x, y, z, w, h, hdg float64) *txPoint {
    return &txPoint{X: x, Y: y, Z: z, W: w, H: h, Hdg: hdg}
}

func NewTxPointWithPoint(p *txPoint) *txPoint {
    return &txPoint{X: p.X, Y: p.Y, Z: p.Z, W: p.W, H: p.H, Hdg: p.Hdg}
}

// Assignment operator
func (p *txPoint) Assign(p2 *txPoint) {
    p.X = p2.X
    p.Y = p2.Y
    p.Z = p2.Z
    p.W = p2.W
    p.H = p2.H
    p.Hdg = p2.Hdg
}

// Equality operator
func (p *txPoint) Equal(p2 *txPoint) bool {
    return math.Abs(p.X-p2.X) < 1e-7 && math.Abs(p.Y-p2.Y) < 1e-7 && math.Abs(p.Z-p2.Z) < 1e-7 &&
        math.Abs(p.W-p2.W) < 1e-7 && math.Abs(p.H-p2.H) < 1e-7
}

// Arithmetic operators
func (p *txPoint) Add(point *txPoint) *txPoint {
    p.X += point.X
    p.Y += point.Y
    return p
}

func (p *txPoint) Subtract(point *txPoint) *txPoint {
    p.X -= point.X
    p.Y -= point.Y
    return p
}

func (p *txPoint) Multiply(d float64) *txPoint {
    p.X *= d
    p.Y *= d
    return p
}

func (p *txPoint) Divide(d float64) *txPoint {
    if d != 0 {
        p.X /= d
        p.Y /= d
    }
    return p
}

// Vector of points
type PointVec []*txPoint

// Base class for curves
type ItxCurve interface {
    SetCoordType(ct CoordType)
    GetCoordType() CoordType
    Reverse()
    Transfer(oldEnuC, newEnuC *txPoint) bool
    Transfer2ENU(enuCenter *txPoint) bool
    Empty() bool
    GetLength() float64
    GetPoint(distance float64) *txPoint
    GetStart() *txPoint
    GetEnd() *txPoint
    Sample(interval float64, points *PointVec)
    SampleV2(angleLimit, angleLimitLen float64, points *PointVec)
    GetPassedDistance(specifiedPoint *txPoint, pedalPoint *txPoint, ct CoordType) float64
    Xy2sl(x, y float64, s, l, yaw *float64) bool
    Sl2xy(s, l float64, x, y, yaw *float64) bool
    GetYaw(s float64) float64

    GetPointIndex(distance float64) int
    SampleWithRange(interval, start_s, end_s float64, points *PointVec)
    Cut(begin, end float64, points *PointVec) bool
    Size() int
    GetPointByIndex(index int) txPoint
    Yaw(index int) float64
    GetPoints(points *PointVec)
    AddPoint(point txPoint, lastUpdate bool)
    SetCoords(points PointVec)
    Clone(curve ItxCurve)
    CloneFromPtr(curvePtr ItxCurve)
    CloneFromLineCurve(lineCurvePtr *txLineCurve)
    Splice(curvePtr *ItxCurve)
    SpliceFromInstance(curveIns ItxCurve)

    size() int
    getPoint(index int) txPoint
    yaw(index int) float64
    getPoints(points *PointVec)
    addPoint(point txPoint, update bool)
    setCoords(points PointVec)
    clone(curveIns ItxCurve) error
    splice(curvePtr ItxCurve) error
    reverse()
    transfer(oldEnuC, newEnuC txPoint) bool
    transfer2ENU(enuCenter txPoint) bool
    xy2sl(x, y float64) (s, l, yaw float64, err error)
}

// Link object class
type ItxLinkObject interface {
    GetLinkType() LINK_TYPE
    GetPrev(prevIds *[]string) bool
    GetNext(nextIds *[]string) bool
    ClearPrev()
    ClearNext()
    AddPrev(preId string)
    AddNext(nextId string)
    PutExData(dataPtr ExDataPtr)
    GetExData() ExDataPtr
    GetUniqueId() string
}

// Curve curvature structure
type txCurvature struct {
    starts, length, curvature float64
}

// Vector of curve curvatures
type txCurvatureVec []*txCurvature

// Curve control point structure
type txControlPoint struct {
    Type   string
    Points []*txPoint
}

// OpenCRG structure
type txOpenCrg struct {
    File        string
    Orientation string
    Mode        string
    Purpose     string
    SOffset     string
    TOffset     string
    ZOffset     string
    ZScale      string
    HOffset     string
}

// Vector of OpenCRG structures
type txOpenCrgVec []*txOpenCrg

// Curve slope structure
type txSlope struct {
    starts, length, slope float64
}

// Vector of curve slopes
type txSlopeVec []*txSlope

// Road link structure
type txRoadLink struct {
    Id           string
    Type         string
    ContactPoint string
}

package hadmap

import "strconv"

type txRoad struct {
    ID   roadpkid
    Name string
}
type txJunctionRoad struct {
    txJunctionRoadPtr *txRoad
    turnDir           DIR_TYPE
    hasLights         bool
    hasStop           bool
    jId               junctionpkid
    fromRoadId        roadpkid
    toRoadId          roadpkid
    objMap            map[OBJECT_TYPE]txObjects
}

func (j *txJunctionRoad) IsJunction() bool {
    return true
}

func (j *txJunctionRoad) HasTrafficLights() bool {
    return j.hasLights
}

func (j *txJunctionRoad) HasStopLine() bool {
    return j.hasStop
}

func (j *txJunctionRoad) TurnDirection() DIR_TYPE {
    return j.turnDir
}

func (j *txJunctionRoad) GetUniqueId() string {
    return "junc_" + strconv.Itoa(int(j.GetId()))
}

func (r *txJunctionRoad) GetId() roadpkid {
    return r.id
}
func (r *txJunctionRoad) turnDirection() DIR_TYPE {
    return r.turnDir
}

func (r *txJunctionRoad) setTurnDir(dir DIR_TYPE) {
    r.turnDir = dir
}

func (j *txJunctionRoad) setToRoadId(id roadpkid) {
    j.toRoadId = id
}

func (j *txJunctionRoad) setLightFlag(flag bool) {
    j.hasLights = flag
}

func (j *txJunctionRoad) setStopLineFlag(flag bool) {
    j.hasStop = flag
}

func (j *txJunctionRoad) setObj(type_ OBJECT_TYPE, objPtr txObjectPtr) {
    if _, ok := j.objMap[type_]; !ok {
        j.objMap[type_] = []txObjectPtr{}
    }
    j.objMap[type_] = append(j.objMap[type_], objPtr)
}

func (j *txJunctionRoad) setObjs(type_ OBJECT_TYPE, objs []txObjectPtr) {
    if _, ok := j.objMap[type_]; !ok {
        j.objMap[type_] = objs
    } else {
        j.objMap[type_] = append(j.objMap[type_], objs...)
    }
}

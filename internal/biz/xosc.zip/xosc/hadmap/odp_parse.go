package hadmap

import (
    "fmt"
    "math"
    "sort"
    "sync"
    openDrive "wuwen.com/wwsi/internal/biz/xosc/hadmap/odp"
    "wuwen.com/wwsi/util/wuwen/mapper"
)

func NewODParse() DataParse {
    return &ODParse{}
}

func (odp *ODParse) parse(dataPath string) bool {
    odp.BoundPKID = 1
    odp.LinkPKID = 1
    odp.TxRoads = make(map[Roadpkid]*openDrive.OpenDRIVERoad)
    odp.TxLinks = make( map[string]TXLaneLinks)
    odp.TxJunctions = make(map[Junctionpkid]openDrive.OpenDRIVEJunction)
    odp.TxObjects = make( map[Roadpkid]TXObjects)
    odp.TxRoads = make( map[Roadpkid]TXRoads)
    odp.TxLinks = make( map[string]TXLaneLinks)
    odp.TxObjects = make( map[Roadpkid]TXObjects)


    openDRIVE, err := openDrive.WithFile(dataPath)

    odp.North,_ = mapper.Convert(openDRIVE.Header.North).Float64()
    odp.West,_ = mapper.Convert(openDRIVE.Header.West).Float64()
    odp.South,_ = mapper.Convert(openDRIVE.Header.South).Float64()
    odp.East,_ = mapper.Convert(openDRIVE.Header.East).Float64()


    odp.generateHeaderPtr(openDRIVE.Header)
    pointRef := txPoint{X: odp.West, Y: odp.South, Z: 0}

    juncMap := make(map[Junctionpkid]*openDrive.OpenDRIVEJunction)
    for _ ,junc:= range openDRIVE.Junction {
        i, _ := mapper.Convert(junc.ID).Uint64()
        juncMap[Junctionpkid(i)] = &junc
    }

    odp.TxJunctions = juncMap
    //controllerMap := make(map[int64]*Controller)
    //for elem := root.FirstChildElement("controller"); elem != nil; elem = elem.NextSiblingElement("controller") {
    //    ctl := &Controller{}
    //    if err := ctl.parse(elem); err != nil {
    //        continue
    //    }
    //    controllerMap[ctl.id()] = ctl
    //}

    var roads []*openDrive.OpenDRIVERoad
    roadsMap := make(map[Roadpkid]*openDrive.OpenDRIVERoad)
    for _, road := range openDRIVE.Road {
        i, _ := mapper.Convert(road.ID).Uint64()
        roads = append(roads, &road)
        roadsMap[Roadpkid(i)] = &road
    }

    odp.TxRoads = roadsMap

    for i := range roads {
        odp.DoRoad(roads[i])
    }


    return true
}

func (odp *ODParse) parseArea(dataPath string, vec AreaPointVec) bool {
    odp.BoundPKID = 1
    odp.LinkPKID = 1
    odp.TxRoads = make(map[Roadpkid]TXRoads)
    odp.TxLinks = make( map[string]TXLaneLinks)
    odp.TxJunctions = make(  map[Junctionpkid]TxJunctions)
    odp.TxObjects = make( map[Roadpkid]TXObjects)
    odp.TxRoads = make( map[Roadpkid]TXRoads)
    odp.TxLinks = make( map[string]TXLaneLinks)
    odp.TxJunctions = make( map[Junctionpkid]TxJunctions)
    odp.TxObjects = make( map[Roadpkid]TXObjects)

    openDRIVE, err := openDrive.WithFile(dataPath)


    if err := odp.odHeader.parse(headerElem); err != nil {
        return false
    }
    if err := odp.odHeader.getBBox(&odp.north, &odp.south, &odp.east, &odp.west); err != nil {
        return false
    }

    pointRef := txPoint{X: odp.west, Y: odp.south, Z: 0}

    juncMap := make(map[int64]*Junction)
    for elem := root.FirstChildElement("junction"); elem != nil; elem = elem.NextSiblingElement("junction") {
        junc := &Junction{}
        if err := junc.parse(elem); err != nil {
            continue
        }
        juncMap[junc.id()] = junc
    }

    controllerMap := make(map[int64]*Controller)
    for elem := root.FirstChildElement("controller"); elem != nil; elem = elem.NextSiblingElement("controller") {
        ctl := &Controller{}
        if err := ctl.parse(elem); err != nil {
            continue
        }
        controllerMap[ctl.id()] = ctl
    }

    // Transform ptr to ENU
    tmpRecVec := [][]txPoint{}
    for _, iter := range ptr {
        points := []txPoint{
            {X: iter.X1, Y: iter.Y1, Z: 0},
            {X: iter.X1, Y: iter.Y2, Z: 0},
            {X: iter.X2, Y: iter.Y2, Z: 0},
            {X: iter.X2, Y: iter.Y1, Z: 0},
        }
        pointsa := []txPoint{}
        for _, it := range points {
            lon, lat := it.X, it.Y
            lonlat2global(&it)
            pointsa = append(pointsa, it)
        }
        tmpRecVec = append(tmpRecVec, pointsa)
    }

    roads := []*Road{}
    for elem := root.FirstChildElement("road"); elem != nil; elem = elem.NextSiblingElement("road") {
        road := &Road{}
        if err := road.parse(elem); err != nil {
            continue
        }
        roads = append(roads, road)
    }

    thnum := 12
    var wg sync.WaitGroup
    for i := 0; i < thnum; i++ {
        odp.DoRoad(roads[i])
    }
    wg.Wait()

    otherIds := []int64{}
    for _, road := range roads {
        if road.junctionId() > 0 {
            preId := road.preRoadId()
            if _, ok := odp.txRoads[preId]; !ok && !contains(otherIds, preId) {
                otherIds = append(otherIds, preId)
            }
            succId := road.succRoadId()
            if _, ok := odp.txRoads[succId]; !ok && !contains(otherIds, succId) {
                otherIds = append(otherIds, succId)
            }
        }
    }

    otherRoads := []*Road{}
    for elem := root.FirstChildElement("road"); elem != nil; elem = elem.NextSiblingElement("road") {
        road := &Road{}
        if err := road.parse(elem); err != nil {
            continue
        }
        roadId := road.id()
        if contains(otherIds, roadId) {
            otherRoads = append(otherRoads, road)
        }
    }

    for i := 0; i < thnum; i++ {
        wg.Add(1)
        go func(i int) {
            defer wg.Done()
            doOtherRoad(thnum, i)
        }(i)
    }
    wg.Wait()

    // Further conversion of the remaining code here...

    return true

}
func (odp *ODParse) getData(roads TXRoads, links TXLaneLinks, objs TXObjects,
    juncs TxJunctions, header TxOdHeaderPtr, refPoint txPoint, doubleRoad bool) bool {
    if doubleRoad {
        odp.splitBilateral()
    }
    *roads = make(txRoads)
    for k, v := range odp.tx_roads {
        (*roads)[k] = v
    }

    *links = make(tXLaneLinks, 0)
    for _, v := range odp.tx_links {
        *links = append(*links, v...)
    }

    *objs = make(TXObjects, 0)
    for _, v := range odp.tx_objects {
        *objs = append(*objs, v...)
    }

    *juncs = make(common.txJunctions, 0)
    for _, v := range odp.tx_junctions {
        *juncs = append(*juncs, v)
    }

    *header = odp.tx_header
    *refPoint = odp.tx_refpoint
    return true
}

func (odp *ODParse) splitBilateral() {
    dummyId := roadpkid(100000000)
    for _, road := range tx_roads {
        if road.id > dummyId {
            dummyId = road.id
        }
    }
    dummyId = roadpkid(math.Pow(10, 1+math.Ceil(math.Log10(float64(dummyId)))))

    ReservePoints := func(curve *txGeometry) []txPoint {
        points := curve.points
        sort.Slice(points, func(i, j int) bool {
            return i > j
        })
        return points
    }

    new_roads := make(map[roadpkid]txRoadPtr)
    laneIdReplace := make(map[txLaneId]txLaneId)

    for roadId, road := range tx_roads {
        bil := false
        for _, section := range road.sections {
            if len(section.lanes) > 0 && section.lanes[0].id > 0 {
                bil = true
                break
            }
        }
        if bil {
            new_road := &txRoad{}
            new_road.setId(road.id + dummyId).setRoadType(roadType)
            new_road.setGeometry(ReservePoints(road.getGeometry()), coordType)
            // set curvature
            vecOld := road.getCurvature()
            vecNew := make([]txCurvature, 0)
            start_s := 0.0
            for i := len(vecOld) - 1; i >= 0; i-- {
                tmp := vecOld[i]
                tmp.m_starts = start_s
                vecNew = append(vecNew, tmp)
                start_s += tmp.m_length
            }
            new_road.setCurvature(vecNew)
            // set slope
            vecSlopeOld := road.getSlope()
            vecSlopeNew := make([]txSlope, 0)
            start_s = 0.0
            for i := len(vecSlopeOld) - 1; i >= 0; i-- {
                tmp := vecSlopeOld[i]
                tmp.m_starts = start_s
                vecSlopeNew = append(vecSlopeNew, tmp)
                start_s += tmp.m_length
            }
            new_road.setSlope(vecSlopeNew)

            remain_lane_num := 0
            for _, section := range road.sections {
                if len(section.lanes) == 0 {
                    // log warning
                    continue
                }
                new_sec := &txSection{}
                new_sec.setId(len(road.sections) - 1 - section.id)
                lanes := section.lanes
                assert(len(lanes)+1 == len(section.boundaries))
                nxLaneNum := 0
                for _, lane := range lanes {
                    if lane.id > 0 {
                        nxLaneNum++
                    }
                }
                if nxLaneNum == 0 {
                    continue
                }
                new_bound_ptrs := make([]*txLaneBoundary, nxLaneNum+1)
                for i := 0; i < len(new_bound_ptrs); i++ {
                    bound := section.boundaries[i]
                    new_bound := &txLaneBoundary{}
                    new_bound.setId(max_bound_pkid).setLaneMark(bound.laneMark)
                    new_bound.setGeometry(ReservePoints(bound.geometry), bound.geometry.coordType)
                    new_bound_ptrs[len(new_bound_ptrs)-1-i] = new_bound
                }
                for i := 0; i < nxLaneNum; i++ {
                    lane := lanes[nxLaneNum-1-i]
                    new_lane := &txLane{}
                    new_lane.setRoadId(new_road.id).setSectionId(new_sec.id).setId(-lane.id).setLaneType(lane.laneType).setLaneWidth(lane.laneWidth).setSpeedLimit(lane.speedLimit).setLaneArrow(lane.laneArrow)
                    new_lane.setGeometry(ReservePoints(lane.geometry), lane.geometry.coordType)
                    new_lane.setLeftBoundary(new_bound_ptrs[i])
                    new_lane.setRightBoundary(new_bound_ptrs[i+1])
                    new_sec.add(new_lane)
                    laneIdReplace[lane.getTxLaneId()] = new_lane.getTxLaneId()
                }
                new_sec.bindSectionPtr()
                new_sec.setMeanCurvature(section.getMeanCurvature())
                new_sec.setMeanSlope(section.getMeanSlope() * -1.0)
                new_road.addSection(new_sec)
                // remove old
                for i := 0; i < nxLaneNum; i++ {
                    section.lanes = section.lanes[1:]
                }
                remain_lane_num += len(section.lanes)
            }
            sections := new_road.getSections()
            sort.Slice(sections, func(i, j int) bool {
                return i > j
            })
            new_road.bindRoadPtr()
            new_roads[new_road.id] = new_road
            if remain_lane_num == 0 {
                delete(tx_roads, roadId)
                continue
            }
        }
    }

    if len(new_roads) == 0 {
        return
    }
    for id, road := range new_roads {
        tx_roads[id] = road
    }

    lanesAll := make(map[txLaneId]*txLane)
    for _, road := range tx_roads {
        for _, section := range road.sections {
            for _, lane := range section.lanes {
                lanesAll[lane.getTxLaneId()] = lane
            }
        }
    }

    Distance := func(p1, p2 txPoint, wgs bool) float64 {
        // implementation not provided
        return 0
    }

    for _, links := range tx_links {
        for _, link := range links {
            from := lanesAll[link.fromTxLaneId]
            to := lanesAll[link.toTxLaneId]
            // reverze
            fromType := link.getPreContact()
            toType := link.getSuccContact()
            if link.fromLaneId > 0 && laneIdReplace[link.fromTxLaneId] != 0 {
                newid := laneIdReplace[link.fromTxLaneId]
                assert(newid.roadId > 0)
                link.setFromRoadId(newid.roadId).setFromSectionId(newid.sectionId).setFromLaneId(newid.laneId)
                if fromType == "START" {
                    link.setPreContact("END")
                } else {
                    link.setPreContact("START")
                }
            }
            if link.toLaneId > 0 && laneIdReplace[link.toTxLaneId] != 0 {
                newid := laneIdReplace[link.toTxLaneId]
                assert(newid.roadId > 0)
                link.setToRoadId(newid.roadId).setToSectionId(newid.sectionId).setToLaneId(newid.laneId)
                if toType == "START" {
                    link.setSuccContact("END")
                } else {
                    link.setSuccContact("START")
                }
            }
            if link.getGeometry() == nil || len(link.getGeometry()) == 0 {
                continue
            }
            if from == nil || to == nil {
                continue
            }
            if from.getGeometry() == nil || to.getGeometry() == nil || len(from.getGeometry()) == 0 || len(to.getGeometry()) == 0 {
                continue
            }
            disF := Distance(link.getGeometry()[0], from.getGeometry()[len(from.getGeometry())-1], link.getGeometry().coordType == "COORD_WGS84")
            disB := Distance(link.getGeometry()[len(link.getGeometry())-1], to.getGeometry()[0], link.getGeometry().coordType == "COORD_WGS84")
            test_disF := Distance(link.getGeometry()[0], from.getGeometry()[0], link.getGeometry().coordType == "COORD_WGS84")
            test_disB := Distance(link.getGeometry()[len(link.getGeometry())-1], to.getGeometry()[len(to.getGeometry())-1], link.getGeometry().coordType == "COORD_WGS84")
            if (disF + disB) > (test_disB + test_disF) {
                link.setFromRoadId(to.getRoadId()).setFromSectionId(to.getSectionId()).setFromLaneId(to.getId())
                if link.getPreContact() == "START" {
                    link.setPreContact("END")
                } else {
                    link.setPreContact("START")
                }
                link.setToRoadId(from.getRoadId()).setToSectionId(from.getSectionId()).setToLaneId(from.getId())
                if link.getSuccContact() == "START" {
                    link.setSuccContact("END")
                } else {
                    link.setSuccContact("START")
                }
                link.setGeometry(ReservePoints(link.getGeometry()), link.getGeometry().coordType)
                leftBds := link.getLeftBoundaries()
                rightBds := link.getRightBoundaries()
                for _, bd := range leftBds {
                    if bd != nil {
                        bd.setGeometry(ReservePoints(bd.geometry), bd.geometry.coordType)
                    }
                }
                for _, bd := range rightBds {
                    if bd != nil {
                        bd.setGeometry(ReservePoints(bd.geometry), bd.geometry.coordType)
                    }
                }
                sort.Slice(leftBds, func(i, j int) bool {
                    return i > j
                })
                sort.Slice(rightBds, func(i, j int) bool {
                    return i > j
                })
                link.setLeftBoundaries(rightBds)
                link.setRightBoundaries(leftBds)
            }
        }
    }

    for roadId, objs := range tx_objects {
        for _, obj := range objs {
            rlanes := obj.getReliedLaneIds()
            for i, rl := range rlanes {
                if laneIdReplace[rl] != 0 {
                    rlanes[i] = laneIdReplace[rl]
                }
            }
            obj.setReliedLaneIds(rlanes)
            // tunnel
            if obj.getObjectType() == "OBJECT_TYPE_Tunnel" {
                if tx_roads[roadId+dummyId] != nil {
                    userData := make(map[string]string)
                    userData["relate_road"] = fmt.Sprintf("%d", roadId+dummyId)
                    obj.setUserData(userData)
                    // add object
                    cur_object := &txObject{}
                    cur_object_data := obj.getTxData()
                    _s := tx_roads[roadId+dummyId].getLength() - (cur_object_data.s + cur_object_data.length)
                    cur_object_data.s = math.Max(_s, 0)
                    cur_object.setData(cur_object_data)
                    cur_object_od_data := obj.getOdData()
                    cur_object_od_data.s = math.Max(_s, 0)
                    userData = make(map[string]string)
                    userData["relate_road"] = fmt.Sprintf("%d", roadId)
                    cur_object.setTxOdData(cur_object_od_data)
                    cur_object.setOdRoadId(roadId + dummyId)
                    cur_object.setUserData(userData)
                    geomPtr := &txObjectGeom{}
                    cur_object.addGeom(geomPtr)
                    cur_object.setId(int(dummyId) + obj.id)
                    curve := make([]txPoint, 0)
                    curve = append(curve, tx_roads[roadId+dummyId].getGeometry().getPoint(cur_object_od_data.s))
                    geomPtr.setGeometry(curve, "COORD_WGS84")
                    if tx_objects[roadId+dummyId] == nil {
                        tx_objects[roadId+dummyId] = make([]*txObject, 0)
                    }
                    tx_objects[roadId+dummyId] = append(tx_objects[roadId+dummyId], cur_object)
                }
            }
        }
    }
}




func (odp *ODParse) DoRoad(curRoad *openDrive.OpenDRIVERoad) bool {
    curRoadID := curRoad.ID
    var roadGeom []struct{ X, Y float64 }
    var roadEle, roadInterval []float64

    curRoad.roadInterval(&roadInterval)
    curRoad.roadGeom(&roadGeom)
    curRoad.roadEle(&roadEle)

    for i := range roadGeom {
        roadGeom[i].X += odp.west
        roadGeom[i].Y += odp.south
    }

    if len(roadEle) < len(roadGeom) {
        h := 0.0
        if len(roadEle) > 0 {
            h = roadEle[len(roadEle)-1]
        }
        for len(roadEle) < len(roadGeom) {
            roadEle = append(roadEle, h)
        }
    }

    var txRoad *txRoadPtr
    eType := GetRoadType(curRoad.getRoadType())
    generateRoadPtr(curRoad.id(), eType, curRoad.speedlimit(), roadGeom, roadEle, &txRoad)

    if txRoad != nil {
        var startx, length, radios []float64
        curRoad.roadCurvature(&startx, &length, &radios)
        var curvatureVec txCurvatureVec

        for i := range startx {
            curvatureVec = append(curvatureVec, txCurvature{
                m_starts:    startx[i],
                m_length:    length[i],
                m_curvature: radios[i],
            })
        }
        txRoad.setCurvature(curvatureVec)

        var slopesStartx, slopesLength, slopes []float64
        curRoad.roadSlope(&slopesStartx, &slopesLength, &slopes)
        var slopeVec txSlopeVec

        for i := range slopesStartx {
            slopeVec = append(slopeVec, txSlope{
                m_starts: slopesStartx[i],
                m_length: slopesLength[i],
                m_slope:  slopes[i],
            })
        }
        txRoad.setSlope(slopeVec)

        if odp.odHeader.getVendor() == "tadsim v2.0" {
            var controlType string
            var controlPoints [][]float64
            curRoad.roadControlPoint(&controlType, &controlPoints)
            controlPoint := txControlPoint{m_type: controlType}

            for _, it := range controlPoints {
                controlPoint.m_points = append(controlPoint.m_points, txPoint{
                    X:   it[0],
                    Y:   it[1],
                    Z:   0,
                    Hdg: it[2],
                })
            }
            txRoad.setControlPoint(controlPoint)
        }

        crgs := curRoad.getCrgs()
        txRoad.setCrgs(GetOpenCrg(crgs))

        var eleControlPoints [][]float64
        curRoad.roadEleControlPoint(&eleControlPoints, curRoad.length(), odp.odHeader.getVendor())
        var cPoint txControlPoint

        for _, it := range eleControlPoints {
            cPoint.m_points = append(cPoint.m_points, txPoint{
                X: it[0],
                Y: it[1],
                Z: it[2],
            })
        }
        if len(cPoint.m_points) > 0 {
            cPoint.m_type = "catmullrom"
            txRoad.setElePoint(cPoint)
        }

        var sections txSections
        widDatas := make([]Wid_Data, curRoad.sectionSize())

        for secI := 0; secI < curRoad.sectionSize(); secI++ {
            var sec ODLaneSection
            curRoad.getSection(secI, &sec)
            disFromSec := widDatas[secI]._dis_from_sec[:0]
            curRoad.getSectionRange(secI, &secS, &secE)

            secS += 0.001
            secE -= 0.001

            if len(roadInterval) > 0 && secS < secE {
                disFromSec = append(disFromSec, secS)
                for _, d := range roadInterval {
                    if d > secS && d < secE {
                        disFromSec = append(disFromSec, d)
                    }
                }
                disFromSec = append(disFromSec, secE)
            }

            if len(disFromSec) == 0 {
                continue
            }

            secRefLine := widDatas[secI]._sec_ref_line[:0]
            secRefNormal := widDatas[secI]._sec_ref_normal[:0]
            secEle := widDatas[secI]._sec_ele[:0]

            curRoad.roadRef(&secRefLine, &disFromSec)
            curRoad.roadNormal(&secRefNormal, &disFromSec)
            curRoad.roadEle(&secEle, &disFromSec)

            for i := range secRefLine {
                secRefLine[i].X += odp.west
                secRefLine[i].Y += odp.south
            }

            for i := range disFromSec {
                disFromSec[i] -= secS - 0.001
            }

            laneWidths := widDatas[secI]._lane_width[:len(sec)]
            bdyWidths := widDatas[secI]._bdy_width[:len(sec)]

            for i := range laneWidths {
                laneWidths[i] = make([]float64, len(secRefLine))
            }
            for i := range bdyWidths {
                bdyWidths[i] = make([]float64, len(secRefLine))
            }

            width0 := make([]float64, len(secRefLine))

            for i := range sec {
                if sec.id() >= 0 {
                    continue
                }
                curWidth := []float64{}
                sec.width(disFromSec, &curWidth)
                for j := range secRefLine {
                    laneWidths[i][j] = width0[j] + curWidth[j]*0.5
                    width0[j] += curWidth[j]
                    bdyWidths[i][j] = width0[j]
                }
            }

            width0 = make([]float64, len(secRefLine))
            for i := len(sec) - 1; i >= 0; i-- {
                if sec.id() <= 0 {
                    continue
                }
                curWidth := []float64{}
                sec.width(disFromSec, &curWidth)
                for j := range secRefLine {
                    laneWidths[i][j] = width0[j] - curWidth[j]*0.5
                    width0[j] -= curWidth[j]
                    bdyWidths[i][j] = width0[j]
                }
            }

            for i := range sec {
                if sec.id() == 0 {
                    curWidth := []float64{}
                    sec.width(disFromSec, &curWidth)
                    bdyWidths[i] = curWidth
                    break
                }
            }

            curSec := &txSection{}
            curSec.setRoadId(curRoad.id()).setId(int64(secI))

            boundPtr := make([]*txLaneBoundaryPtr, len(bdyWidths))

            for i := range bdyWidths {
                boundGeom := make([]struct{ X, Y float64 }, len(secRefLine))
                for j := range secRefLine {
                    wid := bdyWidths[i][j]
                    boundGeom[j].X = secRefLine[j].X - secRefNormal[j].X*wid
                    boundGeom[j].Y = secRefLine[j].Y - secRefNormal[j].Y*wid
                }

                var boundPtrI *txLaneBoundaryPtr
                generateBoundaryPtr(0, sec.mark(), sec.lanewidth(), sec.lanedinterval(),
                    sec.laned_space(), sec.laned_soffset(), sec.laned_len(), boundGeom, secEle, &boundPtrI)

                odp.mutex.Lock()
                boundPtrI.setId(odp.boundPkid)
                odp.boundPkid++
                odp.mutex.Unlock()

                boundPtr[i] = boundPtrI
            }

            for i := range sec {
                if sec.id() == 0 {
                    continue
                }

                laneGeom := make([]struct{ X, Y float64 }, len(secRefLine))
                for j := range secRefLine {
                    laneGeom[j].X = secRefLine[j].X - secRefNormal[j].X*laneWidths[i][j]
                    laneGeom[j].Y = secRefLine[j].Y - secRefNormal[j].Y*laneWidths[i][j]
                }

                laneWidth := -1.0
                if i > 0 && len(bdyWidths[i]) > 0 {
                    laneWidth = 0.5 * (bdyWidths[i][0] - bdyWidths[i-1][0] +
                        bdyWidths[i][len(bdyWidths[i])-1] - bdyWidths[i-1][len(bdyWidths[i])-1])
                }

                getLaneWidth := func(front, back []float64) []float64 {
                    ret := make([]float64, len(front))
                    for i := range front {
                        ret[i] = back[i] - front[i]
                    }
                    return ret
                }

                boundaryIndex := i
                if sec.id() > 0 {
                    boundaryIndex++
                }

                var lanePtr *txLanePtr
                generateLanePtr(curRoad.id(), int64(secI), int64(sec.id()), sec.type(), curRoad.speedlimit(),
                    laneWidth, sec.surface(), sec.friction(), sec.lane_material_sOffset(),
                    laneGeom, secEle, getLaneWidth(bdyWidths[boundaryIndex], bdyWidths[boundaryIndex-1]), &lanePtr)

                if len(boundPtr) > 0 {
                    if sec.id() < 0 {
                        lanePtr.setLeftBoundary(boundPtr[i-1])
                        lanePtr.setRightBoundary(boundPtr[i])
                    } else {
                        lanePtr.setLeftBoundary(boundPtr[i])
                        lanePtr.setRightBoundary(boundPtr[i+1])
                    }
                }

                if lanePtr.getSpeedLimit() == 0 {
                    lanePtr.setSpeedLimit(curRoad.speedlimit())
                }

                curSec.add(lanePtr)
                curSec.bindSectionPtr()
            }

            startf, length := 0.0, 0.0
            curRoad.getSectionRange(secI, &startf, &length)
            length -= startf
            curSec.setMeanSlope(GetMeanSlope(txRoad, startf, length))
            curSec.setMeanCurvature(GetMeanCurvature(txRoad, startf, length))
            sections = append(sections, curSec)
        }
        txRoad.setSections(sections)
        txRoad.bindRoadPtr()
        odp.mutex.Lock()
        odp.txRoads[curRoad.id()] = txRoad
        odp.mutex.Unlock()
    } else {
        fmt.Println("Assertion failed")
    }

    var objs []ODRoadObject
    curRoad.getObjects(&objs)
    var objects TXObjects
    for i := range objs {
        var objPtr *txObject
        parseObject(objs[i], &objPtr, odp.west, odp.south)
        objPtr.setOdRoadId(curRoad.id())
        if objPtr != nil {
            var rlanes []txLaneId
            objPtr.getReliedLaneIds(&rlanes)
            for _, lid := range objs[i].validityLane {
                sectionid := int64(-1)
                if txRoad != nil {
                    sectionid = curRoad.getSectionIdx(objs[i].s)
                }
                rlanes = append(rlanes, txLaneId{
                    RoadId:    curRoadID,
                    SectionId: sectionid,
                    LaneId:    lid,
                })
            }
            objPtr.setReliedLaneIds(rlanes)
            objects = append(objects, objPtr)
        }
    }

    odp.mutex.Lock()
    odp.txObjects[curRoad.id()] = objects
    odp.mutex.Unlock()
    return true
}
func (odp *ODParse) DoLink(curRoad *Road) bool {
    curRoadID := curRoad.id()
    invalidDouble := math.MaxFloat64

    distanceBetweenP := func(p0, p1 txPoint) float64 {
        return math.Sqrt(math.Pow(p0.X-p1.X, 2) + math.Pow(p0.Y-p1.Y, 2) + math.Pow(p0.Z-p1.Z, 2))
    }

    hookUpLines := func(line, base PointVec, fixLen float64) PointVec {
        nline := make(PointVec, len(line))
        copy(nline, line)
        const equalDis = 0.5
        passD := 0.0
        const pi2 = 1.5707963267948966192313216916398
        const e = 2.7182818284590452353602874713527
        for k := range line {
            if k > 0 {
                passD += distanceBetweenP(line[k], line[k-1])
            }
            if passD >= fixLen {
                break
            }
            p1 := line[k]
            p0 := base[k]
            d := passD*10/fixLen - 5
            alpha := 1 / (1 + math.Pow(e, -d))
            x := p1.X - p0.X
            y := p1.Y - p0.Y
            z := p1.Z - p0.Z
            x *= alpha
            y *= alpha
            z *= alpha
            nline[k].X = p0.X + x
            nline[k].Y = p0.Y + y
            nline[k].Z = p0.Z + z
        }
        return nline
    }

    getLanePoint := func(laneid txLaneId, front bool) txPoint {
        p := txPoint{X: invalidDouble, Y: invalidDouble, Z: invalidDouble}
        if road, ok := tx_roads[laneid.RoadId]; ok {
            lanes := road.getSections()[laneid.SectionId].getLanes()
            for _, lane := range lanes {
                if lane.getId() == laneid.LaneId {
                    if geom := lane.getGeometry(); geom != nil && !geom.empty() {
                        if front {
                            p = geom.getStart()
                        } else {
                            p = geom.getEnd()
                        }
                    }
                    break
                }
            }
        }
        return p
    }

    if road, ok := tx_roads[curRoadID]; ok {
        if curRoad.junctionId() > 0 {
            if curRoad.preRoadId() == ROAD_PKID_INVALID || curRoad.succRoadId() == ROAD_PKID_INVALID {
                mutex.Lock()
                to_erase_ids = append(to_erase_ids, curRoadID)
                mutex.Unlock()
            } else if road, ok := tx_roads[curRoadID]; ok {
                fromRid := curRoad.preRoadId()
                toRid := curRoad.succRoadId()

                if fromRoad, fromOk := tx_roads[fromRid]; fromOk &&
                    toRoad, toOk := tx_roads[toRid]; toOk &&
                    len(fromRoad.getSections()) > 0 && len(toRoad.getSections()) > 0 {

                    fromSid := if curRoad.preRoadCont() == ODLink_START { 0 } else { len(fromRoad.getSections()) - 1 }
                    toSid := if curRoad.succRoadCont() == ODLink_START { 0 } else { len(toRoad.getSections()) - 1 }

                    var lanelinks [][]lanepkid
                    curRoad.links(&lanelinks)

                    linkBds := make(map[laneboundarypkid]*txLaneBoundaryPtr)

                    vec := road.getCurvature()
                    slope := road.getSlope()

                    for _, lanelink := range lanelinks {
                        fromRid := fromRid
                        toRid := toRid
                        fromSid := fromSid
                        toSid := toSid
                        fromLid := lanelink[0]
                        toLid := lanelink[len(lanelink)-1]

                        linkPtr := &txLaneLink{}
                        Apoints := PointVec{}
                        coordType := COORD_ENU
                        leftBds := txLaneBoundaries{}
                        rightBds := txLaneBoundaries{}
                        preCon := txContactType(curRoad.preRoadCont())
                        toCon := txContactType(curRoad.succRoadCont())

                        for i, is := range lanelink[1 : len(lanelink)-1] {
                            lanes := road.getSections()[i].getLanes()
                            for _, lane := range lanes {
                                if lane.getId() == lanelink[i+1] {
                                    points := PointVec{}
                                    lane.getGeometry().getPoints(&points)
                                    Apoints = append(Apoints, points...)
                                    coordType = lane.getGeometry().getCoordType()

                                    if l_bdy := lane.getLeftBoundary(); l_bdy != nil {
                                        id := l_bdy.getId()
                                        if _, found := linkBds[id]; !found {
                                            linkBds[id] = &txLaneBoundary(*l_bdy)
                                        }
                                        leftBds = append(leftBds, linkBds[id])
                                    }
                                    if r_bdy := lane.getRightBoundary(); r_bdy != nil {
                                        id := r_bdy.getId()
                                        if _, found := linkBds[id]; !found {
                                            linkBds[id] = &txLaneBoundary(*r_bdy)
                                        }
                                        rightBds = append(rightBds, linkBds[id])
                                    }
                                    break
                                }
                            }
                        }

                        revs := len(lanelink) > 2 && lanelink[1] > 0
                        if revs {
                            fromRid, toRid = toRid, fromRid
                            fromSid, toSid = toSid, fromSid
                            fromLid, toLid = toLid, fromLid
                            reversePoints(Apoints)
                            _preCon, _toCon = toCon, preCon
                            reverseBoundaries(leftBds)
                            reverseBoundaries(rightBds)
                            leftBds, rightBds = rightBds, leftBds
                        }

                        linkPtr.setId(0).
                            setFromRoadId(fromRid).
                            setFromSectionId(fromSid).
                            setFromLaneId(fromLid).
                            setToRoadId(toRid).
                            setToSectionId(toSid).
                            setToLaneId(toLid).
                            setJunctionId(curRoad.junctionId()).
                            setLeftBoundaries(leftBds).
                            setRightBoundaries(rightBds).
                            setOdrRoadId(curRoadID).
                            setPreContact(preCon).
                            setSuccContact(toCon)

                        if odp.odHeader.getVendor() == "tadsim v2.0" {
                            controlType := ""
                            controlPoints := [][]float64{}
                            curRoad.roadControlPoint(&controlType, &controlPoints)
                            point := txControlPoint{m_type: controlType}
                            for _, cp := range controlPoints {
                                point.m_points = append(point.m_points, txPoint{X: cp[0], Y: cp[1], Z: 0, Hdg: cp[2]})
                            }
                            linkPtr.setControlPoint(point)
                        }

                        points := [][]float64{}
                        curRoad.roadEleControlPoint(&points, curRoad.length(), odp.odHeader.getVendor())
                        cPoint := txControlPoint{}
                        for _, p := range points {
                            cPoint.m_points = append(cPoint.m_points, txPoint{X: p[0], Y: p[1], Z: p[2]})
                        }
                        if len(cPoint.m_points) > 0 {
                            cPoint.m_type = "catmullrom"
                            linkPtr.setEleControlPoint(cPoint)
                        }
                        linkPtr.setGeometry(Apoints, coordType)
                        linkPtr.setSlope(slope)
                        linkPtr.setCurvature(vec)

                        index := fmt.Sprintf("%d_%d", fromRid, toRid)
                        mutex.Lock()
                        exist := false
                        for _, link := range tx_links[index] {
                            if link.fromRoadId() == fromRid && link.toRoadId() == toRid &&
                                link.fromSectionId() == fromSid && link.toSectionId() == toSid &&
                                link.fromLaneId() == fromLid && link.toLaneId() == toLid {
                                exist = true
                                break
                            }
                        }
                        if !exist {
                            linkPtr.setId(_link_pkid)
                            _link_pkid++
                            tx_links[index] = append(tx_links[index], linkPtr)
                            linkofjunction[linkPtr.getId()] = curRoad.junctionId()
                        }
                        mutex.Unlock()
                    }
                }

                mutex.Lock()
                to_erase_ids = append(to_erase_ids, curRoadID)
                mutex.Unlock()
            }
        } else {
            links := generateRoadLinks(curRoad)
            if len(links) > 0 {
                mutex.Lock()
                for _, link_ptr := range links {
                    index := fmt.Sprintf("%d_%d", link_ptr.fromRoadId(), link_ptr.toRoadId())
                    exist := false
                    for _, link := range tx_links[index] {
                        if *link == *link_ptr {
                            exist = true
                            break
                        }
                    }
                    if !exist {
                        if road, ok := tx_roads[curRoadID]; ok {
                            link_ptr.setSlope(road.getSlope())
                            link_ptr.setCurvature(road.getCurvature())
                        }
                        link_ptr.setId(_link_pkid)
                        _link_pkid++
                        tx_links[index] = append(tx_links[index], link_ptr)
                    }
                }
                mutex.Unlock()

                const fixLen = 20.0
                prevLanelinksbuf := make(map[txLaneId]map[txLaneId]struct{})
                nextLanelinksbuf := make(map[txLaneId]map[txLaneId]struct{})

                for _, link_ptr := range links {
                    if link_ptr.fromRoadId() != curRoadID {
                        if _, found := prevLanelinksbuf[link_ptr.fromTxLaneId()]; !found {
                            prevLanelinksbuf[link_ptr.fromTxLaneId()] = make(map[txLaneId]struct{})
                        }
                        prevLanelinksbuf[link_ptr.fromTxLaneId()][link_ptr.toTxLaneId()] = struct{}{}
                    } else if link_ptr.toRoadId() != curRoadID {
                        if _, found := nextLanelinksbuf[link_ptr.toTxLaneId()]; !found {
                            nextLanelinksbuf[link_ptr.toTxLaneId()] = make(map[txLaneId]struct{})
                        }
                        nextLanelinksbuf[link_ptr.toTxLaneId()][link_ptr.fromTxLaneId()] = struct{}{}
                    }
                }

                for prev, targets := range prevLanelinksbuf {
                    if len(targets) <= 1 {
                        continue
                    }
                    endP := getLanePoint(prev, false)
                    if endP.X == invalidDouble {
                        continue
                    }
                    nearest := txLaneId{ROAD_PKID_INVALID, SECT_PKID_INVALID, LANE_PKID_INVALID}
                    nearestDis := invalidDouble
                    for target := range targets {
                        startP := getLanePoint(target, true)
                        if startP.X == invalidDouble {
                            continue
                        }
                        d := distanceBetweenP(startP, endP)
                        if d < nearestDis {
                            nearestDis = d
                            nearest = target
                        }
                    }
                    if nearest.RoadId != ROAD_PKID_INVALID && nearestDis < 0.5 {
                        road := tx_roads[nearest.RoadId]
                        lanes := road.getSections()[nearest.SectionId].getLanes()
                        geom := lanes.find(nearest.laneId).getGeometry().(*txLineCurve)
                        pts := geom.getPoints()
                        for target := range targets {
                            if target == nearest {
                                continue
                            }
                            lane := lanes.find(target.laneId)
                            if lane.getLeftBoundary().getId() == nearest.laneId ||
                                lane.getRightBoundary().getId() == nearest.laneId {
                                continue
                            }
                            laneGeom := lane.getGeometry().(*txLineCurve)
                            newLine := hookUpLines(laneGeom.getPoints(), pts, fixLen)
                            lane.setGeometry(newLine, laneGeom.getCoordType())
                        }
                    }
                }

                for next, targets := range nextLanelinksbuf {
                    if len(targets) <= 1 {
                        continue
                    }
                    startP := getLanePoint(next, true)
                    if startP.X == invalidDouble {
                        continue
                    }
                    nearest := txLaneId{ROAD_PKID_INVALID, SECT_PKID_INVALID, LANE_PKID_INVALID}
                    nearestDis := invalidDouble
                    for target := range targets {
                        endP := getLanePoint(target, false)
                        if endP.X == invalidDouble {
                            continue
                        }
                        d := distanceBetweenP(startP, endP)
                        if d < nearestDis {
                            nearestDis = d
                            nearest = target
                        }
                    }
                    if nearest.RoadId != ROAD_PKID_INVALID && nearestDis < 0.5 {
                        road := tx_roads[nearest.RoadId]
                        lanes := road.getSections()[nearest.SectionId].getLanes()
                        geom := lanes.find(nearest.laneId).getGeometry().(*txLineCurve)
                        pts := geom.getPoints()
                        reversePoints(pts)
                        for target := range targets {
                            if target == nearest {
                                continue
                            }
                            lane := lanes.find(target.laneId)
                            if lane.getLeftBoundary().getId() == nearest.laneId ||
                                lane.getRightBoundary().getId() == nearest.laneId {
                                continue
                            }
                            laneGeom := lane.getGeometry().(*txLineCurve)
                            newLine := hookUpLines(reversePoints(laneGeom.getPoints()), pts, fixLen)
                            reversePoints(newLine)
                            lane.setGeometry(newLine, laneGeom.getCoordType())
                        }
                    }
                }
            }
        }
    }

    return true
}


func (odp *ODParse) GetMeanCurvature(txRoad *txRoadPtr, startf, length float64) float64 {
    curvatureSum := 0.0
    lengthSum2 := 0.0
    for _, curvature := range txRoad.curvature {
        tmpLength := 0.0
        if curvature.m_starts < startf && (curvature.m_starts+curvature.m_length < startf+length) {
            continue
        }
        if curvature.m_starts > startf && (curvature.m_starts+curvature.m_length > startf+length) {
            continue
        }
        tmpLength = curvature.m_length
        if curvature.m_starts < startf {
            tmpLength = curvature.m_length - (startf - curvature.m_starts)
        }
        if curvature.m_starts+curvature.m_length > startf+length {
            tmpLength = curvature.m_length - (curvature.m_starts + curvature.m_length - startf - length)
        }
        curvatureSum += (curvature.m_curvature * tmpLength)
        lengthSum2 += tmpLength
    }
    if lengthSum2 != 0 {
        return curvatureSum / lengthSum2
    }
    return 0.0
}

func (odp *ODParse) GetMeanSlope(txRoad *txRoadPtr, startf, length float64) float64 {
    slopeSum := 0.0
    lengthSum := 0.0
    for _, slope := range txRoad.slope {
        tmpLength := 0.0
        if slope.m_starts < startf && (slope.m_starts+slope.m_length < startf+length) {
            continue
        }
        if slope.m_starts > startf && (slope.m_starts+slope.m_length > startf+length) {
            continue
        }
        tmpLength = slope.m_length
        if slope.m_starts < startf {
            tmpLength = slope.m_length - (startf - slope.m_starts)
        }
        if slope.m_starts+slope.m_length > startf+length {
            tmpLength = slope.m_length - (slope.m_starts + slope.m_length - startf - length)
        }
        slopeSum += (slope.m_slope * tmpLength)
        lengthSum += tmpLength
    }
    if lengthSum != 0 {
        return slopeSum / lengthSum
    }
    return 0.0
}

func (odp *ODParse) GetOpenCrg(odcrg []ODCrg) []txOpenCrg {
    var crgvec []txOpenCrg
    for _, itCrg := range odcrg {
        crgvec = append(crgvec, txOpenCrg{
            m_file:       itCrg.getFile(),
            m_orientation: itCrg.getOrientation(),
            m_mode:        itCrg.getMode(),
            m_purpose:     itCrg.getPurpose(),
            m_soffset:     itCrg.getSOffset(),
            m_toffset:     itCrg.getTOffset(),
            m_zoffset:     itCrg.getZOffset(),
            m_zscale:      itCrg.getZScale(),
            m_hoffset:     itCrg.getHOffset(),
        })
    }
    return crgvec
}

func (odp *ODParse) GetRoadType(roadType string) ROAD_TYPE {
    switch roadType {
    case "rural":
        return ROAD_TYPE_ODR_Rural
    case "motorway":
        return ROAD_TYPE_ODR_Motorway
    case "town":
        return ROAD_TYPE_ODR_Town
    case "lowspeed":
        return ROAD_TYPE_ODR_LowSpeed
    case "pedestrian":
        return ROAD_TYPE_ODR_Pedestrian
    default:
        return ROAD_TYPE_Normal
    }
}
func (odp *ODParse) generateRoadLinks(odRoadPtr ODRoadPtr, links TXLaneLinks) {
    var preLinks, succLinks []LinkPair

    odRoadPtr.predecessor(&preLinks)
    odRoadPtr.successor(&succLinks)

    if len(preLinks) == 0 && len(succLinks) == 0 {
        return
    }

    fromRid := odRoadPtr.preRoadId()
    curRid := odRoadPtr.id()
    toRid := odRoadPtr.succRoadId()

    fromRt := odRoadPtr.preRoadType()
    toRt := odRoadPtr.succRoadType()

    preContactPoint := odRoadPtr.preRoadCont()
    succContactPoint := odRoadPtr.succRoadCont()

    if fromRid != ROAD_PKID_INVALID && fromRt == ODLink.ROAD && len(preLinks) != 0 &&
        odp.tx_roads[fromRid] != nil {
        sort.Slice(preLinks, func(i, j int) bool {
            if preLinks[i].First == preLinks[j].First {
                return preLinks[i].Second > preLinks[j].Second
            }
            return preLinks[i].First > preLinks[j].First
        })

        fromSid := 0
        if preContactPoint != ODLink.START {
            fromSid = len(odp.tx_roads[fromRid].getSections()) - 1
        }
        for _, p := range preLinks {
            fromRid := fromRid
            fromSid := fromSid
            fromLid := p.First
            toRid := curRid
            toSid := 0
            toLid := p.Second
            revs := toLid > 0
            if revs {
                fromRid, toRid = toRid, fromRid
                fromSid, toSid = toSid, fromSid
                fromLid, toLid = toLid, fromLid
            }

            linkPtr := new(txLaneLinkPtr)
            (*linkPtr).
                setId(0).
                setFromRoadId(fromRid).
                setFromSectionId(fromSid).
                setFromLaneId(fromLid).
                setToRoadId(toRid).
                setToSectionId(toSid).
                setToLaneId(toLid)

            linkPtr.setPreContact(txContactType(preContactPoint))
            linkPtr.setSuccContact(txContactType(succContactPoint))
            links = append(links, linkPtr)
        }
    }

    if toRid != ROAD_PKID_INVALID && toRt == ODLink.ROAD && len(succLinks) != 0 &&
        odp.tx_roads[toRid] != nil {
        sort.Slice(succLinks, func(i, j int) bool {
            if succLinks[i].First == succLinks[j].First {
                return succLinks[i].Second > succLinks[j].Second
            }
            return succLinks[i].First > succLinks[j].First
        })

        fromSid := odRoadPtr.sectionSize() - 1
        toSid := 0
        if succContactPoint != ODLink.START {
            toSid = len(odp.tx_roads[toRid].getSections()) - 1
        }
        for _, p := range succLinks {
            fromRid := curRid
            fromSid := fromSid
            fromLid := p.First
            toRid := toRid
            toSid := toSid
            toLid := p.Second
            revs := fromLid > 0
            if revs {
                fromRid, toRid = toRid, fromRid
                fromSid, toSid = toSid, fromSid
                fromLid, toLid = toLid, fromLid
            }
            linkPtr := new(txLaneLinkPtr)
            (*linkPtr).
                setId(0).
                setFromRoadId(fromRid).
                setFromSectionId(fromSid).
                setFromLaneId(fromLid).
                setToRoadId(toRid).
                setToSectionId(toSid).
                setToLaneId(toLid)
            linkPtr.setPreContact(txContactType(preContactPoint))
            linkPtr.setSuccContact(txContactType(succContactPoint))
            links = append(links, linkPtr)
        }
    }

    if fromRid == ROAD_PKID_INVALID {
        curRoadId := odRoadPtr.id()
        endSections := odp.tx_roads[curRoadId].getSections()[len(odp.tx_roads[curRoadId].getSections())-1]
        for _, lane := range endSections.getLanes() {
            laneId := lane.getTxLaneId()
            startPoint := std.get<0>(odp.m_laneidToStartAndEndPoint[laneId])
            for _, it := range odp.m_laneidToStartAndEndPoint {
                endPoint := std.get<1>(it.second)
                distance := math.Pow(startPoint.x-endPoint.x, 2) + math.Pow(startPoint.y-endPoint.y, 2)
                if distance < 1.0 {
                    linkPtr := new(txLaneLinkPtr)
                    (*linkPtr).
                        setId(0).
                        setFromRoadId(it.first.roadId).
                        setFromSectionId(it.first.sectionId).
                        setFromLaneId(it.first.laneId).
                        setToRoadId(laneId.roadId).
                        setToSectionId(laneId.sectionId).
                        setToLaneId(laneId.laneId)
                    linkPtr.setPreContact(txContactType.END)
                    linkPtr.setSuccContact(txContactType.START)
                    links = append(links, linkPtr)
                }
            }
        }
    }
}
func (odp *ODParse) calcRefLineLen(refLine []Pair, disFromBegin []float64) {
    disFromBegin = make([]float64, len(refLine))
    for i := 1; i < len(refLine); i++ {
        .frontP := refLine[i-1]
        .curP := refLine[i]

        x := curP.first - frontP.first
        y := curP.second - frontP.second
        dis := math.Sqrt(x*x + y*y)
        disFromBegin[i] = disFromBegin[i-1] + dis
    }
}
func (odp *ODParse) generateHeaderPtr(header openDrive.OpenDRIVEHeader) {
    //var north, south, east, west float64
    txHeader :=NewtxOdHeader()
    txHeader.instancePtr.Georeference = header.GeoReference.Text

    txHeader.instancePtr.North,_ = mapper.Convert(header.North).Float64()
    txHeader.instancePtr.West,_ = mapper.Convert(header.West).Float64()
    txHeader.instancePtr.South,_ = mapper.Convert(header.South).Float64()
    txHeader.instancePtr.East,_ = mapper.Convert(header.East).Float64()
    txHeader.instancePtr.East,_ = mapper.Convert(header.East).Float64()
    //txHeader.instancePtr.Vendor,_ = mapper.Convert(header.).Float64()
    txHeader.instancePtr.RevMinor = mapper.Convert(header.RevMinor).String()
    txHeader.instancePtr.RevMajor = mapper.Convert(header.RevMajor).String()
    odp.TxHeader = txHeader
}

func (odp *ODParse) generateSecRefInfo(refLine []Pair, refNormal []Pair, roadEle []float64, disFromBegin []float64, s float64, e float64, secRefLine []Pair, secRefNormal []Pair, secEle []float64, disFromSec []float64) {
    if len(refLine) != len(refNormal) || len(refNormal) != len(disFromBegin) {
        panic(errors.New("generate lane geom error, refference info size error"))
    }

    var laneRefLine []Pair = secRefLine
    var laneRefNormal []Pair = secRefNormal
    var laneDisFromSection []float64 = disFromSec
    var laneEle []float64 = secEle

    var range_ []int
    for i := 0; i < len(disFromBegin); i++ {
        if math.Abs(disFromBegin[i]-s) < 0.1 {
            range_ = append(range_, i)
        } else if math.Abs(disFromBegin[i]-e) < 0.1 {
            range_ = append(range_, i)
            break
        } else if s < disFromBegin[i] && disFromBegin[i] < e {
            range_ = append(range_, i)
        }
    }

    for i := 0; i < len(range_); i++ {
        index := range_[i]
        if index == 0 || index == len(refLine)-1 || (0 < i && i < len(range_)-1) ||
            math.Abs(disFromBegin[index]-s) < 0.1 || math.Abs(disFromBegin[index]-e) < 0.1 {
            laneRefLine = append(laneRefLine, refLine[index])
            laneRefNormal = append(laneRefNormal, refNormal[index])
            laneEle = append(laneEle, roadEle[index])
            laneDisFromSection = append(laneDisFromSection, disFromBegin[index]-s)
        } else {
            var frontIndex, backIndex int
            var offset float64
            if i == 0 {
                frontIndex = index - 1
                backIndex = index
                offset = s - disFromBegin[frontIndex]
            } else {
                frontIndex = index
                backIndex = index + 1
                offset = e - disFromBegin[frontIndex]

                // insert cur info
                laneRefLine = append(laneRefLine, refLine[index])
                laneRefNormal = append(laneRefNormal, refNormal[index])
                laneDisFromSection = append(laneDisFromSection, disFromBegin[index]-s)
            }

            xDir := refLine[backIndex].first - refLine[frontIndex].first
            yDir := refLine[backIndex].second - refLine[frontIndex].second
            dirLen := math.Sqrt(xDir*xDir + yDir*yDir)
            xDir /= dirLen
            yDir /= dirLen
            x := refLine[frontIndex].first + xDir*offset
            y := refLine[frontIndex].second + yDir*offset
            laneRefLine = append(laneRefLine, Pair{x, y})

            xNormal := refNormal[frontIndex].first + refNormal[backIndex].first
            yNormal := refNormal[frontIndex].second + refNormal[backIndex].second
            normalLen := math.Sqrt(xNormal*xNormal + yNormal*yNormal)
            xNormal /= normalLen
            yNormal /= normalLen
            laneRefNormal = append(laneRefNormal, Pair{xNormal, yNormal})

            laneEle = append(laneEle, (roadEle[frontIndex]+roadEle[backIndex])/2.0)

            if i == 0 {
                laneDisFromSection = append(laneDisFromSection, 0.0)
            } else {
                laneDisFromSection = append(laneDisFromSection, e-s)
            }

            if i == 0 {
                // insert front info
                laneRefLine = append(laneRefLine, refLine[index])
                laneRefNormal = append(laneRefNormal, refNormal[index])
                laneDisFromSection = append(laneDisFromSection, disFromBegin[index]-s)
            }
        }
    }
    // special case: only one point in range, should extend geom both in front and back direction
    if len(range_) == 1 {
        index := range_[0]
        var frontIndex, backIndex int
        var offset float64

        if index > 0 && math.Abs(disFromBegin[index]-e) < 0.1 {
            frontIndex = index - 1
            backIndex = index
            offset = s - disFromBegin[frontIndex]
        } else {
            frontIndex = index
            backIndex = index + 1
            offset = e - disFromBegin[frontIndex]
        }

        xDir := refLine[backIndex].first - refLine[frontIndex].first
        yDir := refLine[backIndex].second - refLine[frontIndex].second
        dirLen := math.Sqrt(xDir*xDir + yDir*yDir)
        xDir /= dirLen
        yDir /= dirLen
        x := refLine[frontIndex].first + xDir*offset
        y := refLine[frontIndex].second + yDir*offset

        xNormal := refNormal[frontIndex].first + refNormal[backIndex].first
        yNormal := refNormal[frontIndex].second + refNormal[backIndex].second
        normalLen := math.Sqrt(xNormal*xNormal + yNormal*yNormal)
        xNormal /= normalLen
        yNormal /= normalLen

        if index == backIndex {
            laneRefLine = append([]Pair{{x, y}}, laneRefLine...)
            laneRefNormal = append([]Pair{{xNormal, yNormal}}, laneRefNormal...)
            laneEle = append([]float64{(roadEle[frontIndex] + roadEle[backIndex]) / 2.0}, laneEle...)
            laneDisFromSection = append([]float64{0.0}, laneDisFromSection...)
        } else {
            laneRefLine = append(laneRefLine, Pair{x, y})
            laneRefNormal = append(laneRefNormal, Pair{xNormal, yNormal})
            laneEle = append(laneEle, (roadEle[frontIndex]+roadEle[backIndex])/2.0)
            laneDisFromSection = append(laneDisFromSection, e-s)
        }
    } else if len(range_) == 0 { // special case: no point in range, should extend geom both in front and back direction
        for i := 1; i < len(disFromBegin); i++ {
            if s < disFromBegin[i] {
                range_ = append(range_, i-1)
                break
            }
        }
        if len(range_) == 1 {
            index := range_[0]
            frontIndex := index
            backIndex := index + 1
            offsetFront := s - disFromBegin[frontIndex]
            offsetBack := e - disFromBegin[frontIndex]

            xDir := refLine[backIndex].first - refLine[frontIndex].first
            yDir := refLine[backIndex].second - refLine[frontIndex].second
            dirLen := math.Sqrt(xDir*xDir + yDir*yDir)
            xDir /= dirLen
            yDir /= dirLen
            xFront := refLine[frontIndex].first + xDir*offsetFront
            yFront := refLine[frontIndex].second + yDir*offsetFront
            xBack := refLine[frontIndex].first + xDir*offsetBack
            yBack := refLine[frontIndex].second + yDir*offsetBack

            xNormal := refNormal[frontIndex].first + refNormal[backIndex].first
            yNormal := refNormal[frontIndex].second + refNormal[backIndex].second
            normalLen := math.Sqrt(xNormal*xNormal + yNormal*yNormal)
            xNormal /= normalLen
            yNormal /= normalLen

            laneRefLine = append(laneRefLine, Pair{xFront, yFront})
            laneRefNormal = append(laneRefNormal, Pair{xNormal, yNormal})
            laneEle = append(laneEle, roadEle[frontIndex]+(roadEle[backIndex]-roadEle[frontIndex])*offsetFront/dirLen)
            laneDisFromSection = append(laneDisFromSection, 0.0)

            laneRefLine = append(laneRefLine, Pair{xBack, yBack})
            laneRefNormal = append(laneRefNormal, Pair{xNormal, yNormal})
            laneEle = append(laneEle, roadEle[frontIndex]+(roadEle[backIndex]-roadEle[frontIndex])*offsetBack/dirLen)
            laneDisFromSection = append(laneDisFromSection, e-s)
        }
    }

    for len(secEle) < len(secRefLine) {
        secEle = append(secEle, secEle[len(secEle)-1])
    }
}
func (odp *ODParse)ODParseObject(obj ODRoadObject, west, south float64) TxObject {
    var txPtr TxObject
    obtype := parseObjectType(obj)
    if obtype == OBJECT_TYPE_None {
        // return
    }
    if obj.st == "PARKING" {
        txPtr = &TxParkingSpace{}
        parkingSpace := txPtr.(*TxParkingSpace)
        for _, mark := range obj.parkingmark {
            var pmark *ParkingMarking
            switch mark.side {
            case "front":
                pmark = &parkingSpace.frontMarking
            case "rear":
                pmark = &parkingSpace.rearMarking
            case "left":
                pmark = &parkingSpace.leftMarking
            case "right":
                pmark = &parkingSpace.rightMarking
            }
            if pmark != nil {
                pmark.valid = true
                pmark.type = mark.type
                    pmark.width = mark.width
                switch mark.color {
                case "standard", "white":
                    pmark.color = OBJECT_COLOR_White
                case "blue":
                    pmark.color = OBJECT_COLOR_Blue
                case "green":
                    pmark.color = OBJECT_COLOR_Green
                case "red":
                    pmark.color = OBJECT_COLOR_Red
                case "yellow":
                    pmark.color = OBJECT_COLOR_Yellow
                }
            }
        }
    } else {
        txPtr = &TxObjectImpl{}
    }
    txPtr.setId(strtoull(obj.id, 10, 64))
    txPtr.setName(obj.name)
    txPtr.setLWH(obj.len, obj.wid, obj.hei)
    txPtr.setRPY(obj.roll, obj.pitch, obj.yaw)
    txPtr.setRawTypeString(obj.type, obj.subtype)
    txPtr.setObjectType(obj.name, obj.type, obj.subtype, obj.st)
    odData := txPtr.getOdData()
    odData.length = obj.len
    odData.width = obj.wid
    odData.height = obj.hei
    odData.roll = obj.roll
    odData.pitch = obj.pitch
    odData.hdg = obj.hdg
    odData.zoffset = obj.zoffset
    odData.s = obj.s
    odData.t = obj.t
    odData.orientation = 1
    odData.markWidth = obj.markwidth
    copy(odData.repeatdata[:], obj.repetaData)
    txp := Point{x: obj.x + west, y: obj.y + south, z: obj.z}
    txPtr.setST(obj.s, obj.t)
    txPtr.setTxOdData(odData)
    txPtr.setUserData(obj.userData)
    txPtr.setPos(txp.x, txp.y, txp.z)
    txPtr.transform2OdData()

    for i, geom := range obj.geom {
        closed := geom.first
        pts := geom.second
        curve := make([]Point, 0, len(pts))
        for _, p := range pts {
            curve = append(curve, Point{x: p.x + west, y: p.y + south, z: p.z})
        }
        if closed {
            curve = append(curve, curve[0])
        }
        var geomType ObjectGeometryType
        var style ObjectStyle
        if len(curve) == 0 {
            // Do nothing
        } else if len(curve) == 1 {
            geomType = OBJECT_GEOMETRY_TYPE_Point
        } else {
            parseObjectGeomType(obj, geomType, style)
        }
        var color ObjectColor
        switch obj.markcolor {
        case "white":
            color = OBJECT_COLOR_White
        case "red":
            color = OBJECT_COLOR_Red
        case "yellow":
            color = OBJECT_COLOR_Yellow
        case "blue":
            color = OBJECT_COLOR_Blue
        case "green":
            color = OBJECT_COLOR_Green
        case "black":
            color = OBJECT_COLOR_Black
        default:
            color = OBJECT_COLOR_Unknown
        }
        geomPtr := &TxObjGeomImpl{}
        geomPtr.setId(i)
        geomPtr.setType(geomType)
        geomPtr.setStyle(style)
        geomPtr.setGeometry(curve, COORD_ENU)
        geomPtr.setColor(color)
        txPtr.addGeom(geomPtr)
    }

    if len(obj.repeat) > 0 {
        curve := make([]Point, 0, len(obj.repeat))
        for _, p := range obj.repeat {
            curve = append(curve, Point{x: p.x + west, y: p.y + south, z: p.z, w: p.w, h: p.h})
        }
        rep := &TxLineCurveImpl{}
        rep.setCoords(curve)
        txPtr.setRepeat(rep)
    }

    return txPtr
}

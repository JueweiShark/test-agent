package hadmap

import (
    "sync"

    "wuwen.com/wwsi/internal/biz/xosc/common"
)

type MapDataType int

type IDataParse interface {
    GetDataType() MapDataType
    Parse(dataPath string) (bool, error)
    ParseArea(dataPath string, areaPoints []AreaPoint) (bool, error)
    GetData(roads *txRoads, links *TXLaneLinks, objs *TXObjects, juncs *common.txJunctions, header *txOdHeaderPtr, refPoint *txPoint, doubleRoad bool) (bool, error)
}

type dataParse struct {
    dataType  MapDataType
    parseFlag bool
    mu        sync.Mutex
}

func (dp *dataParse) GetDataType() MapDataType {
    return dp.dataType
}

package odp

import (
    "encoding/xml"
    "fmt"
    "io/ioutil"
    "os"
    "testing"
)

func TestName(t *testing.T) {
    file, err := os.Open("/Users/wangxmao/Downloads/sim_map_downtown_001.xodr")
    if err != nil {
        fmt.Println("Error opening file:", err)
        return
    }
    defer file.Close()

    byteValue, err := ioutil.ReadAll(file)
    if err != nil {
        fmt.Println("Error reading file:", err)
        return
    }

    var person OpenDRIVE
    err = xml.Unmarshal(byteValue, &person)
    if err != nil {
        fmt.Println("Error unmarshalling XML:", err)
        return
    }

    fmt.Println("Road:", len(person.Road), person.Road[1020].Junction)
    fmt.Println("Junction:", len(person.Junction))
}

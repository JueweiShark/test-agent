package odp

import (
    "encoding/xml"
    "io/ioutil"
    "os"

    "github.com/go-kratos/kratos/v2/log"
)

type OpenDRIVE struct {
    XMLName  xml.Name            `xml:"OpenDRIVE"`
    Text     string              `xml:",chardata"`
    Header   OpenDRIVEHeader     `xml:"header"`
    Road     []OpenDRIVERoad     `xml:"road"`
    Junction []OpenDRIVEJunction `xml:"junction"`
}

type OpenDRIVEHeader struct {
    Text         string                `xml:",chardata"`
    RevMajor     string                `xml:"revMajor,attr"`
    RevMinor     string                `xml:"revMinor,attr"`
    Name         string                `xml:"name,attr"`
    Version      string                `xml:"version,attr"`
    Date         string                `xml:"date,attr"`
    North        string                `xml:"north,attr"`
    South        string                `xml:"south,attr"`
    East         string                `xml:"east,attr"`
    West         string                `xml:"west,attr"`
    GeoReference OpenDRIVEGeoReference `xml:"geoReference"`
}

type OpenDRIVEGeoReference struct {
    Text string `xml:",chardata"`
}

type OpenDRIVERoad struct {
    Text             string                        `xml:",chardata"`
    Name             string                        `xml:"name,attr"`
    Length           string                        `xml:"length,attr"`
    ID               string                        `xml:"id,attr"`
    Junction         string                        `xml:"junction,attr"`
    Link             OpenDRIVERoadLink             `xml:"link"`
    Type             OpenDRIVERoadType             `xml:"type"`
    PlanView         OpenDRIVERoadPlanView         `xml:"planView"`
    ElevationProfile OpenDRIVERoadElevationProfile `xml:"elevationProfile"`
    LateralProfile   OpenDRIVERoadLateralProfile   `xml:"lateralProfile"`
    Lanes            OpenDRIVERoadLanes            `xml:"lanes"`
    Objects          OpenDRIVERoadObjects          `xml:"objects"`
    Signals          OpenDRIVERoadSignals          `xml:"signals"`
}

type OpenDRIVERoadLink struct {
    Text        string                   `xml:",chardata"`
    Predecessor OpenDRIVERoadElementLink `xml:"predecessor"`
    Successor   OpenDRIVERoadElementLink `xml:"successor"`
}

type OpenDRIVERoadElementLink struct {
    Text         string `xml:",chardata"`
    ElementType  string `xml:"elementType,attr"`
    ElementId    string `xml:"elementId,attr"`
    ContactPoint string `xml:"contactPoint,attr"`
}

type OpenDRIVERoadType struct {
    Text string `xml:",chardata"`
    S    string `xml:"s,attr"`
    Type string `xml:"type,attr"`
}

type OpenDRIVERoadPlanView struct {
    Text     string                  `xml:",chardata"`
    Geometry []OpenDRIVERoadGeometry `xml:"geometry"`
}

type OpenDRIVERoadGeometry struct {
    Text       string                   `xml:",chardata"`
    S          string                   `xml:"s,attr"`
    X          string                   `xml:"x,attr"`
    Y          string                   `xml:"y,attr"`
    Hdg        string                   `xml:"hdg,attr"`
    Length     string                   `xml:"length,attr"`
    Line       *OpenDRIVERoadLine       `xml:"line,omitempty"`
    ParamPoly3 *OpenDRIVERoadParamPoly3 `xml:"paramPoly3,omitempty"`
}

type OpenDRIVERoadLine struct {
    Text string `xml:",chardata"`
}

type OpenDRIVERoadParamPoly3 struct {
    Text   string `xml:",chardata"`
    AU     string `xml:"aU,attr"`
    BU     string `xml:"bU,attr"`
    CU     string `xml:"cU,attr"`
    DU     string `xml:"dU,attr"`
    AV     string `xml:"aV,attr"`
    BV     string `xml:"bV,attr"`
    CV     string `xml:"cV,attr"`
    DV     string `xml:"dV,attr"`
    PRange string `xml:"pRange,attr"`
}

type OpenDRIVERoadElevationProfile struct {
    Text      string                 `xml:",chardata"`
    Elevation OpenDRIVERoadElevation `xml:"elevation"`
}

type OpenDRIVERoadElevation struct {
    Text string `xml:",chardata"`
    S    string `xml:"s,attr"`
    A    string `xml:"a,attr"`
    B    string `xml:"b,attr"`
    C    string `xml:"c,attr"`
    D    string `xml:"d,attr"`
}

type OpenDRIVERoadLateralProfile struct {
    Text string `xml:",chardata"`
}

type OpenDRIVERoadLanes struct {
    Text        string                   `xml:",chardata"`
    LaneSection OpenDRIVERoadLaneSection `xml:"laneSection"`
}

type OpenDRIVERoadLaneSection struct {
    Text   string              `xml:",chardata"`
    S      string              `xml:"s,attr"`
    Center OpenDRIVERoadCenter `xml:"center"`
    Right  OpenDRIVERoadRight  `xml:"right"`
}

type OpenDRIVERoadCenter struct {
    Text string            `xml:",chardata"`
    Lane OpenDRIVERoadLane `xml:"lane"`
}

type OpenDRIVERoadRight struct {
    Text string              `xml:",chardata"`
    Lane []OpenDRIVERoadLane `xml:"lane"`
}

type OpenDRIVERoadLane struct {
    Text     string                `xml:",chardata"`
    ID       string                `xml:"id,attr"`
    Type     string                `xml:"type,attr"`
    Level    string                `xml:"level,attr"`
    Link     OpenDRIVERoadLaneLink `xml:"link"`
    Width    OpenDRIVERoadWidth    `xml:"width"`
    RoadMark OpenDRIVERoadRoadMark `xml:"roadMark"`
    Speed    OpenDRIVERoadSpeed    `xml:"speed"`
}

type OpenDRIVERoadLaneLink struct {
    Text        string                   `xml:",chardata"`
    Predecessor *OpenDRIVERoadElementRef `xml:"predecessor,omitempty"`
    Successor   *OpenDRIVERoadElementRef `xml:"successor,omitempty"`
}

type OpenDRIVERoadElementRef struct {
    Text string `xml:",chardata"`
    ID   string `xml:"id,attr"`
}

type OpenDRIVERoadWidth struct {
    Text    string `xml:",chardata"`
    SOffset string `xml:"sOffset,attr"`
    A       string `xml:"a,attr"`
    B       string `xml:"b,attr"`
    C       string `xml:"c,attr"`
    D       string `xml:"d,attr"`
}

type OpenDRIVERoadRoadMark struct {
    Text       string `xml:",chardata"`
    SOffset    string `xml:"sOffset,attr"`
    Type       string `xml:"type,attr"`
    Weight     string `xml:"weight,attr"`
    Color      string `xml:"color,attr"`
    Width      string `xml:"width,attr"`
    Height     string `xml:"height,attr"`
    Material   string `xml:"material,attr"`
    LaneChange string `xml:"laneChange,attr"`
}

type OpenDRIVERoadSpeed struct {
    Text    string `xml:",chardata"`
    SOffset string `xml:"sOffset,attr"`
    Max     string `xml:"max,attr"`
}

type OpenDRIVERoadObjects struct {
    Text   string              `xml:",chardata"`
    Tunnel OpenDRIVERoadTunnel `xml:"tunnel"`
}

type OpenDRIVERoadTunnel struct {
    Text     string                `xml:",chardata"`
    S        string                `xml:"s,attr"`
    Length   string                `xml:"length,attr"`
    Name     string                `xml:"name,attr"`
    ID       string                `xml:"id,attr"`
    Type     string                `xml:"type,attr"`
    Lighting string                `xml:"lighting,attr"`
    Daylight string                `xml:"daylight,attr"`
    UserData OpenDRIVERoadUserData `xml:"userData"`
}

type OpenDRIVERoadUserData struct {
    Text  string `xml:",chardata"`
    Code  string `xml:"code,attr"`
    Value string `xml:"value,attr"`
}

type OpenDRIVERoadSignals struct {
    Text string `xml:",chardata"`
}

type OpenDRIVEJunction struct {
    Text       string                        `xml:",chardata"`
    Name       string                        `xml:"name,attr"`
    ID         string                        `xml:"id,attr"`
    Connection []OpenDRIVEJunctionConnection `xml:"connection"`
}

type OpenDRIVEJunctionConnection struct {
    Text           string                      `xml:",chardata"`
    ConnectingRoad string                      `xml:"connectingRoad,attr"`
    ContactPoint   string                      `xml:"contactPoint,attr"`
    IncomingRoad   string                      `xml:"incomingRoad,attr"`
    ID             string                      `xml:"id,attr"`
    LaneLink       []OpenDRIVEJunctionLaneLink `xml:"laneLink"`
}

type OpenDRIVEJunctionLaneLink struct {
    Text string `xml:",chardata"`
    From string `xml:"from,attr"`
    To   string `xml:"to,attr"`
}

func WithFile(path string) (*OpenDRIVE, error) {
    file, err := os.Open(path)
    if err != nil {
        log.Error("Error opening file:", err)
        return nil, err
    }
    defer file.Close()

    byteValue, err := ioutil.ReadAll(file)
    if err != nil {
        log.Error("Error reading file:", err)
        return nil, err
    }

    var xodr OpenDRIVE
    err = xml.Unmarshal(byteValue, &xodr)
    if err != nil {
        log.Error("Error unmarshalling XML:", err)
        return nil, err
    }
    return &xodr, nil
}

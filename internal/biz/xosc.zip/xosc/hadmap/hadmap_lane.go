package hadmap

import (
    "errors"
    "fmt"
)

type txLane struct {
    instancePtr *laneData
}

type laneData struct {
    data             txLaneData
    geom             txLineCurve
    geomDense        txLineCurve
    leftBoundaryPtr  *txLaneBoundary
    rightBoundaryPtr *txLaneBoundary
    distanceToEnd    float64
    aveWidth         float64
    valid4Driving    bool
    sectionPtr       *txSection
}

type txLaneData struct {
    lane_id               int64
    left_boundary         uint32
    right_boundary        uint32
    lane_type             uint32
    lane_arrow            uint32
    speed_limit           uint32
    lane_surface          uint32
    lane_friction         float64
    lane_material_soffset float64
    road_pkid             uint32
    section_id            uint32
    name                  string
    geom                  []txPoint
    geomDense             []txPoint
}

func newLaneData() *laneData {
    return &laneData{
        geom:          txLineCurve{},
        geomDense:     txLineCurve{},
        distanceToEnd: -1.0,
        aveWidth:      -1.0,
        valid4Driving: true,
    }
}
func (lc *txLineCurve) empty() bool {
    return lc == nil
}

func (lc *txLineCurve) getLength() float64 {
    // Implement the logic to calculate the length of the line curve
    return 0.0
}

func (ld *laneData) xy2sl(x, y float64) (s, l float64, ok bool) {
    if ld.geom.empty() {
        return 0.0, 0.0, false
    }
    s, l, ok = ld.geom.xy2sl(x, y)
    if ld.data.lane_id > 0 {
        s = ld.geom.getLength() - s
        l *= -1
    }
    return s, l, ok
}

func (ld *laneData) sl2xy(s, l float64) (x, y float64, ok bool) {
    if ld.geom.empty() {
        return 0.0, 0.0, false
    }
    ns := s
    nl := l
    if ld.data.lane_id > 0 {
        ns = ld.geom.getLength() - s
        nl *= -1
    }
    x, y, ok = ld.geom.sl2xy(ns, nl)
    if ld.data.lane_id > 0 {
    }
    return x, y, ok
}

func (ld *laneData) getYaw(s float64) float64 {
    if ld.geom.empty() {
        return 0.0
    }
    return ld.geom.getYaw(s)
}

func newTxLane() *txLane {
    return &txLane{
        instancePtr: newLaneData(),
    }
}

func (tl *txLane) getTxLaneData() txLaneData {
    return tl.instancePtr.data
}

func (tl *txLane) getLinkType() string {
    return "LINK_TYPE_LANE"
}

func (tl *txLane) getGeometry() txCurve {
    return &tl.instancePtr.geom
}

func (tl *txLane) getDenseGeometry() txCurve {
    return &tl.instancePtr.geomDense
}

func (tl *txLane) getId() uint32 {
    return tl.instancePtr.data.lane_id
}

func (tl *txLane) getLeftBoundary() *txLaneBoundary {
    return tl.instancePtr.leftBoundaryPtr
}

func (tl *txLane) getLeftBoundaryId() uint32 {
    if tl.instancePtr.leftBoundaryPtr == nil {
        return tl.instancePtr.data.left_boundary
    }
    return tl.instancePtr.leftBoundaryPtr.id
}

func (tl *txLane) getRightBoundary() *txLaneBoundary {
    return tl.instancePtr.rightBoundaryPtr
}

func (tl *txLane) getRightBoundaryId() uint32 {
    if tl.instancePtr.rightBoundaryPtr == nil {
        return tl.instancePtr.data.right_boundary
    }
    return tl.instancePtr.rightBoundaryPtr.id
}

func (tl *txLane) getLaneType() uint32 {
    return tl.instancePtr.data.lane_type
}

func (tl *txLane) getLaneArrow() uint32 {
    return tl.instancePtr.data.lane_arrow
}

func (tl *txLane) getSpeedLimit() uint32 {
    return tl.instancePtr.data.speed_limit
}

func (tl *txLane) getLaneSurface() uint32 {
    return tl.instancePtr.data.lane_surface
}

func (tl *txLane) getLaneFriction() float64 {
    return tl.instancePtr.data.lane_friction
}

func (tl *txLane) getMaterialOffset() float64 {
    return tl.instancePtr.data.lane_material_soffset
}

func (tl *txLane) getRoadId() uint32 {
    return tl.instancePtr.data.road_pkid
}

func (tl *txLane) getSectionId() uint32 {
    return tl.instancePtr.data.section_id
}

func (tl *txLane) getTxLaneId() string {
    return fmt.Sprintf("lane_%d.%d.%d", tl.instancePtr.data.road_pkid, tl.instancePtr.data.section_id, tl.instancePtr.data.lane_id)
}

func (tl *txLane) getDistanceToEnd() float64 {
    return tl.instancePtr.distanceToEnd
}

func (tl *txLane) getLength() float64 {
    if tl.instancePtr.geom.empty() {
        return 0.0
    }
    return tl.instancePtr.geom.getLength()
}

func (tl *txLane) getLaneWidth() float64 {
    return tl.instancePtr.aveWidth
}

func (tl *txLane) getLaneWidthAt(s float64) float64 {
    pt := tl.instancePtr.geom.getPoint(s)
    return pt.w
}

func (tl *txLane) getName() string {
    return tl.instancePtr.data.name
}

func (tl *txLane) isEnable() bool {
    return tl.instancePtr.valid4Driving
}

func (tl *txLane) getSection() *txSection {
    return tl.instancePtr.sectionPtr
}

func (tl *txLane) setName(name string) *txLane {
    tl.instancePtr.data.name = name
    return tl
}

func (tl *txLane) setGeometry(curve ItxCurve) *txLane {
    tl.instancePtr.geom = curve.(*txLineCurve)
    return tl
}

func (tl *txLane) setGeometryFromPoints(points []txPoint, ct CoordType) *txLane {
    tl.instancePtr.geom = txLineCurve{coords: points}
    tl.instancePtr.geom.setCoordType(ct)
    return tl
}

func (tl *txLane) setDenseGeometry(curve ItxCurve) *txLane {
    tl.instancePtr.geomDense = *curve.(*txLineCurve)
    return tl
}

func (tl *txLane) setDenseGeometryFromPoints(points []txPoint, ct CoordType) *txLane {
    tl.instancePtr.geomDense = txLineCurve{coords: points}
    tl.instancePtr.geomDense.setCoordType(ct)
    return tl
}

func (tl *txLane) transfer(oldEnuC, newEnuC txPoint) *txLane {
    tl.instancePtr.geom.transfer(oldEnuC, newEnuC)
    return tl
}

func (tl *txLane) transfer2ENU(enuCenter txPoint) *txLane {
    tl.instancePtr.geom.transfer2ENU(enuCenter)
    return tl
}

func (tl *txLane) setLeftBoundary(boundary *txLaneBoundary) *txLane {
    tl.instancePtr.leftBoundaryPtr = boundary
    if boundary == nil {
        tl.instancePtr.data.left_boundary = 0
    } else {
        tl.instancePtr.data.left_boundary = boundary.id
    }
    return tl
}

func (tl *txLane) setLeftBoundaryId(boundaryId uint32) *txLane {
    tl.instancePtr.data.left_boundary = boundaryId
    if tl.instancePtr.leftBoundaryPtr != nil && tl.instancePtr.leftBoundaryPtr.id != boundaryId {
        tl.instancePtr.leftBoundaryPtr = nil
    }
    return tl
}

func (tl *txLane) setRightBoundary(boundary *txLaneBoundary) *txLane {
    tl.instancePtr.rightBoundaryPtr = boundary
    if boundary == nil {
        tl.instancePtr.data.right_boundary = 0
    } else {
        tl.instancePtr.data.right_boundary = boundary.id
    }
    return tl
}

func (tl *txLane) setRightBoundaryId(boundaryId uint32) *txLane {
    tl.instancePtr.data.right_boundary = boundaryId
    if tl.instancePtr.rightBoundaryPtr != nil && tl.instancePtr.rightBoundaryPtr.id != boundaryId {
        tl.instancePtr.rightBoundaryPtr = nil
    }
    return tl
}

func (tl *txLane) setLaneType(type_ uint32) *txLane {
    tl.instancePtr.data.lane_type = type_
    return tl
}

func (tl *txLane) setLaneArrow(arrow uint32) *txLane {
    tl.instancePtr.data.lane_arrow = arrow
    return tl
}

func (tl *txLane) setSpeedLimit(speed uint32) *txLane {
    tl.instancePtr.data.speed_limit = speed
    return tl
}

func (tl *txLane) setLaneSurface(surface uint32) *txLane {
    tl.instancePtr.data.lane_surface = surface
    return tl
}

func (tl *txLane) setLaneFriction(friction float64) *txLane {
    tl.instancePtr.data.lane_friction = friction
    return tl
}

func (tl *txLane) setMaterialOffset(soffset float64) *txLane {
    tl.instancePtr.data.lane_material_soffset = soffset
    return tl
}

func (tl *txLane) setRoadId(roadId uint32) *txLane {
    tl.instancePtr.data.road_pkid = roadId
    return tl
}

func (tl *txLane) setId(laneId uint32) *txLane {
    tl.instancePtr.data.lane_id = laneId
    return tl
}

func (tl *txLane) setSectionId(sectionId uint32) *txLane {
    tl.instancePtr.data.section_id = sectionId
    return tl
}

func (tl *txLane) setDistanceToEnd(disToEnd float64) *txLane {
    tl.instancePtr.distanceToEnd = disToEnd
    return tl
}

func (tl *txLane) setLaneWidth(width float64) *txLane {
    tl.instancePtr.aveWidth = width
    return tl
}

func (tl *txLane) setEnable(enable bool) *txLane {
    tl.instancePtr.valid4Driving = enable
    return tl
}

func (tl *txLane) setSection(sec *txSection) *txLane {
    tl.instancePtr.sectionPtr = sec
    return tl
}

func (tl *txLane) reverse() bool {
    tl.instancePtr.data.lane_id *= -1
    tl.instancePtr.geom.reverse()
    return true
}

func (tl *txLane) exchangeBoundaryIndex() bool {
    tl.instancePtr.data.left_boundary, tl.instancePtr.data.right_boundary = tl.instancePtr.data.right_boundary, tl.instancePtr.data.left_boundary
    tl.instancePtr.leftBoundaryPtr, tl.instancePtr.rightBoundaryPtr = tl.instancePtr.rightBoundaryPtr, tl.instancePtr.leftBoundaryPtr
    return true
}

func (tl *txLane) getUniqueId() string {
    return fmt.Sprintf("lane_%d.%d.%d", tl.instancePtr.data.road_pkid, tl.instancePtr.data.section_id, tl.instancePtr.data.lane_id)
}

func (tl *txLane) xy2sl(x, y float64) (s, l float64, ok bool) {
    return tl.instancePtr.xy2sl(x, y)
}

func (tl *txLane) sl2xy(s, l float64) (x, y float64, ok bool) {
    return tl.instancePtr.sl2xy(s, l)
}

func (tl *txLane) xy2slWithYaw(x, y float64) (s, l, yaw float64, ok bool) {
    s, l, ok = tl.instancePtr.xy2sl(x, y)
    if !ok {
        return 0.0, 0.0, 0.0, false
    }
    yaw = tl.instancePtr.getYaw(s)
    return s, l, yaw, true
}

func (tl *txLane) sl2xyWithYaw(s, l float64) (x, y, yaw float64, ok bool) {
    x, y, ok = tl.instancePtr.sl2xy(s, l)
    if !ok {
        return 0.0, 0.0, 0.0, false
    }
    yaw = tl.instancePtr.getYaw(s)
    return x, y, yaw, true
}

func (tl *txLane) getYaw(s float64) (yaw float64, err error) {
    if tl.instancePtr.geom.empty() {
        return 0.0, errors.New("getYaw error, no geometry data")
    }
    return tl.instancePtr.getYaw(s), nil
}

package hadmap

import (
    "strconv"
)

type HeaderData struct {
    Date         string
    Name         string
    East         float64
    North        float64
    South        float64
    West         float64
    RevMajor     string
    RevMinor     string
    Georeference string
    Vendor       string
}

type txOdHeader struct {
    instancePtr *HeaderData
}

func NewtxOdHeader() *txOdHeader {
    return &txOdHeader{instancePtr: &HeaderData{}}
}

func (t *txOdHeader) GetHeaderDate() string {
    return t.instancePtr.Date
}

func (t *txOdHeader) SetHeaderDate(date string) *txOdHeader {
    t.instancePtr.Date = date
    return t
}

func (t *txOdHeader) GetName() string {
    return t.instancePtr.Name
}

func (t *txOdHeader) SetName(name string) *txOdHeader {
    t.instancePtr.Name = name
    return t
}

func (t *txOdHeader) GetVendor() string {
    return t.instancePtr.Vendor
}

func (t *txOdHeader) SetVendor(vendor string) *txOdHeader {
    t.instancePtr.Vendor = vendor
    return t
}

func (t *txOdHeader) GetRevMajor() uint8 {
    major, _ := strconv.Atoi(t.instancePtr.RevMajor)
    return uint8(major)
}

func (t *txOdHeader) SetRevMajor(revMajor uint8) *txOdHeader {
    t.instancePtr.RevMajor = strconv.Itoa(int(revMajor))
    return t
}

func (t *txOdHeader) GetRevMinor() uint8 {
    minor, _ := strconv.Atoi(t.instancePtr.RevMinor)
    return uint8(minor)
}

func (t *txOdHeader) SetRevMinor(revMinor uint8) *txOdHeader {
    t.instancePtr.RevMinor = strconv.Itoa(int(revMinor))
    return t
}

func (t *txOdHeader) GetEast() float64 {
    return t.instancePtr.East
}

func (t *txOdHeader) SetEast(east float64) *txOdHeader {
    t.instancePtr.East = east
    return t
}

func (t *txOdHeader) GetNorth() float64 {
    return t.instancePtr.North
}

func (t *txOdHeader) SetNorth(north float64) *txOdHeader {
    t.instancePtr.North = north
    return t
}

func (t *txOdHeader) GetSouth() float64 {
    return t.instancePtr.South
}

func (t *txOdHeader) SetSouth(south float64) *txOdHeader {
    t.instancePtr.South = south
    return t
}

func (t *txOdHeader) GetWest() float64 {
    return t.instancePtr.West
}

func (t *txOdHeader) SetWest(west float64) *txOdHeader {
    t.instancePtr.West = west
    return t
}

func (t *txOdHeader) GetGeoreference() string {
    return t.instancePtr.Georeference
}

func (t *txOdHeader) SetGeoreference(reference string) *txOdHeader {
    t.instancePtr.Georeference = reference
    return t
}

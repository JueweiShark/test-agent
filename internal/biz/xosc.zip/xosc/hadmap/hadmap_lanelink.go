package hadmap

import (
    "fmt"
    "math"
    "sync"
)

type txLaneLink struct {
    instancePtr *LaneLinkData
}

type tx_lanelink_t struct {
    pkid            lanelinkpkid
    from_road_pkid  roadpkid
    from_section_id sectionpkid
    from_lane_id    lanepkid
    to_road_pkid    roadpkid
    to_section_id   sectionpkid
    to_lane_id      lanepkid
    odr_road_id     roadpkid
    controlPoint    txControlPoint
    eleControlPoint txControlPoint
    curvature       txCurvatureVec
    slope           txSlopeVec
    preContact      txContactType
    succContact     txContactType
    junction_id     junctionpkid
    geom            PointVec
}

type txLaneBoundaries struct {
    // TODO: Define the structure of txLaneBoundaries
}

type txControlPoint struct {
    // TODO: Define the structure of txControlPoint
}

type txContactType int

type txLaneId struct {
    roadPkid  roadpkid
    sectionId sectionpkid
    laneId    lanepkid
}

//type hadmap struct{}
//
//func (h *hadmap) calcCircumcircleRadius(A, B, C Point2d, flag bool) float64 {
//    // TODO: Implement the calculation of the circumcircle radius
//    return 0
//}
//
//func (h *hadmap) directlyDis(A, B Point2d) float64 {
//    // TODO: Implement the calculation of the direct distance between two points
//    return 0
//}
//
//func (h *hadmap) lonlat2enu(lon, lat, z, x, y, z2 float64) {
//    // TODO: Implement the conversion from longitude and latitude to east-north-up coordinates
//}
//
//func (h *hadmap) LineCurveToPoints3d(curve *txLineCurve, points *PointVec) {
//    // TODO: Implement the conversion from txLineCurve to PointVec
//}

type LaneLinkData struct {
    data      tx_lanelink_t
    geomPtr   *txLineCurve
    leftBds   txLaneBoundaries
    rightBds  txLaneBoundaries
    radius    float64
    radiusmtx sync.Mutex
}

func NewLaneLinkData() *LaneLinkData {
    return &LaneLinkData{
        geomPtr: nil,
    }
}

func NewTxLineCurve(coordType CoordType) *txLineCurve {
    return &txLineCurve{}
}

func (c *txLineCurve) SetCoordType(coordType CoordType) {
    // TODO: Set the coordinate type of the txLineCurve
}

func (c *txLineCurve) SetCoords(coords PointVec) {
    c.coords = coords
}

func (c *txLineCurve) GetStart() Point2d {
    // TODO: Get the start point of the txLineCurve
    return Point2d{}
}

func (c *txLineCurve) GetPoint(index int) Point2d {
    // TODO: Get the point at the specified index of the txLineCurve
    return Point2d{}
}

func (c *txLineCurve) GetEnd() Point2d {
    // TODO: Get the end point of the txLineCurve
    return Point2d{}
}

func (c *txLineCurve) Yaw(index int) float64 {
    // TODO: Get the yaw at the specified index of the txLineCurve
    return 0
}

func (c *txLineCurve) Size() int {
    return len(c.coords)
}

func NewTxLaneLink() *txLaneLink {
    return &txLaneLink{
        instancePtr: NewLaneLinkData(),
    }
}

func (l *txLaneLink) GetTxData() tx_lanelink_t {
    return l.instancePtr.data
}

func (l *txLaneLink) GetLinkType() LINK_TYPE {
    return LINK_TYPE_LANELINK
}

func (l *txLaneLink) GetId() lanelinkpkid {
    return l.instancePtr.data.pkid
}

func (l *txLaneLink) FromRoadId() roadpkid {
    return l.instancePtr.data.from_road_pkid
}

func (l *txLaneLink) FromSectionId() sectionpkid {
    return l.instancePtr.data.from_section_id
}

func (l *txLaneLink) FromLaneId() lanepkid {
    return l.instancePtr.data.from_lane_id
}

func (l *txLaneLink) FromTxLaneId() txLaneId {
    return txLaneId{
        roadPkid:  l.instancePtr.data.from_road_pkid,
        sectionId: l.instancePtr.data.from_section_id,
        laneId:    l.instancePtr.data.from_lane_id,
    }
}

func (l *txLaneLink) ToRoadId() roadpkid {
    return l.instancePtr.data.to_road_pkid
}

func (l *txLaneLink) ToSectionId() sectionpkid {
    return l.instancePtr.data.to_section_id
}

func (l *txLaneLink) ToLaneId() lanepkid {
    return l.instancePtr.data.to_lane_id
}

func (l *txLaneLink) ToTxLaneId() txLaneId {
    return txLaneId{
        roadPkid:  l.instancePtr.data.to_road_pkid,
        sectionId: l.instancePtr.data.to_section_id,
        laneId:    l.instancePtr.data.to_lane_id,
    }
}

func (l *txLaneLink) GetOdrRoadId() roadpkid {
    return l.instancePtr.data.odr_road_id
}

func (l *txLaneLink) GetUniqueId() string {
    index := fmt.Sprintf("link_%d.%d.%d_%d.%d.%d",
        l.instancePtr.data.from_road_pkid,
        l.instancePtr.data.from_section_id,
        l.instancePtr.data.from_lane_id,
        l.instancePtr.data.to_road_pkid,
        l.instancePtr.data.to_section_id,
        l.instancePtr.data.to_lane_id,
    )
    return index
}

func (l *txLaneLink) GetJunctionId() junctionpkid {
    return l.instancePtr.data.junction_id
}

func (l *txLaneLink) GetControlPoint() txControlPoint {
    return l.instancePtr.data.controlPoint
}

func (l *txLaneLink) GetEleControlPoint() txControlPoint {
    return l.instancePtr.data.eleControlPoint
}

func (l *txLaneLink) GetCurvature() txCurvatureVec {
    return l.instancePtr.data.curvature
}

func (l *txLaneLink) GetSlope() txSlopeVec {
    return l.instancePtr.data.slope
}

func (l *txLaneLink) GetMeanSlope() float64 {
    length := 0.0
    sumSlope := 0.0
    for _, slope := range l.instancePtr.data.slope {
        sumSlope += slope.slope * slope.length
        length += slope.length
    }
    if length == 0 || sumSlope/length < 1e-5 {
        return 0
    }
    return sumSlope / length
}

func (l *txLaneLink) GetPreContact() txContactType {
    return l.instancePtr.data.preContact
}

func (l *txLaneLink) GetSuccContact() txContactType {
    return l.instancePtr.data.succContact
}

func (l *txLaneLink) GetMeanCurvature() float64 {
    length := 0.0
    sumCurvature := 0.0
    for _, curvature := range l.instancePtr.data.curvature {
        sumCurvature += curvature.curvature * curvature.length
        length += curvature.length
    }
    if length == 0 || sumCurvature/length < 1e-6 {
        return 0
    }
    return sumCurvature / length
}

func (l *txLaneLink) GetLeftBoundaries() txLaneBoundaries {
    return l.instancePtr.leftBds
}

func (l *txLaneLink) GetRightBoundaries() txLaneBoundaries {
    return l.instancePtr.rightBds
}

func (l *txLaneLink) GetDeltaDirection() float64 {
    if l.instancePtr.geomPtr != nil && l.instancePtr.geomPtr.Size() > 2 {
        yaw0 := l.instancePtr.geomPtr.Yaw(0)
        yaw1 := l.instancePtr.geomPtr.Yaw(l.instancePtr.geomPtr.Size() - 1)
        yaw1 -= yaw0
        if yaw1 > 180 {
            yaw1 -= 360
        } else if yaw1 < -180 {
            yaw1 += 360
        }
        return yaw1
    }
    return 0.0
}

func (l *txLaneLink) GetRadius() float64 {
    if l.instancePtr.geomPtr == nil || l.instancePtr.geomPtr.Size() <= 2 {
        return math.Inf(1)
    }

    l.instancePtr.radiusmtx.Lock()
    defer l.instancePtr.radiusmtx.Unlock()
    if l.instancePtr.radius >= 0.0 {
        return l.instancePtr.radius
    }

    geom := l.instancePtr.geomPtr
    p1 := geom.GetStart()
    p2 := geom.GetPoint(1)
    p3 := geom.GetEnd()

    A := Point2d{p1.x, p1.y}
    B := Point2d{p2.x, p2.y}
    C := Point2d{p3.x, p3.y}
    if geom.GetCoordType() == COORD_WGS84 {
        var z float64
        h.lonlat2enu(B.x, B.y, z, A.x, A.y, z)
        h.lonlat2enu(C.x, C.y, z, A.x, A.y, z)
        A.x = 0.0
        A.y = 0.0
    }

    l.instancePtr.radius = h.calcCircumcircleRadius(A, B, C, false)
    return l.instancePtr.radius
}

func (l *txLaneLink) GetSpeedLimit() float64 {
    radius := l.GetRadius()
    if radius < 35 {
        return 35
    } else if radius < 68 {
        return 45
    } else if radius < 112 {
        return 57
    } else if radius < 192 {
        return 65
    } else if radius < 210 {
        return 67
    } else if radius < 239 {
        return 69
    } else if radius < 361 {
        return 83
    } else if radius < 464 {
        return 95
    } else if radius < 643 {
        return 120
    } else if radius < 1086 {
        return 130
    }
    return math.Inf(1)
}

func (l *txLaneLink) GetGeometry() *txLineCurve {
    return l.instancePtr.geomPtr
}

func (l *txLaneLink) Equal(link *txLaneLink) bool {
    if l.instancePtr.data.from_road_pkid == link.instancePtr.data.from_road_pkid &&
        l.instancePtr.data.from_section_id == link.instancePtr.data.from_section_id &&
        l.instancePtr.data.from_lane_id == link.instancePtr.data.from_lane_id &&
        l.instancePtr.data.to_road_pkid == link.instancePtr.data.to_road_pkid &&
        l.instancePtr.data.to_section_id == link.instancePtr.data.to_section_id &&
        l.instancePtr.data.to_lane_id == link.instancePtr.data.to_lane_id {
        return true
    }
    return false
}

func (l *txLaneLink) LinkIndex() string {
    index := fmt.Sprintf("%d.%d.%d_%d.%d.%d",
        l.instancePtr.data.from_road_pkid,
        l.instancePtr.data.from_section_id,
        l.instancePtr.data.from_lane_id,
        l.instancePtr.data.to_road_pkid,
        l.instancePtr.data.to_section_id,
        l.instancePtr.data.to_lane_id,
    )
    return index
}

func (l *txLaneLink) SetId(id lanelinkpkid) *txLaneLink {
    l.instancePtr.data.pkid = id
    return l
}

func (l *txLaneLink) SetFromRoadId(roadId roadpkid) *txLaneLink {
    l.instancePtr.data.from_road_pkid = roadId
    return l
}

func (l *txLaneLink) SetFromSectionId(sectionId sectionpkid) *txLaneLink {
    l.instancePtr.data.from_section_id = sectionId
    return l
}

func (l *txLaneLink) SetFromLaneId(laneId lanepkid) *txLaneLink {
    l.instancePtr.data.from_lane_id = laneId
    return l
}

func (l *txLaneLink) SetToRoadId(roadId roadpkid) *txLaneLink {
    l.instancePtr.data.to_road_pkid = roadId
    return l
}

func (l *txLaneLink) SetToSectionId(sectionId sectionpkid) *txLaneLink {
    l.instancePtr.data.to_section_id = sectionId
    return l
}

func (l *txLaneLink) SetToLaneId(laneId lanepkid) *txLaneLink {
    l.instancePtr.data.to_lane_id = laneId
    return l
}

func (l *txLaneLink) SetOdrRoadId(roadId roadpkid) *txLaneLink {
    l.instancePtr.data.odr_road_id = roadId
    return l
}

func (l *txLaneLink) SetControlPoint(control txControlPoint) *txLaneLink {
    l.instancePtr.data.controlPoint = control
    return l
}

func (l *txLaneLink) SetEleControlPoint(control txControlPoint) *txLaneLink {
    l.instancePtr.data.eleControlPoint = control
    return l
}

func (l *txLaneLink) SetGeometry(curve *txLineCurve) *txLaneLink {
    if l.instancePtr.geomPtr == nil {
        l.instancePtr.geomPtr = NewTxLineCurve(curve.GetCoordType())
    }
    l.instancePtr.geomPtr.SetCoords(curve.GetCoords())
    h.LineCurveToPoints3d(l.instancePtr.geomPtr, &l.instancePtr.data.geom)
    return l
}

func (l *txLaneLink) SetCurvature(curvature txCurvatureVec) *txLaneLink {
    l.instancePtr.data.curvature = curvature
    return l
}

func (l *txLaneLink) SetSlope(slope txSlopeVec) *txLaneLink {
    l.instancePtr.data.slope = slope
    return l
}

func (l *txLaneLink) SetPreContact(preContact txContactType) *txLaneLink {
    l.instancePtr.data.preContact = preContact
    return l
}

func (l *txLaneLink) SetSuccContact(succContact txContactType) *txLaneLink {
    l.instancePtr.data.succContact = succContact
    return l
}

func (l *txLaneLink) SetJunctionId(jid junctionpkid) *txLaneLink {
    l.instancePtr.data.junction_id = jid
    return l
}

func (l *txLaneLink) SetLeftBoundaries(bds txLaneBoundaries) *txLaneLink {
    l.instancePtr.leftBds = bds
    return l
}

func (l *txLaneLink) SetRightBoundaries(bds txLaneBoundaries) *txLaneLink {
    l.instancePtr.rightBds = bds
    return l
}

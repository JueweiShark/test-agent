package hadmap

type RouteType int

const (
    ROAD_ROUTE     RouteType = 1
    JUNCTION_ROUTE RouteType = 2
)

type RouteNodeData struct {
    Type        RouteType
    RouteID     int
    PreRouteID  int
    NextRouteID int
    StartRange  float64
    EndRange    float64
    NeedReverse bool
    Length      float64
    Attr        uint64
}
type txRouteNode struct {
    routeType   RouteType
    id          roadpkid
    preId       roadpkid
    nextId      roadpkid
    startRange  float64
    endRange    float64
    attr        uint64
    needReverse bool
    length      float64
    instancePtr *RouteNodeData
}

func (t *txRouteNode) Copy(route *txRouteNode) {
    t.instancePtr.Type = route.instancePtr.Type
    t.instancePtr.RouteID = route.instancePtr.RouteID
    t.instancePtr.PreRouteID = route.instancePtr.PreRouteID
    t.instancePtr.NextRouteID = route.instancePtr.NextRouteID
    t.instancePtr.StartRange = route.instancePtr.StartRange
    t.instancePtr.EndRange = route.instancePtr.EndRange
    t.instancePtr.NeedReverse = route.instancePtr.NeedReverse
    t.instancePtr.Length = route.instancePtr.Length
    t.instancePtr.Attr = route.instancePtr.Attr
}

func (t *txRouteNode) GetRouteType() RouteType {
    return t.instancePtr.Type
}

func (t *txRouteNode) GetID() int {
    return t.instancePtr.RouteID
}

func (t *txRouteNode) GetPreID() int {
    return t.instancePtr.PreRouteID
}

func (t *txRouteNode) GetNextID() int {
    return t.instancePtr.NextRouteID
}

func (t *txRouteNode) GetStartRange() float64 {
    return t.instancePtr.StartRange
}

func (t *txRouteNode) GetEndRange() float64 {
    return t.instancePtr.EndRange
}

func (t *txRouteNode) GetAttr() uint64 {
    return t.instancePtr.Attr
}

func (t *txRouteNode) NeedReverse() bool {
    return t.instancePtr.NeedReverse
}

func (t *txRouteNode) GetLength() float64 {
    return t.instancePtr.Length
}

func (t *txRouteNode) SetRouteType(type_ RouteType) *txRouteNode {
    t.instancePtr.Type = type_
    return t
}

func (t *txRouteNode) SetID(id int) *txRouteNode {
    t.instancePtr.RouteID = id
    return t
}

func (t *txRouteNode) SetPreID(id int) *txRouteNode {
    t.instancePtr.PreRouteID = id
    return t
}

func (t *txRouteNode) SetNextID(id int) *txRouteNode {
    t.instancePtr.NextRouteID = id
    return t
}

func (t *txRouteNode) SetStartRange(r float64) *txRouteNode {
    t.instancePtr.StartRange = r
    return t
}

func (t *txRouteNode) SetEndRange(r float64) *txRouteNode {
    t.instancePtr.EndRange = r
    return t
}

func (t *txRouteNode) SetAttr(attr uint64) *txRouteNode {
    t.instancePtr.Attr = attr
    return t
}

func (t *txRouteNode) SetReverse(needReverse bool) *txRouteNode {
    t.instancePtr.NeedReverse = needReverse
    return t
}

func (t *txRouteNode) SetLength(l float64) *txRouteNode {
    t.instancePtr.Length = l
    return t
}

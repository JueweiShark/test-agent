package hadmap

import (
    "sort"
    "sync"
)

type SectionData struct {
    ID                 sectionpkid
    Lanes              txLanes
    DistanceToJunction float64
    MeanSlope          float64
    MeanCurvature      float64
    StartPercent       float64
    EndPercent         float64
    RoadPtr            *txRoad
}

type txSection struct {
    mu          sync.Mutex
    data        *SectionData
    id          uint32
    instancePtr *SectionData
}

func (s *SectionData) GetID() sectionpkid {
    return s.ID
}

func (s *SectionData) GetRoadID() roadpkid {
    if len(s.Lanes) > 0 {
        return s.Lanes[0].GetRoadID()
    }
    if s.RoadPtr != nil {
        return s.RoadPtr.GetID()
    }
    return SECT_PKID_INVALID
}

func (s *SectionData) GetLength() float64 {
    var len float64
    count := 0
    for _, lane := range s.Lanes {
        dis := lane.GetLength()
        if dis > 1e-5 {
            len += dis
            count++
        }
    }
    if count > 0 {
        return len / float64(count)
    }
    return 0.0
}

func (s *SectionData) GetLanes() txLanes {
    return s.Lanes
}

func (s *SectionData) GetBoundaries() txLaneBoundaries {
    var ids map[laneboundarypkid]struct{}
    boundaries := make(txLaneBoundaries, 0)
    for _, lane := range s.Lanes {
        if _, exists := ids[lane.GetLeftBoundaryID()]; !exists {
            ids[lane.GetLeftBoundaryID()] = struct{}{}
            boundaries = append(boundaries, lane.GetLeftBoundary())
        }
        if _, exists := ids[lane.GetRightBoundaryID()]; !exists {
            ids[lane.GetRightBoundaryID()] = struct{}{}
            boundaries = append(boundaries, lane.GetRightBoundary())
        }
    }
    return boundaries
}

func (s *SectionData) GetDistanceToJunction() float64 {
    return s.DistanceToJunction
}

func (s *SectionData) GetLane(laneID lanepkid) *txLane {
    for _, lane := range s.Lanes {
        if lane.GetID() == laneID {
            return lane
        }
    }
    return nil
}

func (s *SectionData) GetLaneByName(name string) *txLane {
    for _, lane := range s.Lanes {
        if lane.GetName() == name {
            return lane
        }
    }
    return nil
}

func (s *SectionData) SetRoadID(id roadpkid) {
    for _, lane := range s.Lanes {
        lane.SetRoadID(id)
    }
}

func (s *SectionData) SetID(id sectionpkid) {
    s.ID = id
    for _, lane := range s.Lanes {
        lane.SetSectionID(id)
    }
}

func (s *SectionData) SetDistanceToJunction(d float64) {
    s.DistanceToJunction = d
}

func (t *txSection) GetID() sectionpkid {
    return t.instancePtr.GetID()
}

func (t *txSection) GetRoadID() roadpkid {
    return t.instancePtr.GetRoadID()
}

func (t *txSection) GetLength() float64 {
    return t.instancePtr.GetLength()
}

func (t *txSection) GetMeanSlope() float64 {
    return t.instancePtr.MeanSlope
}

func (t *txSection) GetMeanCurvature() float64 {
    return t.instancePtr.MeanCurvature
}

func (t *txSection) GetLane(laneID int8) *txLane {
    for _, lane := range t.instancePtr.GetLanes() {
        if lane.GetID() == laneID {
            return lane
        }
    }
    return nil
}

func (t *txSection) GetLanes() txLanes {
    return t.instancePtr.GetLanes()
}

func (t *txSection) GetRightLanes() []txLaneId {
    var rightLanes []txLaneId
    for _, lane := range t.instancePtr.GetLanes() {
        if lane.GetID() < 0 {
            rightLanes = append(rightLanes, lane.GetTxLaneId())
        }
    }
    sort.Slice(rightLanes, func(i, j int) bool {
        return abs(rightLanes[i].LaneID) < abs(rightLanes[j].LaneID)
    })
    return rightLanes
}

func (t *txSection) GetLeftLanes() []txLaneId {
    var leftLanes []txLaneId
    for _, lane := range t.instancePtr.GetLanes() {
        if lane.GetID() > 0 {
            leftLanes = append(leftLanes, lane.GetTxLaneId())
        }
    }
    sort.Slice(leftLanes, func(i, j int) bool {
        return abs(leftLanes[i].LaneID) < abs(leftLanes[j].LaneID)
    })
    return leftLanes
}

func (t *txSection) GetStartPercentOfRoad() float64 {
    return t.instancePtr.StartPercent
}

func (t *txSection) GetEndPercentOfRoad() float64 {
    return t.instancePtr.EndPercent
}

func (t *txSection) GetBoundaries() txLaneBoundaries {
    return t.instancePtr.GetBoundaries()
}

func (t *txSection) GetBoundariesByRange(start, end float64) txLaneBoundaries {
    if start > 0.0 && end > 0.0 && start > end {
        return nil
    }

    boundaries := t.instancePtr.GetBoundaries()
    var cutBoundaries txLaneBoundaries
    for _, bound := range boundaries {
        curBound := &txLaneBoundary{}
        curBound.SetID(bound.GetID()).SetLaneMark(bound.GetLaneMark())

        curve, ok := bound.GetGeometry().(*txLineCurve)
        if !ok {
            return nil
        }
        points, err := curve.Cut(start, end)
        if err != nil || len(points) <= 1 {
            return nil
        }
        curBound.SetGeometry(points, curve.GetCoordType())
        cutBoundaries = append(cutBoundaries, curBound)
    }
    return cutBoundaries
}

func (t *txSection) GetDistanceToJunction() float64 {
    return t.instancePtr.GetDistanceToJunction()
}

func (t *txSection) GetLaneByID(laneID lanepkid) *txLane {
    return t.instancePtr.GetLane(laneID)
}

func (t *txSection) GetLaneByName(name string) *txLane {
    return t.instancePtr.GetLaneByName(name)
}

func (t *txSection) GetRoad() *txRoad {
    return t.instancePtr.RoadPtr
}

func (t *txSection) SetRoadID(id roadpkid) *txSection {
    t.instancePtr.SetRoadID(id)
    return t
}

func (t *txSection) SetID(id sectionpkid) *txSection {
    t.instancePtr.SetID(id)
    return t
}

func (t *txSection) SetLanes(lanes txLanes) *txSection {
    t.instancePtr.Lanes = lanes
    for _, lane := range t.instancePtr.Lanes {
        lane.SetSection(t)
        lane.SetSectionID(t.instancePtr.ID)
    }
    return t
}

func (t *txSection) Add(lanePtr *txLane) *txSection {
    for _, lane := range t.instancePtr.Lanes {
        if lane.GetID() == lanePtr.GetID() && lane.GetName() == lanePtr.GetName() {
            return t
        }
    }
    lanePtr.SetSectionID(t.instancePtr.ID)
    lanePtr.SetSection(t)
    t.instancePtr.Lanes = append(t.instancePtr.Lanes, lanePtr)
    return t
}

func (t *txSection) RemoveLane(laneID lanepkid) *txSection {
    for i, lane := range t.instancePtr.Lanes {
        if lane.GetID() == laneID {
            t.instancePtr.Lanes = append(t.instancePtr.Lanes[:i], t.instancePtr.Lanes[i+1:]...)
            break
        }
    }
    return t
}

func (t *txSection) SetDistanceToJunction(d float64) *txSection {
    t.instancePtr.SetDistanceToJunction(d)
    return t
}

func (t *txSection) SetMeanSlope(d float64) *txSection {
    t.instancePtr.MeanSlope = d
    return t
}

func (t *txSection) SetMeanCurvature(d float64) *txSection {
    t.instancePtr.MeanCurvature = d
    return t
}

func (t *txSection) SetRoad(roadPtr *txRoad) *txSection {
    t.instancePtr.RoadPtr = roadPtr
    return t
}

func (t *txSection) Reverse() bool {
    if len(t.instancePtr.Lanes) == 0 {
        return false
    }
    for i, j := 0, len(t.instancePtr.Lanes)-1; i <= j; i, j = i+1, j-1 {
        if i == j {
            t.instancePtr.Lanes[i].Reverse()
            break
        } else {
            t.instancePtr.Lanes[i].Reverse()
            t.instancePtr.Lanes[j].Reverse()
            t.instancePtr.Lanes[i], t.instancePtr.Lanes[j] = t.instancePtr.Lanes[j], t.instancePtr.Lanes[i]
        }
    }
    var boundaryIds map[uint64_t]struct{}
    for _, lane := range t.instancePtr.Lanes {
        if _, exists := boundaryIds[lane.GetLeftBoundaryID()]; !exists {
            boundaryIds[lane.GetLeftBoundaryID()] = struct{}{}
            lane.GetLeftBoundary().Reverse()
        }
        if _, exists := boundaryIds[lane.GetRightBoundaryID()]; !exists {
            boundaryIds[lane.GetRightBoundaryID()] = struct{}{}
            lane.GetRightBoundary().Reverse()
        }
    }
    return true
}

func (t *txSection) ExchangeBoundaryIndex(curLane, oppositeLane bool) bool {
    if len(t.instancePtr.Lanes) == 0 {
        return false
    }
    if curLane {
        for _, lane := range t.instancePtr.Lanes {
            if lane.GetID() < 0 {
                lane.ExchangeBoundaryIndex()
            }
        }
    }
    if oppositeLane {
        for _, lane := range t.instancePtr.Lanes {
            if lane.GetID() > 0 {
                lane.ExchangeBoundaryIndex()
            }
        }
    }
    return true
}

func (t *txSection) BindSectionPtr() *txSection {
    for _, lane := range t.instancePtr.Lanes {
        lane.SetSection(t)
    }
    return t
}

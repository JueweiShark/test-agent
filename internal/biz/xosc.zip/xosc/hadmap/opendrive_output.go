package hadmap

import (
    "encoding/xml"
    "fmt"
    "math"
    "sort"
    "time"
)

const M_PI = 3.1415926

type PlanView struct {
    Geometry   []Geometry `xml:"geometry"`
    Type       string     `xml:"type,attr"`
    Hdg        float64    `xml:"hdg,attr"`
    Length     float64    `xml:"length,attr"`
    S          float64    `xml:"s,attr"`
    X          float64    `xml:"x,attr"`
    Y          float64    `xml:"y,attr"`
    Arc        float64    `xml:"arc,attr"`
    StartIndex int        `xml:"startIndex,attr"`
    EndIndex   int        `xml:"endIndex,attr"`
    AU         float64    `xml:"aU,attr"`
    BU         float64    `xml:"bU,attr"`
    CU         float64    `xml:"cU,attr"`
    DU         float64    `xml:"dU,attr"`
    AV         float64    `xml:"aV,attr"`
    BV         float64    `xml:"bV,attr"`
    CV         float64    `xml:"cV,attr"`
    DV         float64    `xml:"dV,attr"`
}

type Ele struct {
    S float64 `xml:"s,attr"`
    A float64 `xml:"a,attr"`
    B float64 `xml:"b,attr"`
    C float64 `xml:"c,attr"`
    D float64 `xml:"d,attr"`
}

type LaneMark struct {
    Type       string `xml:"type,attr"`
    Color      string `xml:"color,attr"`
    LaneChange string `xml:"laneChange,attr"`
}

type OpenDriveOutput struct {
    Doc      *xml.Encoder
    RefPoint txPoint
    FilePath string
    IsInit   bool
}

func HadMapLaneType(type_ LANE_TYPE) string {
    switch type_ {
    case LANE_TYPE_None:
        return "none"
    case LANE_TYPE_Driving:
        return "driving"
    case LANE_TYPE_Stop:
        return "stop"
    case LANE_TYPE_Shoulder:
        return "shoulder"
    case LANE_TYPE_Biking:
        return "biking"
    case LANE_TYPE_Sidewalk:
        return "sidewalk"
    case LANE_TYPE_Border:
        return "border"
    case LANE_TYPE_Restricted:
        return "restricted"
    case LANE_TYPE_Parking:
        return "parking"
    case LANE_TYPE_BIDIRECTIONAL:
        return "bidirectional"
    case LANE_TYPE_CONNECTINGRAMP:
        return "connectingRamp"
    case LANE_TYPE_CURB:
        return "curb"
    case LANE_TYPE_ENTRY:
        return "entry"
    case LANE_TYPE_EXIT:
        return "exit"
    case LANE_TYPE_MEDIAN:
        return "median"
    case LANE_TYPE_OFFRAMP:
        return "offRamp"
    case LANE_TYPE_ONRAMP:
        return "onRamp"
    case LANE_TYPE_RAIL:
        return "rail"
    case LANE_TYPE_ROADWORKS:
        return "roadworks"
    case LANE_TYPE_TRAM:
        return "tram"
    case LANE_TYPE_MwyEntry:
        return "MwyEntry"
    case LANE_TYPE_MwyExit:
        return "MwyExit"
    case LANE_TYPE_Emergency:
        return "Emergency"
    case LANE_TYPE_TurnWaiting:
        return "TurnWaiting"
    default:
        return "none"
    }
}

func HadMapLaneMark(mark LANE_MARK) string {
    switch mark {
    case LANE_MARK_None:
        return "none"
    case LANE_MARK_Solid:
        return "solid"
    case LANE_MARK_Broken:
        return "broken"
    case LANE_MARK_Solid2:
        return "solid2"
    case LANE_MARK_Broken2:
        return "broken2"
    case LANE_MARK_SolidSolid:
        return "solid solid"
    case LANE_MARK_SolidBroken:
        return "solid broken"
    case LANE_MARK_BrokenSolid:
        return "broken solid"
    case LANE_MARK_BrokenBroken:
        return "broken broken"
    case LANE_MARK_Curb:
        return "curb"
    case LANE_MARK_Fence:
        return "fence"
    case LANE_MARK_Bold:
        return "bold"
    case LANE_MARK_Yellow:
        return "yellow"
    case LANE_MARK_Red:
        return "red"
    case LANE_MARK_Yellow2:
        return "yellow"
    case LANE_MARK_YellowYellow:
        return "yellow"
    case LANE_MARK_Blue:
        return "blue"
    case LANE_MARK_Green:
        return "green"
    }
    return "none"
}

func HadMapLaneColor(mark LANE_MARK) string {
    switch mark {
    case LANE_MARK_Yellow:
        return "yellow"
    case LANE_MARK_Red:
        return "red"
    case LANE_MARK_Yellow2:
        return "yellow yellow"
    case LANE_MARK_Blue:
        return "blue"
    case LANE_MARK_Green:
        return "green"
    default:
        return "white"
    }
}

func HadMapObjectColor(tColor int) string {
    switch tColor {
    case OBJECT_COLOR_Yellow:
        return "yellow"
    case OBJECT_COLOR_Red:
        return "red"
    case int(LANE_MARK_Yellow2):
        return "yellow yellow"
    case OBJECT_COLOR_Blue:
        return "blue"
    case OBJECT_COLOR_Green:
        return "green"
    case OBJECT_COLOR_Black:
        return "black"
    default:
        return "white"
    }
}
func LineEquation(pt1, pt2 txPoint, A, B, C *float64) bool {
    *A = 1.0
    *B = 1.0
    *C = 1.0
    var pt txPoint
    F := pt1.x*pt2.y - pt1.y*pt2.x
    pt.x = pt2.x - pt1.x
    pt.y = pt2.y - pt1.y
    if math.Abs(F) < 1e-6 {
        if math.Abs(pt.x) < 1e-6 && math.Abs(pt.y) < 1e-6 {
            return false
        } else if math.Abs(pt.x) < 1e-6 {
            *A = 1.0
            *B = 0.0
            *C = 0.0 - pt1.x
        } else if math.Abs(pt.y) < 1e-6 {
            *A = 0.0
            *B = 1.0
            *C = 0.0 - pt1.y
        } else {
            *A = 1.0
            *B = 0.0 - pt1.x/pt1.y
            *C = 0.0
        }
    } else {
        *A = 0.0 - pt.y/F
        *B = pt.x / F
        *C = 1.0
    }
    return true
}

func LineEquationWithPoint(pt txPoint, A, B float64, C *float64) bool {
    *C = 0.0 - A*pt.x - B*pt.y
    return true
}

func LineLineCross(A1, B1, C1, A2, B2, C2 float64, ptCross *txPoint) bool {
    F := A1*B2 - A2*B1
    if math.Abs(F) < 1e-8 {
        return false
    }

    ptCross.x = (B1*C2 - B2*C1) / F
    ptCross.y = 0.0 - (A1*C2-A2*C1)/F
    return true
}

func Pt3CircleWithAngle(pt1, pt2, pt3 txPoint, R *float64, ptCen *txPoint, radLength, startAngleG, endAngleG *float64) bool {
    var A, B, C [4]float64
    var pt [3]txPoint

    LineEquation(pt1, pt2, &A[0], &B[0], &C[0])
    LineEquation(pt2, pt3, &A[1], &B[1], &C[1])

    if math.Abs(B[0]) < 1e-6 {
        if math.Abs(B[1]) < 1e-6 {
            return false
        }
    } else {
        if math.Abs(B[1]) > 1e-6 {
            if math.Abs(A[0]/B[0]-A[1]/B[1]) < 1e-6 {
                return false
            }
        }
    }

    pt[0] = pt1
    pt[0].x *= 0.5
    pt[0].y *= 0.5
    pt[2] = pt2
    pt[2].x *= 0.5
    pt[2].y *= 0.5
    pt[0].x += pt[2].x
    pt[0].y += pt[2].y

    pt[1] = pt2
    pt[1].x *= 0.5
    pt[1].y *= 0.5
    pt[2] = pt3
    pt[2].x *= 0.5
    pt[2].y *= 0.5
    pt[1].x += pt[2].x
    pt[1].y += pt[2].y

    A[2] = 0.0 - B[0]
    B[2] = A[0]
    LineEquation(pt[0], &A[2], &B[2], &C[2])

    A[3] = 0.0 - B[1]
    B[3] = A[1]
    LineEquation(pt[1], &A[3], &B[3], &C[3])

    LineLineCross(A[2], B[2], C[2], A[3], B[3], C[3], ptCen)

    pt[2] = pt1
    pt[2].x -= ptCen.x
    pt[2].y -= ptCen.y
    pt[2].z = 0.0
    *R = math.Sqrt(pt[2].x*pt[2].x + pt[2].y*pt[2].y + pt[2].z*pt[2].z)

    pt[0] = pt2
    pt[0].x -= pt1.x
    pt[0].y -= pt1.y
    pt[1] = pt3
    pt[1].x -= pt2.x
    pt[1].y -= pt2.y

    A[0] = math.Atan2(pt[0].y, pt[0].x)
    A[1] = math.Atan2(pt[1].y, pt[1].x)
    A[2] = A[1] - A[0]

    if A[2] < -math.Pi {
        A[2] += 2 * math.Pi
    } else if A[2] > math.Pi {
        A[2] -= 2 * math.Pi
    }

    *radLength = 2 * math.Abs(A[2])

    *startAngleG = math.Atan2(pt1.y-ptCen.y, pt1.x-ptCen.x)
    if *startAngleG < 0 && *startAngleG >= -math.Pi {
        *startAngleG += 2 * math.Pi
    }
    *endAngleG = *startAngleG + 2*A[2]

    return true
}
func (o *OpenDriveOutput) initFilePath(filePath string, replace bool) bool {
    o.filePath = filePath
    if replace {
        var err error
        o.doc, err = libxml2.NewDocument()
        if err != nil {
            return false
        }
        declare := o.doc.NewDeclaration()
        opendriveEle := o.doc.NewElement("OpenDRIVE")
        o.doc.InsertFirstChild(declare)
        o.doc.InsertEndChild(opendriveEle)
    } else {
        var err error
        o.doc, err = libxml2.LoadFile(filePath)
        if err != nil {
            return false
        }
    }
    o.isInit = true
    return true
}

func (o *OpenDriveOutput) insertHeader(refPoint TXPoint) bool {
    header := o.doc.NewElement("header")
    header.SetAttribute("revMajor", "1")
    header.SetAttribute("revMinor", "4")
    header.SetAttribute("name", "")
    header.SetAttribute("version", "1.0")
    now := time.Now()
    date := fmt.Sprintf("%d-%02d-%02d", now.Year(), now.Month(), now.Day())
    header.SetAttribute("date", date)
    header.SetAttribute("north", fmt.Sprintf("%f", refPoint.Y))
    header.SetAttribute("south", fmt.Sprintf("%f", refPoint.Y))
    header.SetAttribute("west", fmt.Sprintf("%f", refPoint.X))
    header.SetAttribute("east", fmt.Sprintf("%f", refPoint.X))
    header.SetAttribute("vendor", "")
    opendrive := o.doc.FirstChildElement("OpenDRIVE")
    opendrive.InsertFirstChild(header)
    return true
}

func (o *OpenDriveOutput) insertRoads(roads []TXRoad) bool {
    for _, road := range roads {
        roadEle := o.insertOneRoad(road)
        lastRoadEle := o.doc.RootElement().LastChildElement("road")
        if lastRoadEle != nil {
            opendrive := o.doc.FirstChildElement("OpenDRIVE")
            opendrive.InsertAfterChild(lastRoadEle, roadEle)
        } else {
            opendrive := o.doc.FirstChildElement("OpenDRIVE")
            opendrive.InsertEndChild(roadEle)
        }
    }
    return true
}

type TXObject struct {
    XMLName     xml.Name  `xml:"object"`
    Type        string    `xml:"type,attr"`
    ID          int64     `xml:"id,attr"`
    S           float64   `xml:"s,attr"`
    T           float64   `xml:"t,attr"`
    Name        string    `xml:"name,attr"`
    ZOffset     float64   `xml:"zOffset,attr"`
    Orientation string    `xml:"orientation,attr"`
    Length      float64   `xml:"length,attr"`
    Width       float64   `xml:"width,attr"`
    Height      float64   `xml:"height,attr"`
    Hdg         float64   `xml:"hdg,attr"`
    Pitch       float64   `xml:"pitch,attr"`
    Roll        float64   `xml:"roll,attr"`
    Repeat      *Repeat   `xml:"repeat,omitempty"`
    Outlines    *Outlines `xml:"outlines,omitempty"`
}

type Repeat struct {
    XMLName    xml.Name          `xml:"repeat"`
    Attributes map[string]string `xml:",any,attr"`
}

type Outlines struct {
    XMLName xml.Name  `xml:"outlines"`
    Outline []Outline `xml:"outline"`
}

type Outline struct {
    XMLName    xml.Name     `xml:"outline"`
    ID         int          `xml:"id,attr"`
    CornerRoad []CornerRoad `xml:"cornerRoad"`
}

type CornerRoad struct {
    XMLName xml.Name `xml:"cornerRoad"`
    S       float64  `xml:"s,attr"`
    T       float64  `xml:"t,attr"`
    Dz      float64  `xml:"dz,attr"`
    Height  float64  `xml:"height,attr"`
    ID      int      `xml:"id,attr"`
}

func insertObjects(objects []TXObject, roads []Road) bool {
    roadID2MapObjects := make(map[int64][]TXObject)
    for _, obj := range objects {
        roadID := obj.S
        if roadID > 0 {
            if _, ok := roadID2MapObjects[roadID]; !ok {
                roadID2MapObjects[roadID] = []TXObject{obj}
            } else {
                roadID2MapObjects[roadID] = append(roadID2MapObjects[roadID], obj)
            }
        } else {
            linkRoadID := obj.T + LINK_ROAD_ID
            if _, ok := roadID2MapObjects[linkRoadID]; !ok {
                roadID2MapObjects[linkRoadID] = []TXObject{obj}
            } else {
                roadID2MapObjects[linkRoadID] = append(roadID2MapObjects[linkRoadID], obj)
            }
        }
    }
    for roadID, objects := range roadID2MapObjects {
        for i, road := range roads {
            if road.ID == roadID {
                // Process objects and add them to the road
                for _, obj := range objects {
                    // Example: Add object to road
                    roads[i].Objects = append(roads[i].Objects, obj)
                }
                break
            }
        }
    }
    return true
}

type Road struct {
    XMLName          xml.Name         `xml:"road"`
    Name             string           `xml:"name,attr"`
    ID               int64            `xml:"id,attr"`
    Junction         int              `xml:"junction,attr"`
    Link             Link             `xml:"link"`
    Type             Type             `xml:"type"`
    PlanView         PlanView         `xml:"planView"`
    ElevationProfile ElevationProfile `xml:"elevationProfile"`
    Lanes            Lanes            `xml:"lanes"`
}

type Type struct {
    Type string `xml:"type,attr"`
    S    string `xml:"s,attr"`
}

type Geometry struct {
    X          string     `xml:"x,attr"`
    Y          string     `xml:"y,attr"`
    Length     string     `xml:"length,attr"`
    Hdg        string     `xml:"hdg,attr"`
    S          string     `xml:"s,attr"`
    Line       struct{}   `xml:"line"`
    ParamPoly3 ParamPoly3 `xml:"paramPoly3"`
    Arc        Arc        `xml:"arc"`
}

type ParamPoly3 struct {
    AU     string `xml:"aU,attr"`
    AV     string `xml:"aV,attr"`
    BU     string `xml:"bU,attr"`
    BV     string `xml:"bV,attr"`
    CU     string `xml:"cU,attr"`
    CV     string `xml:"cV,attr"`
    DU     string `xml:"dU,attr"`
    DV     string `xml:"dV,attr"`
    PRange string `xml:"pRange,attr"`
}

type Arc struct {
    Curvature string `xml:"curvature,attr"`
}

type ElevationProfile struct {
    Elevation []Elevation `xml:"elevation"`
}

type Elevation struct {
    A string `xml:"a,attr"`
    B string `xml:"b,attr"`
    C string `xml:"c,attr"`
    D string `xml:"d,attr"`
    S string `xml:"s,attr"`
}

type Lanes struct {
    LaneSection []LaneSection `xml:"laneSection"`
}

type LaneSection struct {
    S      string `xml:"s,attr"`
    Left   Left   `xml:"left"`
    Center Center `xml:"center"`
    Right  Right  `xml:"right"`
}

type Left struct {
    Lane []Lane `xml:"lane"`
}

type Center struct {
    Lane Lane `xml:"lane"`
}

type Right struct {
    Lane []Lane `xml:"lane"`
}

const LINK_ROAD_ID = 10000

type txLaneLink struct {
    FromLaneId  int64
    ToLaneId    int64
    SuccContact string

    FromRoadId int64 `xml:"fromRoadId"`
    ToRoadId   int64 `xml:"toRoadId"`
    OdrRoadId  int64 `xml:"odrRoadId"`
    JunctionId int64 `xml:"junctionId"`
}

type Link struct {
    XMLName     xml.Name     `xml:"link"`
    Predecessor *Predecessor `xml:"predecessor"`
    Successor   *Successor   `xml:"successor"`
}

type Successor struct {
    XMLName      xml.Name `xml:"successor"`
    ElementType  string   `xml:"elementType,attr"`
    ElementId    int64    `xml:"elementId,attr"`
    ContactPoint string   `xml:"contactPoint,attr"`
    ID          string     `xml:"ID,attr"`
}

type Junction struct {
    XMLName     xml.Name     `xml:"junction"`
    ID          int64        `xml:"id,attr"`
    Connections []Connection `xml:"connection"`
}

type Connection struct {
    XMLName        xml.Name   `xml:"connection"`
    ConnectingRoad int64      `xml:"connectingRoad,attr"`
    ContactPoint   string     `xml:"contactPoint,attr"`
    IncomingRoad   int64      `xml:"incomingRoad,attr"`
    LaneLinks      []LaneLink `xml:"laneLink"`
}

type LaneLink struct {
    XMLName     xml.Name    `xml:"laneLink"`
    From        int64       `xml:"from,attr"`
    To          int64       `xml:"to,attr"`
    Predecessor Predecessor `xml:"<link>predecessor,omitempty"`
    Successor   Successor   `xml:"<link>successor,omitempty"`
}

type Predecessor struct {
    ID string
    ContactPoint string `xml:"contactPoint,attr"`
    ElementID    int64  `xml:"elementId,attr"`
    ElementType  string `xml:"elementType,attr"`
}

type Line struct{}

type Lane struct {
    ID       int        `xml:"id,attr"`
    Level    bool       `xml:"level,attr"`
    Type        string      `xml:"type,attr"`
    RoadMark    []RoadMark  `xml:"roadMark"`
    Width       []Width     `xml:"width"`
    Predecessor Predecessor `xml:"<link>predecessor,omitempty"`
    Successor   Successor   `xml:"<link>successor,omitempty"`
    Link        []LaneLink  `xml:"link"`
    Speed       []Speed     `xml:"speed"`
    Material    []Material  `xml:"material"`
}

type RoadMark struct {
    SOffset    float64 `xml:"sOffset,attr"`
    Weight     string  `xml:"weight,attr"`
    Width      string  `xml:"width,attr"`
    Height     string  `xml:"height,attr"`
    Material   string  `xml:"material,attr"`
    LaneChange string  `xml:"laneChange,attr"`
    Type       string  `xml:"type,attr"`
    Color      string  `xml:"color,attr"`
}

type Width struct {
    A       float64 `xml:"a,attr"`
    B       float64 `xml:"b,attr"`
    C       float64 `xml:"c,attr"`
    D       float64 `xml:"d,attr"`
    SOffset float64 `xml:"sOffset,attr"`
}

func (o *OpenDriveOutput) insertLaneLinks(lanelinks []txLaneLink) bool {
    id2lanelinks := make(map[int64][]txLaneLink)
    fromRoad2LaneLink := make(map[int64]*txLaneLink)
    toRoad2LaneLink := make(map[int64]*txLaneLink)

    for _, itLink := range lanelinks {
        fromRoad2LaneLink[itLink.FromRoadId] = &itLink
        toRoad2LaneLink[itLink.ToRoadId] = &itLink
        if _, ok := id2lanelinks[itLink.JunctionId]; ok {
            id2lanelinks[itLink.JunctionId] = append(id2lanelinks[itLink.JunctionId], itLink)
        } else {
            id2lanelinks[itLink.JunctionId] = []txLaneLink{itLink}
        }
        o.insertOneLaneLink(itLink)
    }

    for itJuc := range id2lanelinks {
        junction := o.findOrCreateJunction(itJuc)
        for _, itLink := range id2lanelinks[itJuc] {
            connection := Connection{
                ConnectingRoad: itLink.OdrRoadId,
                ContactPoint:   itLink.SuccContact,
                IncomingRoad:   itLink.FromRoadId,
                LaneLinks:      []LaneLink{{From: itLink.FromLaneId, To: itLink.ToLaneId}},
            }
            junction.Connections = append(junction.Connections, connection)
        }
    }

    for _, road := range o.Roads {
        if itLink, ok := fromRoad2LaneLink[road.ID]; ok {
            o.updateRoadLink(&road, "predecessor", itLink.JunctionId)
        }
        if itLink, ok := toRoad2LaneLink[road.ID]; ok {
            o.updateRoadLink(&road, "successor", itLink.JunctionId)
        }
    }
    return true
}

func (o *OpenDriveOutput) insertOneLaneLink(itLink txLaneLink) {
    // Implementation for inserting a single lane link
}

func (o *OpenDriveOutput) findOrCreateJunction(id int64) *Junction {
    for i, junction := range o.Junctions {
        if junction.ID == id {
            return &o.Junctions[i]
        }
    }
    newJunction := Junction{ID: id}
    o.Junctions = append(o.Junctions, newJunction)
    return &o.Junctions[len(o.Junctions)-1]
}

func (o *OpenDriveOutput) updateRoadLink(road *Road, linkType string, junctionId int64) {
    if road.Link == nil {
        road.Link = &Link{}
    }
    if linkType == "predecessor" {
        if road.Link.Predecessor == nil {
            road.Link.Predecessor = &Predecessor{}
        }
        road.Link.Predecessor.ElementType = "junction"
        road.Link.Predecessor.ElementId = junctionId
    } else if linkType == "successor" {
        if road.Link.Successor == nil {
            road.Link.Successor = &Successor{}
        }
        road.Link.Successor.ElementType = "junction"
        road.Link.Successor.ElementId = junctionId
    }
}

func (o *OpenDriveOutput) updateRoads(roads []Road) bool {
    roadpkidMap := make(map[int64]*Road)
    for _, road := range roads {
        roadpkidMap[road.Id] = &road
    }
    roadEle := o.Doc.Root().FirstChild("road").(*xml.Element)
    for roadEle != nil {
        roadid := roadEle.Int64Attr("id")
        if _, ok := roadpkidMap[roadid]; ok {
            insertRoad := o.insertOneRoad(roadpkidMap[roadid])
            if objectsEle := roadEle.FirstChild("objects").(*xml.Element); objectsEle != nil {
                insertRoad.InsertEndChild(objectsEle)
            }
            if signalsEle := roadEle.FirstChild("signals").(*xml.Element); signalsEle != nil {
                insertRoad.InsertEndChild(signalsEle)
            }
            o.Doc.Root().InsertAfterChild(roadEle, insertRoad)
            o.Doc.Root().DeleteChild(roadEle)
            roadEle = insertRoad
        }
        roadEle = roadEle.NextSibling("road").(*xml.Element)
    }
    return true
}

func (o *OpenDriveOutput) updateLaneLinks(lanelinks []LaneLink) bool {
    o.deleteLanelinks(lanelinks)
    o.insertLaneLinks(lanelinks)
    return true
}

func (o *OpenDriveOutput) updateObjects(objects []Object, roads []Road) bool {
    o.deleteObjects(objects)
    o.insertObjects(objects, roads)
    return true
}

func (o *OpenDriveOutput) deleteRoads(roads []Road) bool {
    roadpkidMap := make(map[int64]*Road)
    for _, road := range roads {
        roadpkidMap[road.Id] = &road
    }
    roadEle := o.Doc.Root().FirstChild("road").(*xml.Element)
    for roadEle != nil {
        roadid := roadEle.Int64Attr("id")
        if _, ok := roadpkidMap[roadid]; ok {
            o.Doc.Root().DeleteChild(roadEle)
        }
        roadEle = roadEle.NextSibling("road").(*xml.Element)
    }
    return true
}


func (o *OpenDriveOutput) deleteLanelinks(lanelinks TXLaneLinks) bool {
    fromRoad2LaneLink := make(map[int64]*txLaneLink)
    toRoad2LaneLink := make(map[int64]*txLaneLink)
    roadpkidMap := make(map[int64]*txLaneLink)
    id2lanelinks := make(map[int64]TXLaneLinks)

    for _, link := range lanelinks {
        fromRoad2LaneLink[link.FromRoadId] = &link
        toRoad2LaneLink[link.ToRoadId] = &link
        roadpkidMap[link.OdrRoadId] = &link
        if links, exists := id2lanelinks[link.JunctionId]; exists {
            id2lanelinks[link.JunctionId] = append(links, link)
        } else {
            id2lanelinks[link.JunctionId] = TXLaneLinks{link}
        }
    }

    roadEle := o.Doc.Root().FirstChild("road")
    for roadEle != nil {
        roadid := roadEle.Int64Attr("id")
        if _, exists := roadpkidMap[roadid]; exists {
            o.Doc.Root().DeleteChild(roadEle)
        }
        roadEle = roadEle.NextSibling("road")
    }

    junction := o.Doc.Root().FirstChild("junction")
    for junction != nil {
        junctionid := junction.Int64Attr("id")
        if _, exists := id2lanelinks[junctionid]; exists {
            connection := junction.FirstChild("connection")
            for connection != nil {
                if _, exists := roadpkidMap[connection.Int64Attr("connectingRoad")]; exists {
                    junction.DeleteChild(connection)
                }
                connection = connection.NextSibling("connection")
            }
            if junction.FirstChild() == nil {
                o.Doc.Root().DeleteChild(junction)
            }
        }
        junction = junction.NextSibling("junction")
    }

    roadelement := o.Doc.Root().FirstChild("road")
    for roadelement != nil {
        roadid := roadelement.Int64Attr("id")
        if _, exists := fromRoad2LaneLink[roadid]; exists {
            link := roadelement.FirstChild("link")
            if link == nil {
                link = o.Doc.NewElement("link")
                roadelement.InsertFirstChild(link)
            }
            if link.FirstChild("predecessor") != nil {
                link.DeleteChild(link.FirstChild("predecessor"))
            }
        }
        if _, exists := toRoad2LaneLink[roadid]; exists {
            link := roadelement.FirstChild("link")
            if link == nil {
                link = o.Doc.NewElement("link")
                roadelement.InsertFirstChild(link)
            }
            if link.FirstChild("successor") != nil {
                link.DeleteChild(link.FirstChild("successor"))
            }
        }
        roadelement = roadelement.NextSibling("road")
    }
    return true
}

func (o *OpenDriveOutput) deleteObjects(objects TXObjects) bool {
    roadid2mapObjects := make(map[int64]TXObjects)
    objectIdVec := make(map[int64]bool)

    for _, obj := range objects {
        if obj.RoadId > 0 {
            if _, exists := roadid2mapObjects[obj.RoadId]; !exists {
                roadid2mapObjects[obj.RoadId] = TXObjects{obj}
            } else {
                roadid2mapObjects[obj.RoadId] = append(roadid2mapObjects[obj.RoadId], obj)
            }
        } else {
            objectIdVec[obj.Id] = true
        }
    }

    for roadid, objects := range roadid2mapObjects {
        roadEle := o.Doc.Root().FirstChild("road")
        for roadEle != nil {
            if roadEle.Int64Attr("id") == roadid {
                objectsEle := roadEle.FirstChild("objects")
                if objectsEle == nil {
                    objectsEle = o.Doc.NewElement("objects")
                    roadEle.InsertEndChild(objectsEle)
                }
                signalsEle := roadEle.FirstChild("signals")
                if signalsEle == nil {
                    signalsEle = o.Doc.NewElement("signals")
                    roadEle.InsertEndChild(signalsEle)
                }

                for _, obj := range objects {
                    objectEle := objectsEle.FirstChild("object")
                    for objectEle != nil {
                        if obj.Id == objectEle.Int64Attr("id") {
                            objectsEle.DeleteChild(objectEle)
                            break
                        }
                        objectEle = objectEle.NextSibling("object")
                    }
                    tunnelEle := objectsEle.FirstChild("tunnel")
                    for tunnelEle != nil {
                        if obj.Id == tunnelEle.Int64Attr("id") {
                            objectsEle.DeleteChild(tunnelEle)
                            break
                        }
                        tunnelEle = tunnelEle.NextSibling("tunnel")
                    }

                    signalEle := signalsEle.FirstChild("signal")
                    for signalEle != nil {
                        if obj.Id == signalEle.Int64Attr("id") {
                            signalsEle.DeleteChild(signalEle)
                            break
                        }
                        signalEle = signalEle.NextSibling("signal")
                    }
                }
                break
            }
            roadEle = roadEle.NextSibling("road")
        }
    }

    roadEle = o.Doc.Root().FirstChild("road")
    for roadEle != nil {
        if objectsEle := roadEle.FirstChild("objects"); objectsEle != nil && objectsEle.FirstChild("object") != nil {
            objectid := objectsEle.FirstChild("object").Int64Attr("id")
            if _, exists := objectIdVec[objectid]; exists {
                objectsEle.DeleteChild(objectsEle.FirstChild("object"))
            }
        }
        roadEle = roadEle.NextSibling("road")
    }
    return true
}

func (o *OpenDriveOutput) SpecLaneLinks(roadid int64, lanelinks []LaneLink) bool {
    if len(lanelinks) < 1 {
        return true
    }

    // if road contains several lanelinks
    roadEle := o.Doc.Root().FirstChild("road")
    for roadEle != nil {
        curRoadid := roadEle.Int64Attr("id")
        if curRoadid == roadid {
            o.Doc.Root().RemoveChild(roadEle)
            break
        }
        roadEle = roadEle.NextSibling("road")
    }

    index := 0
    for _, itLaneLink := range lanelinks {
        itLaneLink.SetOdrRoadId(itLaneLink.GetOdrRoadId()*10000 + int64(index))
        ele := o.InsertOneLaneLink(itLaneLink)
        o.Doc.FirstChild("OpenDRIVE").InsertAfterChild(o.Doc.Root().LastChild("road"), ele)
        index++
    }
    return true
}

func (o *OpenDriveOutput) SaveFile(filePath string) int {
    if o.Doc != nil {
        return o.Doc.SaveFile(filePath)
    }
    return -1
}

func (o *OpenDriveOutput) InsertOneRoad(it *RoadPtr) *xml.Element {
    road := o.Doc.NewElement("road")
    road.SetAttr("name", it.GetName())
    road.SetAttr("id", it.GetId())
    road.SetAttr("junction", -1)

    // link
    link := o.Doc.NewElement("link")
    predecessor := o.Doc.NewElement("predecessor")
    pre := it.GetRoadPreLink()
    if pre.Id != "" {
        predecessor.SetAttr("elementType", pre.Type)
        predecessor.SetAttr("elementId", pre.Id)
        link.InsertEndChild(predecessor)
    }
    successor := o.Doc.NewElement("successor")
    to := it.GetRoadToLink()
    if to.Id != "" {
        successor.SetAttr("elementType", to.Type)
        successor.SetAttr("elementId", to.Id)
        link.InsertEndChild(successor)
    }
    road.InsertEndChild(link)

    // type
    roadType := o.Doc.NewElement("type")
    roadType.SetAttr("type", "motorway")
    roadType.SetAttr("s", "0")
    road.InsertEndChild(roadType)

    // planview
    curve := it.GetGeometry()
    points := CurveToPoints(curve)
    var planViewVec []PlanView
    point := it.GetControlPoint()
    getPlanViewLink(point, points, &planViewVec)
    planView := o.Doc.NewElement("planView")
    var length float64
    for _, it := range planViewVec {
        geometry := o.Doc.NewElement("geometry")
        geometry.SetAttr("x", fmt.Sprintf("%f", it.X))
        geometry.SetAttr("y", fmt.Sprintf("%f", it.Y))
        geometry.SetAttr("length", fmt.Sprintf("%f", it.Length))
        geometry.SetAttr("hdg", fmt.Sprintf("%f", it.Hdg))
        geometry.SetAttr("s", fmt.Sprintf("%f", it.S))
        if it.Type == "line" {
            line := o.Doc.NewElement("line")
            geometry.InsertEndChild(line)
        } else if it.Type == "paramPoly3" {
            paramPoly3 := o.Doc.NewElement("paramPoly3")
            paramPoly3.SetAttr("aU", it.AU)
            paramPoly3.SetAttr("aV", it.AV)
            paramPoly3.SetAttr("bU", it.BU)
            paramPoly3.SetAttr("bV", it.BV)
            paramPoly3.SetAttr("cU", it.CU)
            paramPoly3.SetAttr("cV", it.CV)
            paramPoly3.SetAttr("dU", it.DU)
            paramPoly3.SetAttr("dV", it.DV)
            paramPoly3.SetAttr("pRange", "normalized")
            geometry.InsertEndChild(paramPoly3)
        } else {
            if it.AbsArc() < 1e-5 {
                line := o.Doc.NewElement("line")
                geometry.InsertEndChild(line)
            } else {
                arc := o.Doc.NewElement("arc")
                arc.SetAttr("curvature", fmt.Sprintf("%f", it.Arc))
                geometry.InsertEndChild(arc)
            }
        }
        length = it.S + it.Length
        planView.InsertEndChild(geometry)
    }
    road.SetAttr("length", fmt.Sprintf("%f", length))
    road.InsertEndChild(planView)

    // elevationProfile
    elevationProfile := o.Doc.NewElement("elevationProfile")
    var elevec []ele
    if it.GetElePoint().m_type != "none" && len(it.GetElePoint().m_points) > 1 {
        getEleFromControl(it.GetElePoint().m_points, &elevec)
    } else {
        getEle(points, &elevec)
    }
    for _, itEle := range elevec {
        elevation := o.Doc.NewElement("elevation")
        elevation.SetAttr("a", itEle.a)
        elevation.SetAttr("b", itEle.b)
        elevation.SetAttr("c", itEle.c)
        elevation.SetAttr("d", itEle.d)
        elevation.SetAttr("s", itEle.s)
        elevationProfile.InsertEndChild(elevation)
    }
    road.InsertEndChild(elevationProfile)

    // lanes
    lanes := o.Doc.NewElement("lanes")
    var sectionLength float64
    for _, itSection := range it.GetSections() {
        laneSection := o.Doc.NewElement("laneSection")
        laneSection.SetAttr("s", fmt.Sprintf("%f", sectionLength))
        // left
        leftLanes := itSection.GetLeftLanes()
        if len(leftLanes) > 0 {
            left := o.Doc.NewElement("left")
            for _, _itlaneid := range leftLanes {
                laneEle := o.InsertOneLane(itSection.GetLane(_itlaneid.laneId))
                left.InsertEndChild(laneEle)
            }
            laneSection.InsertEndChild(left)
        }
        // center
        center := o.Doc.NewElement("center")
        lane := o.Doc.NewElement("lane")
        lane.SetAttr("id", "0")
        lane.SetAttr("level", "false")
        lane.SetAttr("type", "none")
        var centerLine *txLaneBoundaryPtr
        if len(itSection.GetRightLanes()) > 0 {
            centerLine = itSection.GetLane(-1).GetLeftBoundary()
        } else if len(itSection.GetLeftLanes()) > 0 {
            centerLine = itSection.GetLane(1).GetRightBoundary()
        }
        roadMark := o.Doc.NewElement("roadMark")
        roadMark.SetAttr("sOffset", "0")
        roadMark.SetAttr("weight", "standard")
        roadMark.SetAttr("height", "0")
        roadMark.SetAttr("material", "standard")
        roadMark.SetAttr("width", "0.15")
        roadMark.SetAttr("laneChange", "none")
        strType := HadMapLaneMark(LANE_MARK(centerLine.GetLaneMark() & 0xFF))
        roadMark.SetAttr("type", strType)
        n := centerLine.GetLaneMark() & 0x0F0000
        strColor := HadMapLaneColor(n)
        roadMark.SetAttr("color", strColor)
        lane.InsertEndChild(roadMark)
        center.InsertEndChild(lane)
        laneSection.InsertEndChild(center)
        // right
        rightLanes := itSection.GetRightLanes()
        if len(rightLanes) > 0 {
            right := o.Doc.NewElement("right")
            for _, _itlaneid := range rightLanes {
                laneEle := o.InsertOneLane(itSection.GetLane(_itlaneid.laneId))
                right.InsertEndChild(laneEle)
            }
            laneSection.InsertEndChild(right)
        }
        lanes.InsertEndChild(laneSection)
        sectionLength += itSection.GetLength()
    }
    road.InsertEndChild(lanes)

    // surface
    if len(it.GetCrgVec()) > 0 {
        surface := o.InsertCrgs(it.GetCrgVec(), it.GetLength())
        road.InsertEndChild(surface)
    }

    return road
}
func insertOneLaneLink(itLink txLaneLinkPtr) *Road {
    road := &Road{
        Name:     "",
        ID:       itLink.getOdrRoadId(),
        Junction: itLink.getJunctionId(),
    }

    var link Link
    {}

    startType := "start"
    if itLink.getPreContact() != START {
        startType = "end"
    }
    link.Predecessor = &Predecessor{
        ContactPoint: startType,
        ElementID:    itLink.fromRoadId(),
        ElementType:  "road",
    }

    startTypeSuc := "start"
    if itLink.getSuccContact() != START {
        startTypeSuc = "end"
    }
    link.Successor = &Successor{
        ContactPoint: startTypeSuc,
        ElementId:    itLink.toRoadId(),
        ElementType:  "road",
    }

    road.PlanView = getPlanView(itLink)

    elevec := getEle(itLink.getGeometry())
    road.ElevationProfile = elevec

    laneSection := LaneSection{
        S: 0,
    }

    centerLane := Lane{
        ID:    0,
        Level: false,
        Type:  "none",
    }

    centerLane.RoadMark = []RoadMark{
        {
            SOffset: 0,
            Weight:  "standard",
            Width:   "1.0",
            Height:  "0",
        },
    }

    laneSection.Center = []Lane{centerLane}

    rightLane := Lane{
        ID:    -1,
        Level: false,
        Type:  "driving",
    }

    laneLink := LaneLink{
        Predecessor: Predecessor{
            ID: itLink.fromTxLaneId().laneId,
        },
        Successor: Successor{
            ID: itLink.toTxLaneId().laneId,
        },
    }

    rightLane.Link = []LaneLink{laneLink}

    rightLane.RoadMark = []RoadMark{
        {
            SOffset:    0,
            Weight:     "standard",
            Height:     0,
            Material:   "standard",
            Width:      "0.2",
            LaneChange: "none",
        },
    }

    rightLane.Width = []Width{
        {
            A:       0.1,
            B:       0,
            C:       0,
            D:       0,
            SOffset: 0,
        },
    }

    laneSection.Right = Right{[]Lane{rightLane}}

    road.Lanes.LaneSection = []LaneSection{laneSection}

    return road
}

type Speed struct {
    SOffset float64 `xml:"sOffset,attr"`
    Max     float64 `xml:"max,attr"`
}

type Material struct {
    Surface   string  `xml:"surface,attr"`
    Friction  float64 `xml:"friction,attr"`
    SOffset   float64 `xml:"sOffset,attr"`
}

func (o *OpenDriveOutput) insertCrgs(crgs []txOpenCrg, roadlength float64) *XMLElement {
    surface := doc.NewElement("surface")
    for _, crg := range crgs {
        crgElement := doc.NewElement("CRG")
        crgElement.SetAttribute("sStart", "0")
        crgElement.SetAttribute("sEnd", fmt.Sprintf("%f", roadlength))
        crgElement.SetAttribute("file", crg.m_file)
        crgElement.SetAttribute("orientation", crg.m_orientation)
        crgElement.SetAttribute("mode", crg.m_mode)
        crgElement.SetAttribute("purpose", crg.m_purpose)
        crgElement.SetAttribute("sOffset", crg.m_soffset)
        crgElement.SetAttribute("tOffset", crg.m_toffset)
        crgElement.SetAttribute("zOffset", crg.m_zoffset)
        crgElement.SetAttribute("hOffset", crg.m_hoffset)
        crgElement.SetAttribute("zScale", crg.m_zscale)
        surface.InsertEndChild(crgElement)
    }
    return surface
}

func insertOneLane(lanePtr *Lane) *Lane {
    lane := &Lane{
        ID:    lanePtr.ID,
        Level: lanePtr.Level,
        Type:  lanePtr.Type,
    }

    var boundary *Boundary
    if lanePtr.ID > "0" {
        boundary = lanePtr.LeftBoundary
    } else {
        boundary = lanePtr.RightBoundary
    }

    roadMark := &RoadMark{
        SOffset:    0,
        Weight:     "standard",
        Height:     "0",
        Material:   "standard",
        Width:      "0.2",
        LaneChange: "none",
        Type:       HadMapLaneMark(boundary.LaneMark & 0xFF),
        Color:      HadMapLaneMark(boundary.LaneMark & 0xFFFF00),
    }
    lane.RoadMark = append(lane.RoadMark, *roadMark)

    width := &Width{
        A:       GetLaneWidth(lanePtr),
        B:       0.0,
        C:       0.0,
        D:       0.0,
        SOffset: 0.0,
    }
    lane.Width = append(lane.Width, *width)

    speed := &Speed{
        SOffset: 0,
        Max:     lanePtr.SpeedLimit / 3.6,
    }
    lane.Speed = append(lane.Speed, *speed)

    material := &Material{
        Surface:   "",
        Friction:  lanePtr.LaneFriction,
        SOffset:   lanePtr.MaterialOffset,
    }
    lane.Material = append(lane.Material, *material)

    return lane
}

func GetLaneWidth(lane *Lane) float64 {
    laneWidth := 0.0
    if lane.LeftBoundary != nil && lane.RightBoundary != nil {
        leftCurve := lane.LeftBoundary.Geometry.(*LineCurve)
        leftPoints := leftCurve.GetPoints()
        rightCurve := lane.RightBoundary.Geometry.(*LineCurve)
        rightPoints := rightCurve.GetPoints()
        if len(leftPoints) != len(rightPoints) {
            fmt.Println("left point size is not equal right point")
            left := leftPoints[0]
            lonlat2xy(&left.X, &left.Y)
            right := rightPoints[0]
            lonlat2xy(&right.X, &right.Y)
            return distanceTwoPoint(left, right)
        }
        for i := 0; i < len(leftPoints); i++ {
            left := leftPoints[i]
            lonlat2xy(&left.X, &left.Y)
            right := rightPoints[i]
            lonlat2xy(&right.X, &right.Y)
            laneWidth += distanceTwoPoint(left, right)
        }
        laneWidth /= float64(len(leftPoints))
        fmt.Println("lanewidth =", laneWidth)
        return laneWidth
    }
    return 3.5
}
func CurveToPoints(curve *txCurve, points *[]txPoint) {
    fLen := curve.getLength()
    var fInterval float64 = 10
    if fLen < 50 {
        fInterval = fLen / 10
    } else if fLen >= 50 && fLen < 100 {
        fInterval = fLen / 20
    } else if fLen >= 100 && fLen < 300 {
        fInterval = fLen / 30
    }
    if fLen < 0.1 {
        fInterval = 1
    }
    pts := curve.sample(fInterval)
    for _, pt := range pts {
        x, y, z := pt.x, pt.y, pt.z
        lonlat2xy(x, y)
        tmp := txPoint{x: x, y: y, z: z}
        *points = append(*points, tmp)
    }
}

func distanceTwoPoint(a, b txPoint) float64 {
    return math.Sqrt((b.y-a.y)*(b.y-a.y) + (b.x-a.x)*(b.x-a.x))
}


func (o *OpenDriveOutput) FitCenterByLeastSquares(mapPoint []txPoint, radius *float64, radiusVec *[]float64) {
    if len(mapPoint) < 3 {
        *radius = 0.0
        return
    }
    var radiusVecSum float64

    for i := 0; i < len(mapPoint)-2; i++ {
        type point struct {
            x, y float64
        }
        P1 := point{mapPoint[i].x, mapPoint[i].y}
        P2 := point{mapPoint[i+1].x, mapPoint[i+1].y}
        P3 := point{mapPoint[i+2].x, mapPoint[i+2].y}
        if P1.x == P2.x && P2.x == P3.x {
            *radius = 0
        } else {
            var dis1, dis2, dis3, cosA, sinA, dis float64
            dis1 = math.Sqrt((P1.x-P2.x)*(P1.x-P2.x) + (P1.y-P2.y)*(P1.y-P2.y))
            dis2 = math.Sqrt((P1.x-P3.x)*(P1.x-P3.x) + (P1.y-P3.y)*(P1.y-P3.y))
            dis3 = math.Sqrt((P2.x-P3.x)*(P2.x-P3.x) + (P2.y-P3.y)*(P2.y-P3.y))
            dis = dis1*dis1 + dis3*dis3 - dis2*dis2

            if dis1 == 0 || dis2 == 0 || dis3 == 0 || dis == 0 {
                *radius = 0
            } else {
                cosA = dis / (2 * dis1 * dis3)
                if math.Abs(1-cosA*cosA) < 1e-6 || math.Abs(dis2) < 1e-6 {
                    *radius = 0
                } else {
                    sinA = math.Sqrt(1 - cosA*cosA)
                    *radius = 0.5 * dis2 / sinA
                    *radius = 1 / *radius
                }
                z := (P1.x-P2.x)*(P3.y-P2.y) - (P1.y-P2.y)*(P3.x-P2.x)
                if z > 0 {
                    *radius = *radius * (-1)
                }
            }
        }
        *radiusVec = append(*radiusVec, *radius)
        radiusVecSum += *radius
    }
    *radius = radiusVecSum / float64(len(mapPoint)-2)
}

func (o *OpenDriveOutput) getEle(vec []txPoint, elevec *[]ele) float64 {
    var points []txPoint
    var s float64
    points = append(points, txPoint{0, vec[0].z, 0})
    for i := 1; i < len(vec); i++ {
        s += distanceTwoPoint(vec[i], vec[i-1])
        points = append(points, txPoint{s, vec[i].z, 0})
    }
    var fRadius float64
    var radiusVec []float64
    o.FitCenterByLeastSquares(points, &fRadius, &radiusVec)
    var index_start, index_end int
    var start2end []struct{ int, int }
    for i := 0; i < len(radiusVec); i++ {
        if index_end == len(radiusVec)-1 {
            start2end = append(start2end, struct{ int, int }{index_start, index_end})
        }
        if math.Abs(radiusVec[i]) < 0.01 {
            index_end++
        } else {
            start2end = append(start2end, struct{ int, int }{index_start, index_end})
            index_start = index_end
            index_end++
        }
    }
    for _, se := range start2end {
        startIndex, endIndex := se[0], se[0]
        if startIndex+2 >= len(points) || startIndex < 0 {
            continue
        }
        fmt.Println("startIndex =", startIndex)
        fmt.Println("points =", len(points))
        starts := points[startIndex].x
        starth := points[startIndex].y
        ends := points[startIndex+2].x
        endh := points[startIndex+2].y
        tmp := ele{
            s: starts,
            a: starth,
            b: (endh - starth) / (ends - starts),
            c: 0.0,
            d: 0.0,
        }
        *elevec = append(*elevec, tmp)
    }
    return true
}

func (o *OpenDriveOutput) getPlanViewLink(points []txPoint, planViewVec *[]PlanView) bool {
    var allLength float64
    *planViewVec = nil
    var fRadius float64
    var radiusVec []float64
    o.FitCenterByLeastSquares(points, &fRadius, &radiusVec)
    sample_distance := 3.0
    for i := 0; i < len(points)-1; i++ {
        allLength += distanceTwoPoint(points[i+1], points[i])
    }
    if allLength < 10 || math.Abs(fRadius) > 0.1 {
        sample_distance = 1.0
    }
    var index int
    var length float64
    for i := 0; i < len(points); i++ {
        distance := distanceTwoPoint(points[index], points[i])
        if i == len(points)-1 {
            it := PlanView{
                x:     points[index].x,
                y:     points[index].y,
                s:     length,
                length: distance,
                arc:   0,
                hdg:   math.Atan2((points[i].y-points[index].y), (points[i].x-points[index].x)),
            }
            *planViewVec = append(*planViewVec, it)
            index = i
            length += distance
        }
        if distance > sample_distance {
            if i < len(radiusVec)-1 && math.Abs(radiusVec[i-1]) > 1e-5 {
                it := PlanView{
                    x:     points[index].x,
                    y:     points[index].y,
                    hdg:   math.Atan2((points[i].y-points[index].y), (points[i].x-points[index].x)),
                    length: distance,
                    arc:   0.0,
                    s:     length,
                }
                *planViewVec = append(*planViewVec, it)
                index = i
                length += distance
            }
        }
    }
    return true
}

func (o *OpenDriveOutput) getPlanViewLink(controlPoint txControlPoint, points []txPoint, planViewVec []PlanView) bool {
    if controlPoint.m_type == "none" {
        return o.getPlanViewLink(points, planViewVec)
    }
    if controlPoint.m_type == "line" {
        tmp := PlanView{}
        tmp.typeField = "line"
        tmp.s = 0
        tmp.x = controlPoint.m_points[0].x
        tmp.y = controlPoint.m_points[0].y
        tmp.hdg = controlPoint.m_points[0].hdg
        tmp.length = distanceTwoPoint(controlPoint.m_points[0], controlPoint.m_points[len(controlPoint.m_points)-1])
        planViewVec = append(planViewVec, tmp)
    } else if controlPoint.m_type == "arc" {
        tmp := PlanView{}
        tmp.typeField = "arc"
        tmp.s = 0
        tmp.x = controlPoint.m_points[0].x
        tmp.y = controlPoint.m_points[0].y
        tmp.hdg = controlPoint.m_points[0].hdg
        var arc, length float64
        nextPoint := controlPoint.m_points[0] - controlPoint.m_points[len(controlPoint.m_points)-1]
        nextHdg := math.Atan2(nextPoint.y, nextPoint.x)
        getArcAndLength(controlPoint.m_points[0].hdg, controlPoint.m_points[len(controlPoint.m_points)-1].hdg, nextHdg, distanceTwoPoint(controlPoint.m_points[0], controlPoint.m_points[len(controlPoint.m_points)-1]), &arc, &length)
        tmp.arc = arc
        tmp.length = length
        planViewVec = append(planViewVec, tmp)
    } else if controlPoint.m_type == "catmullrom" {
        if len(controlPoint.m_points) < 4 {
            return o.getPlanViewLink(points, planViewVec)
        }
        var s float64
        for i := 0; i < len(controlPoint.m_points)-3; i++ {
            var pointVec []txPoint
            for j := i; j < i+4; j++ {
                pointVec = append(pointVec, controlPoint.m_points[j])
            }
            tmp := PlanView{}
            controlPointsToParamPloy(pointVec, &tmp)
            tmp.s = s
            s += tmp.length
            planViewVec = append(planViewVec, tmp)
        }
        return true
    } else {
        return o.getPlanViewLink(points, planViewVec)
    }
    return true
}

func (o *OpenDriveOutput) getPlanView(points []txPoint, planViewVec []PlanView) bool {
    var fRadius float64
    var radiusVec []float64
    FitCenterByLeastSquares(points, fRadius, radiusVec)
    sort.Float64s(radiusVec)
    var radius float64
    for i := 0; i < len(radiusVec); i++ {
        for j := i + 1; j < len(radiusVec); j++ {
            if math.Abs(radiusVec[j]-radiusVec[i]) < 0.01 {
                if j == len(radiusVec)-1 {
                    tmp := PlanView{}
                    tmp.startIndex = i
                    tmp.endIndex = j
                    i = j
                    planViewVec = append(planViewVec, tmp)
                    break
                }
                continue
            }
            tmp := PlanView{}
            tmp.startIndex = i
            tmp.endIndex = j
            i = j
            planViewVec = append(planViewVec, tmp)
            break
        }
    }

    var flength float64
    var index int
    for _, it := range planViewVec {
        var _length float64
        startIndex := it.startIndex
        nextIndex := it.startIndex + 1
        endIndex := it.endIndex + 1
        if index == len(planViewVec)-1 {
            endIndex++
        }
        index++
        deg := math.Atan2(points[endIndex].y-points[it.startIndex].y, points[it.endIndex].x-points[it.startIndex].x)
        _length = distanceTwoPoint(points[endIndex], points[startIndex])

        it.x = points[startIndex].x
        it.y = points[startIndex].y
        it.s = flength
        it.arc = 0
        it.hdg = deg
        it.length = _length
        flength += _length
    }
    return true
}

func (o *OpenDriveOutput) getEleFromControl(vec []txPoint, elevec []ele) int {
    if len(vec) < 2 {
        return -1
    }
    elevec = elevec[:0]
    var tmp []txPoint
    p1 := vec[0]
    p2 := vec[1]
    p0 := txPoint{x: p1.x*2 - p2.x, y: p1.y*2 - p2.y}
    tmp = append(tmp, p0)
    p3 := vec[len(vec)-2]
    p4 := vec[len(vec)-1]
    p5 := txPoint{x: p4.x*2 - p3.x, y: p4.y*2 - p3.y}
    tmp = append(tmp, vec...)
    tmp = append(tmp, p5)
    for i := 0; i < len(tmp)-3; i++ {
        var controlVec []txPoint
        controlVec = append(controlVec, tmp[i], tmp[i+1], tmp[i+2], tmp[i+3])
        var _ele ele
        controlPointsToPloy3(controlVec, &_ele)
        elevec = append(elevec, _ele)
    }
    return 0
}

func (o *OpenDriveOutput) getArcAndLength(hdg1, hdg2, nextHdg, length float64, arc *float64, arcLength *float64) {
    a_b := math.Sin(hdg1)*math.Cos(nextHdg) - math.Cos(hdg1)*math.Sin(nextHdg)
    if a_b > 0 {
        a := hdg2 - hdg1
        if a < 0 {
            a += 2 * math.Pi
        }
        half_a := 0.5 * a
        R := length * 0.5 / math.Sin(half_a)
        *arc = 1 / R
        *arcLength = math.Abs(a * R)
    } else {
        a := hdg2 - hdg1
        if a < 0 {
            a += 2 * math.Pi
        }
        a = 2*math.Pi - a
        half_a := 0.5 * a
        R := length * 0.5 / math.Sin(half_a)
        *arc = -1 / R
        *arcLength = math.Abs(a * R)
    }
}

func (o *OpenDriveOutput) lonlat2xy(x, y *float64) {
    rootelemet := o.doc.FirstChildElement("OpenDRIVE")
    if rootelemet.FirstChildElement("header") != nil {
        south := rootelemet.FirstChildElement("header").DoubleAttribute("south")
        west := rootelemet.FirstChildElement("header").DoubleAttribute("west")
        if rootelemet.FirstChildElement("header").FirstChildElement("geoReference") != nil {
            geoReference := rootelemet.FirstChildElement("header").FirstChildElement("geoReference").GetText()
            // PROJ_NEW_API is not defined in Go, so this part is omitted
        }
        coordTransApiLonlat2Mercator(x, y)
        *x -= west
        *y -= south
    }
    coordTransApiLonlat2Mercator(x, y)
}

func (o *OpenDriveOutput) transformAngle(centerPoint txPoint, rad float64, point txPoint) txPoint {
    ret := txPoint{}
    ret.x = (point.x-centerPoint.x)*math.Cos(rad) - (point.y-centerPoint.y)*math.Sin(rad) + centerPoint.x
    ret.y = (point.y-centerPoint.y)*math.Cos(rad) + (point.x-centerPoint.x)*math.Sin(rad) + centerPoint.y
    return ret
}

func (o *OpenDriveOutput) rotate(angle float64, x, y *float64) {
    cos_a := math.Cos(angle)
    sin_a := math.Sin(angle)
    xx := *x * cos_a - *y * sin_a
    yy := *y * cos_a + *x * sin_a
    *x = xx
    *y = yy
}

func (o *OpenDriveOutput) controlPointsToPloy3(pts []txPoint, _ele *ele) {
    if len(pts) != 4 {
        return
    }
    s := pts[1].x
    x1 := pts[0].x - s
    x2 := pts[1].x - s
    x3 := pts[2].x - s
    x4 := pts[3].x - s
    A := matrix4d{}
    A.data = []float64{x1 * x1 * x1, x1 * x1, x1, 1, x2 * x2 * x2, x2 * x2, x2, 1, x3 * x3 * x3, x3 * x3, x3, 1, x4 * x4 * x4, x4 * x4, x4, 1}
    b := vector4d{pts[0].y, pts[1].y, pts[2].y, pts[3].y}
    x := A.colPivHouseholderQr().solve(b)
    _ele.d = x.data[0]
    _ele.c = x.data[1]
    _ele.b = x.data[2]
    _ele.a = x.data[3]
    _ele.s = pts[1].x
}

func (o *OpenDriveOutput) controlPointsToParamPloy(pts []txPoint, plan *PlanView) {
    if len(pts) != 4 {
        return
    }
    P0 := pts[0]
    P1 := pts[1]
    P2 := pts[2]
    P3 := pts[3]
    P11 := P1
    t0 := 0
    t1 := math.Pow(distanceTwoPoint(pts[0], pts[1]), 0.5) + t0
    t2 := math.Pow(distanceTwoPoint(pts[1], pts[2]), 0.5) + t1
    t3 := math.Pow(distanceTwoPoint(pts[2], pts[3]), 0.5) + t2
    t := t1
    A1 := P0*(t1-t)/(t1-t0) + P1*(t-t0)/(t1-t0)
    A2 := P1*(t2-t)/(t2-t1) + P2*(t-t1)/(t2-t1)
    A3 := P2*(t3-t)/(t3-t2) + P3*(t-t2)/(t3-t2)
    B1 := A1*(t2-t)/(t2-t0) + A2*(t-t0)/(t2-t0)
    B2 := A2*(t3-t)/(t3-t1) + A3*(t-t1)/(t3-t1)
    A1p := (P1 - P0) / (t1 - t0)
    A2p := (P2 - P1) / (t2 - t1)
    A3p := (P3 - P2) / (t3 - t2)
    B1p := (A2 - A1) / (t2 - t0) + A1p*(t2-t)/(t2-t0) + A2p*(t-t0)/(t2-t0)
    B2p := (A3 - A2) / (t3 - t1) + A2p*(t3-t)/(t3-t1) + A3p*(t-t1)/(t3-t1)
    Cp := (B2 - B1) / (t2 - t1) + B1p*(t2-t)/(t2-t1) + B2p*(t-t1)/(t2-t1)
    hdg := math.Atan2(Cp.y, Cp.x)
    P0 = P0 - P11
    o.rotate(-hdg, &P0.x, &P0.y)
    P1 = P1 - P11
    o.rotate(-hdg, &P1.x, &P1.y)
    P2 = P2 - P11
    o.rotate(-hdg, &P2.x, &P2.y)
    P3 = P3 - P11
    o.rotate(-hdg, &P3.x, &P3.y)
    t0 = 0
    t1 = math.Pow(distanceTwoPoint(P0, P1), 0.5) + t0
    t2 = math.Pow(distanceTwoPoint(P1, P2), 0.5) + t1
    t3 = math.Pow(distanceTwoPoint(P2, P3), 0.5) + t2
    t10 := t1 - t0
    t20 := t2 - t0
    t21 := t2 - t1
    t31 := t3 - t1
    t32 := t3 - t2
    aa1 := (P1 - P0) * t21 / t10
    ba1 := P1
    aa2 := P2 - P1
    ba2 := P1
    aa3 := (P3 - P2) * t21 / t32
    ba3 := (P2*t31 - P3*t21) / t32
    ab1 := (aa2 - aa1) * t21 / t20
    bb1 := (aa1*t21 + aa2*t10) / t20
    cb1 := P1
    ab2 := (aa3 - aa2) * t21 / t31
    bb2 := (aa2*t31 - (ba2 - ba3)*t21) / t31
    cb2 := P1
    a := ab2 - ab1
    pp := ab1 - bb1
    b := pp + bb2
    c := bb1
    d := cb1
    plan.aU = d.x
    plan.aV = d.y
    plan.bU = c.x
    plan.bV = c.y
    plan.cU = b.x
    plan.cV = b.y
    plan.dU = a.x
    plan.dV = a.y
    plan.Type = "paramPoly3"
    plan.hdg = hdg
    plan.x = P11.x
    plan.y = P11.y
    lastPoint := pts[1]
    length := 0.0
    for i := 0; i < 101; i++ {
        p := 0.01 * float64(i)
        tmp := txPoint{}
        tmp.x = plan.aU + plan.bU*p + plan.cU*p*p + plan.dU*p*p*p
        tmp.y = plan.aV + plan.bV*p + plan.cV*p*p + plan.dV*p*p*p
        tmp111 := tmp
        o.rotate(hdg, &tmp111.x, &tmp111.y)
        tmp111.x += pts[1].x
        tmp111.y += pts[1].y
        tmp.x += pts[1].x
        tmp.y += pts[1].y
        tmp = o.transformAngle(P11, -hdg, tmp)
        length += distanceTwoPoint(lastPoint, tmp111)
        lastPoint = tmp111
    }
    plan.length = length
}

func (o *OpenDriveOutput) getHdg(frontPoint, nextPoint txPoint) float64 {
    return math.Atan2((frontPoint.y - frontPoint.y), (nextPoint.x - nextPoint.x))
}

type txPoint struct {
    x float64
    y float64
}

type ele struct {
    d float64
    c float64
    b float64
    a float64
    s float64
}


type matrix4d struct {
    data []float64
}

type vector4d struct {
    data []float64
}
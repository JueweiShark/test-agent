package hadmap

import "errors"

type BoundaryData struct {
    // Define the fields for BoundaryData here
}
type txLaneBoundary struct {
    data        txLaneBoundaryData
    geom        txLineCurve
    instancePtr *BoundaryData
}

type txLaneBoundaryData struct {
    pkid            laneboundarypkid
    srs             uint32
    geom            []Point3d
    lane_mark       uint32
    lane_width      float64
    double_interval float64
    dot_space       float64
    dot_offset      float64
    dot_len         float64
}

type txPoint3d struct {
    x, y, z float64
}

func (l *txLaneBoundary) getTxData() txLaneBoundaryData {
    return l.data
}

func (l *txLaneBoundary) getId() laneboundarypkid {
    return l.data.pkid
}

func (l *txLaneBoundary) setId(id laneboundarypkid) *txLaneBoundary {
    l.data.pkid = id
    return l
}

func (l *txLaneBoundary) getSrs() uint32 {
    return l.data.srs
}

func (l *txLaneBoundary) setSrs(srs uint32) *txLaneBoundary {
    l.data.srs = srs
    return l
}

func (l *txLaneBoundary) getGeometry() *txLineCurve {
    return &l.geom
}

func (l *txLaneBoundary) setGeometry(curve *txLineCurve) *txLaneBoundary {
    l.geom = *curve
    return l
}

func (l *txLaneBoundary) setGeometry(points []txPoint, ct CoordType) error {
    if l.geom.coords == nil {
        l.geom.coords = make([]txPoint3d, len(points))
    } else if len(l.geom.coords) != len(points) {
        return errors.New("Invalid number of points")
    }
    for i, p := range points {
        l.geom.coords[i] = txPoint3d{p.x, p.y, p.z}
    }
    l.geom.coordType = ct
    return nil
}

func (l *txLaneBoundary) transfer(oldEnuC, newEnuC txPoint) *txLaneBoundary {
    if l.geom.empty() {
        return l
    }
    l.geom.transfer(oldEnuC, newEnuC)
    return l
}

func (l *txLaneBoundary) transfer2ENU(enuCenter txPoint) *txLaneBoundary {
    if l.geom.empty() {
        return l
    }
    l.geom.transfer2ENU(enuCenter)
    return l
}

func (l *txLaneBoundary) setLaneMark(mark LANE_MARK) *txLaneBoundary {
    l.data.lane_mark = uint32(mark)
    return l
}

func (l *txLaneBoundary) setLaneWidth(w float64) *txLaneBoundary {
    l.data.lane_width = w
    return l
}

func (l *txLaneBoundary) setDoubleInterval(d float64) *txLaneBoundary {
    l.data.double_interval = d
    return l
}

func (l *txLaneBoundary) setDotSpace(d float64) *txLaneBoundary {
    l.data.dot_space = d
    return l
}

func (l *txLaneBoundary) setDotOffset(d float64) *txLaneBoundary {
    l.data.dot_offset = d
    return l
}

func (l *txLaneBoundary) setDotLen(d float64) *txLaneBoundary {
    l.data.dot_len = d
    return l
}

func (l *txLaneBoundary) getLaneMark() LANE_MARK {
    return LANE_MARK(l.data.lane_mark)
}

func (l *txLaneBoundary) getLaneWidth() float64 {
    return l.data.lane_width
}

func (l *txLaneBoundary) getDoubleInterval() float64 {
    return l.data.double_interval
}

func (l *txLaneBoundary) getDotSpace() float64 {
    return l.data.dot_space
}

func (l *txLaneBoundary) getDotOffset() float64 {
    return l.data.dot_offset
}

func (l *txLaneBoundary) getDotLen() float64 {
    return l.data.dot_len
}

func (l *txLaneBoundary) reverse() bool {
    if l.geom.empty() {
        return false
    }
    l.geom.reverse()
    return true
}

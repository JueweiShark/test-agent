package hadmap

import (
    "fmt"
    "strings"
)

type TxRoad struct {
    // road member variables
    instancePtr *RoadData
}

type RoadData struct{}
type tx_road_t struct {
    pkid            roadpkid
    name            [256]byte
    task_pkid       taskpkid
    ground          float64
    speed_limit     uint32
    road_type       ROAD_TYPE
    direction       uint8
    toll            uint8
    func_class      uint8
    urban           bool
    paved           bool
    transition_type uint8
    lane_mark       bool
    material        ROAD_MATERIAL
    curvaturesss    txCurvatureVec
    slopevec        txSlopeVec
    preLink         txRoadLink
    endLink         txRoadLink
    controlPoint    txControlPoint
    opencrg         txOpenCrgVec
    eleControlPoint txControlPoint
}

func (r *txRoad) GetUniqueId() string {
    return fmt.Sprintf("road_%d", r.instancePtr.data.pkid)
}

func (r *txRoad) GetTxData() *tx_road_t {
    return &r.instancePtr.data
}

func (r *txRoad) GetLinkType() LINK_TYPE {
    return LINK_TYPE_ROAD
}

func (r *txRoad) GetId() roadpkid {
    return r.instancePtr.data.pkid
}

func (r *txRoad) GetTaskId() taskpkid {
    return r.instancePtr.data.task_pkid
}

func (r *txRoad) GetName() string {
    return strings.TrimRight(string(r.instancePtr.data.name[:]), "\x00")
}

func (r *txRoad) GetLength() float64 {
    if r.instancePtr.geom != nil {
        return r.instancePtr.geom.GetLength()
    }
    var length float64
    for _, section := range r.instancePtr.sections {
        length += section.GetLength()
    }
    return length
}

func (r *txRoad) GetGeometry() *txLineCurve {
    return r.instancePtr.geom
}

func (r *txRoad) GetGround() float64 {
    return r.instancePtr.data.ground
}

func (r *txRoad) GetSpeedLimit() uint32 {
    return r.instancePtr.data.speed_limit
}

func (r *txRoad) GetRoadType() ROAD_TYPE {
    return r.instancePtr.data.road_type
}

func (r *txRoad) GetDirection() uint8 {
    return r.instancePtr.data.direction
}

func (r *txRoad) GetToll() uint8 {
    return r.instancePtr.data.toll
}

func (r *txRoad) GetFuncClass() uint8 {
    return r.instancePtr.data.func_class
}

func (r *txRoad) IsUrban() bool {
    return r.instancePtr.data.urban
}

func (r *txRoad) IsPaved() bool {
    return r.instancePtr.data.paved
}

func (r *txRoad) GetTransType() uint8 {
    return r.instancePtr.data.transition_type
}

func (r *txRoad) HasLaneMarking() bool {
    return r.instancePtr.data.lane_mark
}

func (r *txRoad) GetMaterial() ROAD_MATERIAL {
    return r.instancePtr.data.material
}

func (r *txRoad) GetSections() txSections {
    return r.instancePtr.sections
}

func (r *txRoad) GetLane(sectionId sectionpkid, laneId lanepkid) txLanePtr {
    var lanePtr txLanePtr
    for _, section := range r.instancePtr.sections {
        if section.GetId() == sectionId {
            lanePtr = section.Get(laneId)
            break
        }
    }
    return lanePtr
}

func (r *txRoad) GetCurvature() txCurvatureVec {
    return r.instancePtr.data.curvaturesss
}

func (r *txRoad) GetSlope() txSlopeVec {
    return r.instancePtr.data.slopevec
}

func (r *txRoad) GetRoadPreLink() txRoadLink {
    return r.instancePtr.data.preLink
}

func (r *txRoad) GetRoadToLink() txRoadLink {
    return r.instancePtr.data.endLink
}

func (r *txRoad) GetControlPoint() txControlPoint {
    return r.instancePtr.data.controlPoint
}

func (r *txRoad) GetCrgVec() txOpenCrgVec {
    return r.instancePtr.data.opencrg
}

func (r *txRoad) GetElePoint() txControlPoint {
    return r.instancePtr.data.eleControlPoint
}

func (r *txRoad) IsBidirectional() bool {
    for _, section := range r.instancePtr.sections {
        lanes := section.GetLanes()
        if len(lanes) > 0 && lanes[0].GetId() > 0 {
            return true
        }
    }
    return false
}

func (r *txRoad) SetId(id roadpkid) *txRoad {
    r.instancePtr.data.pkid = id
    for _, section := range r.instancePtr.sections {
        section.SetRoadId(id)
    }
    return r
}

func (r *txRoad) SetName(name string) *txRoad {
    copy(r.instancePtr.data.name[:], name)
    return r
}

func (r *txRoad) SetGeometry(curvePtr *txLineCurve) *txRoad {
    if r.instancePtr.geom == nil {
        r.instancePtr.geom = &txLineCurve{}
    }
    r.instancePtr.geom.clone(curvePtr)
    return r
}

func (r *txRoad) SetGeometryFromInstance(curveIns txLineCurve) *txRoad {
    if r.instancePtr.geom == nil {
        r.instancePtr.geom = &txLineCurve{}
    }
    r.instancePtr.geom.clone(&curveIns)
    return r
}

func (r *txRoad) SetGeometryFromPoints(points PointVec, ct CoordType) *txRoad {
    if r.instancePtr.geom == nil {
        r.instancePtr.geom = &txLineCurve{ct: ct}
    }
    if ct != r.instancePtr.geom.ct {
        r.instancePtr.geom.ct = ct
    }
    r.instancePtr.geom.setCoords(points)

    r.instancePtr.data.geom = make([]Point3d, len(points))
    for i, point := range points {
        r.instancePtr.data.geom[i] = Point3d{point.x, point.y, point.z}
    }
    return r
}

func (r *txRoad) transfer(oldEnuC, newEnuC txPoint) *txRoad {
    if r.instancePtr.geom == nil || r.instancePtr.geom.IsEmpty() {
        return r
    }
    r.instancePtr.geom.Transfer(oldEnuC, newEnuC)
    return r
}

func (r *txRoad) transfer2ENU(enuCenter txPoint) *txRoad {
    if r.instancePtr.geom == nil || r.instancePtr.geom.IsEmpty() {
        return r
    }
    r.instancePtr.geom.Transfer2ENU(enuCenter)
    return r
}

func (r *txRoad) setSpeedLimit(speed uint32) *txRoad {
    r.instancePtr.data.speed_limit = speed
    return r
}

func (r *txRoad) setGround(g float64) *txRoad {
    r.instancePtr.data.ground = g
    return r
}

func (r *txRoad) setRoadType(roadType ROAD_TYPE) *txRoad {
    r.instancePtr.data.road_type = uint32(roadType)
    return r
}

func (r *txRoad) setDirection(direction uint8) *txRoad {
    r.instancePtr.data.direction = direction
    return r
}

func (r *txRoad) setToll(toll uint8) *txRoad {
    r.instancePtr.data.toll = toll
    return r
}

func (r *txRoad) setFuncClass(funcClass uint8) *txRoad {
    r.instancePtr.data.func_class = funcClass
    return r
}

func (r *txRoad) setUrban(flag bool) *txRoad {
    r.instancePtr.data.urban = flag
    return r
}

func (r *txRoad) setPaved(flag bool) *txRoad {
    r.instancePtr.data.paved = flag
    return r
}

func (r *txRoad) setTransType(transType uint8) *txRoad {
    r.instancePtr.data.transition_type = transType
    return r
}

func (r *txRoad) setLaneMarking(flag bool) *txRoad {
    r.instancePtr.data.lane_mark = flag
    return r
}

func (r *txRoad) setMaterial(material ROAD_MATERIAL) *txRoad {
    r.instancePtr.data.material = uint32(material)
    return r
}

func (r *txRoad) addSection(sectionPtr *txSection) *txRoad {
    for _, section := range r.instancePtr.sections {
        if section.GetId() == sectionPtr.GetId() {
            return r
        }
    }
    r.instancePtr.sections = append(r.instancePtr.sections, sectionPtr)
    r.instancePtr.sections[len(r.instancePtr.sections)-1].SetRoadId(r.instancePtr.data.pkid)
    r.instancePtr.sections[len(r.instancePtr.sections)-1].SetRoad(r)
    return r
}

func (r *txRoad) setSections(sections []*txSection) *txRoad {
    if len(sections) == 0 {
        return r
    }
    r.instancePtr.sections = nil
    for _, section := range sections {
        curSecPtr := &txSection{*section}
        curSecPtr.BindSectionPtr()
        r.addSection(curSecPtr)
    }
    return r
}

func (r *txRoad) setTaskId(taskId string) *txRoad {
    r.instancePtr.data.task_pkid = taskId
    return r
}

func (r *txRoad) setCurvature(vec []float64) *txRoad {
    r.instancePtr.data.curvaturesss = vec
    return r
}

func (r *txRoad) setSlope(vec []float64) *txRoad {
    r.instancePtr.data.slopevec = vec
    return r
}

func (r *txRoad) setElePoint(ele txControlPoint) *txRoad {
    r.instancePtr.data.eleControlPoint = ele
    return r
}

func (r *txRoad) setPreLink(link txRoadLink) *txRoad {
    r.instancePtr.data.preLink = link
    return r
}

func (r *txRoad) setToLink(link txRoadLink) *txRoad {
    r.instancePtr.data.endLink = link
    return r
}

func (r *txRoad) setControlPoint(point txControlPoint) *txRoad {
    r.instancePtr.data.controlPoint = point
    return r
}

func (r *txRoad) setCrgs(crgs []txOpenCrg) *txRoad {
    r.instancePtr.data.opencrg = crgs
    return r
}

func (r *txRoad) reverse() bool {
    r.instancePtr.geom.Reverse()
    if len(r.instancePtr.sections) == 0 {
        return true
    }
    for i, j := 0, len(r.instancePtr.sections)-1; i <= j; i, j = i+1, j-1 {
        if i == j {
            r.instancePtr.sections[i].Reverse()
            break
        }
        frontId := r.instancePtr.sections[i].GetId()
        backId := r.instancePtr.sections[j].GetId()
        r.instancePtr.sections[i].Reverse()
        r.instancePtr.sections[j].Reverse()
        r.instancePtr.sections[i].SetId(backId)
        r.instancePtr.sections[j].SetId(frontId)
        r.instancePtr.sections[i], r.instancePtr.sections[j] = r.instancePtr.sections[j], r.instancePtr.sections[i]
    }
    return true
}

func (r *txRoad) exchangeBoundaryIndex(curLane, oppositeLane bool) bool {
    for _, section := range r.instancePtr.sections {
        section.ExchangeBoundaryIndex(curLane, oppositeLane)
    }
    return true
}

func (r *txRoad) bindRoadPtr() *txRoad {
    for _, section := range r.instancePtr.sections {
        section.SetRoad(r)
    }
    return r
}

func (r *txRoad) buildInnerTopo() bool {
    if len(r.instancePtr.sections) == 0 {
        return false
    }
    if len(r.instancePtr.sections) == 1 {
        return true
    }
    for i := 0; i < len(r.instancePtr.sections)-1; i++ {
        frontLanes := r.instancePtr.sections[i].GetLanes()
        backLanes := r.instancePtr.sections[i+1].GetLanes()
        for _, lane := range frontLanes {
            lane.ClearNext()
        }
        for _, lane := range backLanes {
            lane.ClearPrev()
        }
        for _, lane := range frontLanes {
            if lane.GetGeometry() != nil && !lane.GetGeometry().IsEmpty() {
                end := lane.GetGeometry().GetEnd()
                for _, backLane := range backLanes {
                    if backLane.GetGeometry() != nil && !backLane.GetGeometry().IsEmpty() {
                        begin := backLane.GetGeometry().GetStart()
                        dis := map_util.DistanceBetweenPoints(Point3d{end.x, end.y, end.z}, Point3d{begin.x, begin.y, begin.z}, lane.GetGeometry().GetCoordType() == COORD_WGS84)
                        if dis < 0.15 {
                            lane.AddNext(backLane.GetUniqueId())
                            backLane.AddPrev(lane.GetUniqueId())
                        }
                    }
                }
            }
        }
    }
    return true
}

func (r *txRoad) buildOuterTopo(nextRoadPtr *txRoad) bool {
    if nextRoadPtr == nil || len(nextRoadPtr.instancePtr.sections) == 0 {
        return false
    }
    frontLanes := r.instancePtr.sections[len(r.instancePtr.sections)-1].GetLanes()
    backLanes := nextRoadPtr.instancePtr.sections[0].GetLanes()
    for _, lane := range frontLanes {
        if lane.GetGeometry() != nil && !lane.GetGeometry().IsEmpty() {
            end := lane.GetGeometry().GetEnd()
            for _, backLane := range backLanes {
                if backLane.GetGeometry() != nil && !backLane.GetGeometry().IsEmpty() {
                    begin := backLane.GetGeometry().GetStart()
                    dis := map_util.DistanceBetweenPoints(Point3d{end.x, end.y, end.z}, Point3d{begin.x, begin.y, begin.z}, lane.GetGeometry().GetCoordType() == COORD_WGS84)
                    if dis < 0.15 {
                        lane.AddNext(backLane.GetUniqueId())
                        backLane.AddPrev(lane.GetUniqueId())
                    }
                }
            }
        }
    }
    return true
}

package hadmap

import (
    "sync"
)

type TxJunctions []txJunction

type txJunction struct {
    jId           Junctionpkid
    entranceRoads map[Roadpkid]float64
    exitRoads     map[Roadpkid]float64
    juncRoadsDir  map[Roadpkid]DIR_TYPE
    juncRoads     map[Roadpkid]map[Roadpkid]Roadpkid
    roadPriority  map[Roadpkid]map[Roadpkid]struct{}
    controllers   []*txController
    laneLinkIds   map[Lanelinkpkid]struct{}
    mu            sync.Mutex
}
type TxOdHeaderPtr *txOdHeader

type AreaPointVec [2]struct {
    txPoint1 TxPoint
    txPoint2 TxPoint
}
type TxPoint struct {
    X, Y, Z, W, H, Hdg float64
}

type txRoad struct {
    ID   Roadpkid
    Name string
}
type TXRoads []*txRoad

type TXLaneLinks []txLaneLink

type txLaneLink struct {
    instancePtr *LaneLinkData
}
type LaneLinkData struct {
    data      tx_lanelink_t
    geomPtr   *txLineCurve
    leftBds   txLaneBoundaries
    rightBds  txLaneBoundaries
    radius    float64
    radiusmtx sync.Mutex
}

type tx_lanelink_t struct {
    pkid            Lanelinkpkid
    from_road_pkid  Roadpkid
    from_section_id sectionpkid
    from_lane_id    lanepkid
    to_road_pkid    Roadpkid
    to_section_id   sectionpkid
    to_lane_id      lanepkid
    odr_road_id     Roadpkid
    controlPoint    txControlPoint
    eleControlPoint txControlPoint
    curvature       txCurvatureVec
    slope           txSlopeVec
    preContact      txContactType
    succContact     txContactType
    junction_id     Junctionpkid
    geom            PointVec
}
type txLineCurve struct {
    instancePtr *CurveData
    coordType   CoordType
    coords      []Point3d
    //coords PointVec
}
type txLaneBoundaries []*txLaneBoundary
type txLaneBoundary struct {
    data        txLaneBoundaryData
    geom        txLineCurve
    instancePtr *BoundaryData
}

type txControlPoint struct {
    Type   string
    Points []*TxPoint
}

// Curve curvature structure
type txCurvature struct {
    starts, length, curvature float64
}

// Vector of curve curvatures
type txCurvatureVec []*txCurvature
type txSlope struct {
    starts, length, slope float64
}

// Vector of curve slopes
type txSlopeVec []*txSlope
type txContactType int
type PointVec []*TxPoint
type CurveData struct {
    Geom         PointVec
    DisFromBegin []float64
    PointsYaw    []float64
    PointsNormal []Point2d
    SlRefInfo    []Point3d
    Center       TxPoint
}
type Point2d struct {
    X, Y float64
}

type Point3d struct {
    X, Y, Z float64
}

type txLaneBoundaryData struct {
    pkid            Laneboundarypkid
    srs             uint32
    geom            []Point3d
    lane_mark       uint32
    lane_width      float64
    double_interval float64
    dot_space       float64
    dot_offset      float64
    dot_len         float64
}
type BoundaryData struct {
    Data tx_laneboundary_t
    geom CurveData
}

type tx_laneboundary_t struct {
    Pkid           uint64
    Srs            uint32
    LaneMark       uint32
    LaneWidth      float64
    DoubleInterval float64
    DotSpace       float64
    DotOffset      float64
    DotLen         float64
    Geom           Point3d
}

type txController struct {
    id         controllerkid
    ctlSignals []objectpkid
}
type TXObjects []txObject
type txObject struct {
    Id         int64 `xml:"id"`
    RoadId     int64 `xml:"roadid"`
    LaneLinkId int64 `xml:"lanelinkid"`
}

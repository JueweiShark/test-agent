package hadmap

import (
    "fmt"
    "math"
    "sync"
)

const (
    M_PI    = 3.14159265358979323846
    VALID_Z = -9999.0
)

type txMapInterface interface {
    UpdateCenter(lonlatele txPoint) bool
    InsertRefPoint(point txPoint) bool
    CenterId() size_t
    GetCenter() txPoint
    GetGeomCoordType() CoordType
    GetProjection() txProjectionConstPtr
    GetRoadById(roadId roadpkid) txRoadPtr
    GetLaneById(laneId txLaneId) txLanePtr
    GetLanes(pos txPoint, radius float64) txLanes
    NearestLane(pos txPoint, radius float64) txLanePtr
    NearestLaneWithYaw(pos txPoint, radius float64, yaw float64) txLanePtr
    NearestLaneLink(pos txPoint, radius float64) txLaneLinkPtr
    GetNextLanes(lanePtr txLanePtr) txLanes
    GetPreLanes(lanePtr txLanePtr) txLanes
    GetLeftLane(lanePtr txLanePtr) txLanePtr
    GetRightLane(lanePtr txLanePtr) txLanePtr
    GetLaneBoundaries(pos txPoint, yaw float64, range_ [2]float64) txLaneBoundaries
    GetObject(objId objectpkid) txObjectPtr
    GetObjectByType(pos txPoint, objType OBJECT_TYPE) txObjectPtr
    GetObjects(envelope PointVec, objTypes []OBJECT_TYPE) txObjects
    GetObjectsWithYaw(envelope PointVec, yaw float64, objTypes []OBJECT_TYPE) txObjects
    GetObjectsInRange(pos txPoint, yaw float64, range_ [2]float64, objTypes []OBJECT_TYPE) txObjects
    GetObjectsByRelation(objTypes []OBJECT_TYPE, relIds []txLaneId) txObjects
    GetObjectsBySubType(objTypes []OBJECT_SUB_TYPE, relIds []txLaneId) txObjects
    GetJunction(jId junctionpkid) txJunctionPtr
    GetJunctions() txJunctions
    PriorityCmp(curPtr txJunctionRoadPtr, cmpPtr txJunctionRoadPtr) PRIORITY_TYPE
    SetHeader(header txOdHeaderPtr)
    GetHeader() txOdHeaderPtr
    GetRefPoint() txPoint
    GetRoads(roads *txRoads) bool
    GetLanes(lanes *txLanes) bool
    GetBoundaries(boundaries *txLaneBoundaries) bool
    GetLaneLinks(links *txLaneLinks) bool
    GetObjects(objects *txObjects) bool
    GetObjectsByType(type_ OBJECT_TYPE, objects *txObjects) bool
    GetJunctions(juncs *txJunctions) bool
    NearestLaneByLoc(loc txPoint, radius float64, lanePtr *txLanePtr) bool
    SearchLanes(envelope PointVec, lanes *txLanes) bool
    SearchBoundaries(envelope PointVec, boundaries *txLaneBoundaries) bool
    GetBoundariesByDistance(pos txPoint, yaw float64, dis float64, boundaries *txLaneBoundaries) bool
    SearchRoads(envelope PointVec, roads *txRoads) bool
    SearchObjects(envelope PointVec, types map[OBJECT_TYPE]bool, relLaneId txLaneId, objects *txObjects) bool
    SearchObjectsBySubType(envelope PointVec, types map[OBJECT_SUB_TYPE]bool, relLaneId txLaneId, objects *txObjects) bool
    LaneWidth(loc txPoint, dis2Left *float64, dis2Right *float64) bool
    RoadWidth(loc txPoint, dis2Left *float64, dis2Right *float64) bool
    NextLanes(curLaneId txLaneId, lanes *txLanes) bool
    SpecLanes(specLaneId txLaneId, lanes *txLanes) bool
    SpecBoundaries(ids []laneboundarypkid, boundaries *txLaneBoundaries) bool
    SpecLinks(fromRoadId roadpkid, toRoadId roadpkid, links *txLaneLinks) bool
    SpecLinksByLaneId(fromLaneId txLaneId, toLaneId txLaneId, links *txLaneLinks) bool
    SpecLinksById(linkIds []lanelinkpkid, links *txLaneLinks) bool
    SpecRoadLink(roadid roadpkid, link *txLaneLinkPtr) bool
    SpecRoadLinks(roadid roadpkid, links *txLaneLinks) bool
    RelObjects(curLaneId txLaneId, types map[OBJECT_TYPE]bool, objects *txObjects) bool
    SpecJunction(jId junctionpkid, juncPtr *txJunctionPtr) bool
    InsertRoad(roadPtr txRoadPtr) bool
    InsertRoads(roads txRoads) bool
    InsertLaneLink(linkPtr txLaneLinkPtr) bool
    InsertLaneLinks(links txLaneLinks) bool
    InsertObject(objectPtr txObjectPtr) bool
    InsertObjects(objects txObjects) bool
    InsertJunction(juncPtr txJunctionPtr) bool
    InsertJunctions(juncs txJunctions) bool
    UpdateRoad(roadPtr txRoadPtr) bool
    UpdateRoads(roads txRoads) bool
    UpdateLaneLink(laneLinkPtr txLaneLinkPtr) bool
    UpdateLaneLinks(laneLinks txLaneLinks) bool
    RemoveRoad(roadId roadpkid) bool
    RemoveRoads(roadIds []roadpkid) bool
    RemoveLinks(laneLinkIds []lanelinkpkid) bool
    RemoveLinksByRoadIds(fromRoadId roadpkid, toRoadId roadpkid) bool
    RemoveObject(objectId objectpkid) bool
    RemoveObjects(objectIds []objectpkid) bool
    RemoveJunction(jId junctionpkid) bool

    getGeomCoordType() CoordType
    getProjection() txProjectionConstPtr
    getRoadById(roadId roadpkid) txRoadPtr
    specLanes(laneId txLaneId, lanes *txLanes) bool
    searchLanes(envelope PointVec, lanes *txLanes) bool
    nearestLane(pos txPoint, radius float64, lanePtr *txLanePtr) bool
    nearestLane(pos txPoint, radius float64, yaw float64, lanePtr *txLanePtr) bool
    nearestLaneLink(pos txPoint, radius float64, linkPtr *txLaneLinkPtr) bool
    nextLanes(laneId txLaneId, lanes *txLanes) bool
    preLanes(laneId txLaneId, lanes *txLanes) bool
    xy2sl(x float64, y float64, s *float64, l *float64) bool
    getPassedDistance(pos txPoint, p txPoint, coordType CoordType) float64
    getSection() txSectionPtr
    getRoad() txRoadPtr
    isJunction() bool
    getBoundariesByRange(start float64, end float64) txLaneBoundaries
    getGeometry() txLineCurvePtr
    getPoints(points *PointVec)
    getEnd() txPoint
    getStart() txPoint
    getLaneMark() LANE_MARK
    getCoordType() CoordType
}

type txMap struct {
    sync.Mutex
    MapData *MapData
    instancePtr txMapInterface
}

type DataGeomIdEx struct {
    data2geom map[interface{}]interface{}
    geom2data map[interface{}]interface{}
    mutex     sync.RWMutex
}

func NewDataGeomIdEx() *DataGeomIdEx {
    return &DataGeomIdEx{
        data2geom: make(map[interface{}]interface{}),
        geom2data: make(map[interface{}]interface{}),
    }
}

func (d *DataGeomIdEx) InsertData2Geom(dataIndex, geomIndex interface{}) error {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    if _, ok := d.data2geom[dataIndex]; ok {
        return errors.New("data index already exists")
    }
    d.data2geom[dataIndex] = geomIndex
    return nil
}

func (d *DataGeomIdEx) InsertGeom2Data(geomIndex, dataIndex interface{}) error {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    if _, ok := d.geom2data[geomIndex]; ok {
        return errors.New("geom index already exists")
    }
    d.geom2data[geomIndex] = dataIndex
    return nil
}

func (d *DataGeomIdEx) GetData2Geom(dataIndex interface{}) (interface{}, error) {
    d.mutex.RLock()
    defer d.mutex.RUnlock()
    if geomIndex, ok := d.data2geom[dataIndex]; ok {
        return geomIndex, nil
    }
    return nil, errors.New("data index not found")
}

func (d *DataGeomIdEx) GetGeom2Data(geomIndex interface{}) (interface{}, error) {
    d.mutex.RLock()
    defer d.mutex.RUnlock()
    if dataIndex, ok := d.geom2data[geomIndex]; ok {
        return dataIndex, nil
    }
    return nil, errors.New("geom index not found")
}

func (d *DataGeomIdEx) RemoveData2Geom(dataIndex interface{}) {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    delete(d.data2geom, dataIndex)
}

func (d *DataGeomIdEx) RemoveGeom2Data(geomIndex interface{}) {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    delete(d.geom2data, geomIndex)
}

func (d *DataGeomIdEx) Clear() {
    d.mutex.Lock()
    defer d.mutex.Unlock()
    d.data2geom = make(map[interface{}]interface{})
    d.geom2data = make(map[interface{}]interface{})
}

type MapData struct {
    Center txPoint
    // srs
    srs uint32

    // coord type
    coordType CoordType

    // road datas
    roadDatas map[roadpkid]*txRoadPtr

    // lane geom ids for spatial index
    roadgeomIdEx DataGeomIdEx[roadpkid, []pkid_t, pkid_t, txLaneId]

    // link datas
    linkDatas map[lanelinkpkid]*txLaneLinkPtr

    fromLinkDatas map[roadpkid]map[lanelinkpkid]struct{}

    toLinkDatas map[roadpkid]map[lanelinkpkid]struct{}

    // link geom ids for spatial index
    linkgeomIdEx DataGeomIdEx[lanelinkpkid, pkid_t, pkid_t, lanelinkpkid]

    // object datas
    objectDatas map[objectpkid]*txObjectPtr

    roadRelObjects map[roadpkid]map[objectpkid]struct{}

    // object geom ids for spatial index
    objectgeomIdEx DataGeomIdEx[objectpkid, pkid_t, pkid_t, objectpkid]

    // geom pkid
    // pkid == 0 -> invalid
    lanegeomId pkid_t

    linkgeomId pkid_t

    objgeomId pkid_t

    // mutex
    roaddataMutex sync.Mutex

    linkdataMutex sync.Mutex

    objdataMutex sync.Mutex

    // spatialindex
    spIndex txSpatialIndex

    centerLL txPoint

    lastCenterLL txPoint

    centerId uint

    centerMutex sync.Mutex

    projPtr *txProjection

    // junction info
    juncDataMutex sync.Mutex

    juncDatas map[junctionpkid]*txJunctionPtr

    // header
    headerptr *txOdHeaderPtr

    //
    ref_point txPoint
}

func (m *MapData) coordDis2D(p0, p1 txPoint) float64 {
    var a, b [3]float64
    if m.coordType == COORD_XYZ || m.coordType == COORD_ENU {
        a[0] = p0.x
        a[1] = p0.y
        a[2] = 0.0
        b[0] = p1.x
        b[1] = p1.y
        b[2] = 0.0
    } else {
        a[0] = p0.x
        a[1] = p0.y
        a[2] = 0.0
        b[0] = p1.x
        b[1] = p1.y
        b[2] = 0.0
        coord_trans_api{}.lonlat2global(a[0], a[1], a[2])
        coord_trans_api{}.lonlat2global(b[0], b[1], b[2])
    }
    return map_util{}.directlyDis(a[:], b[:])
}

func (m *MapData) updateProj() bool {
    m.projPtr.originLL = m.centerLL
    var enu txPoint
    coord_trans_api{}.lonlat2enu(m.lastCenterLL.x, m.lastCenterLL.y, m.lastCenterLL.z, enu.x, enu.y, enu.z)
    if m.centerId == 1 {
        m.projPtr.dx = 0.0
        m.projPtr.dy = 0.0
    } else {
        m.projPtr.dx = enu.x
        m.projPtr.dy = enu.y
    }
    m.projPtr.pId = m.centerId
    return true
}

func (m *MapData) getLaneUnsafe(laneId int, lanePtr *txLane) bool {
    if _, ok := m.roadDatas[laneId]; !ok {
        return false
    } else {
        roadPtr := m.roadDatas[laneId]
        sections := roadPtr.sections
        for _, secPtr := range sections {
            if secPtr.id == laneId {
                lanes := secPtr.lanes
                for _, curLanePtr := range lanes {
                    if curLanePtr.id == laneId {
                        *lanePtr = *curLanePtr
                        return true
                    }
                }
            }
        }
        return false
    }
}

func (m *MapData) setLaneGeomToENU(lanePtr *txLane, center txPoint) {
    if lanePtr != nil && lanePtr.geometry != nil && len(lanePtr.geometry.coords) > 0 {
        curvePtr := lanePtr.geometry
        var points []txPoint
        curvePtr.getPoints(&points)
        for i := range points {
            coord_trans_api{}.lonlat2enu(points[i].x, points[i].y, points[i].z, center.x, center.y, center.z)
        }
        lanePtr.geometry.setCoords(points)
    }
}

func (m *MapData) setRoadGeomToENU(roadPtr *txRoad, center txPoint) {
    if roadPtr != nil && roadPtr.geometry != nil && len(roadPtr.geometry.coords) > 0 {
        curvePtr := roadPtr.geometry
        var points []txPoint
        curvePtr.getPoints(&points)
        for i := range points {
            coord_trans_api{}.lonlat2enu(points[i].x, points[i].y, points[i].z, center.x, center.y, center.z)
        }
        roadPtr.geometry.setCoords(points)
    }
}

func (m *MapData) setBoundaryGeomToENU(boundaryPtr *txLaneBoundary, center txPoint) {
    if boundaryPtr != nil && boundaryPtr.geometry != nil && len(boundaryPtr.geometry.coords) > 0 {
        curvePtr := boundaryPtr.geometry
        var points []txPoint
        curvePtr.getPoints(&points)
        for i := range points {
            coord_trans_api{}.lonlat2enu(points[i].x, points[i].y, points[i].z, center.x, center.y, center.z)
        }
        boundaryPtr.geometry.setCoords(points)
    }
}

func (m *MapData) transferRoadGeomToENU(roadPtr *txRoad, enuCenter txPoint) {
    if roadPtr == nil || len(roadPtr.sections) == 0 {
        return
    } else {
        if enuCenter.x < 1e-5 && enuCenter.y < 1e-5 && enuCenter.z < 1e-5 {
            enuCenter = roadPtr.geometry.getStart()
        }
        roadPtr.transfer2ENU(enuCenter)
        sections := roadPtr.sections
        for _, secPtr := range sections {
            lanes := secPtr.lanes
            var boundarySets map[int]bool
            for _, lanePtr := range lanes {
                lanePtr.transfer2ENU(enuCenter)
                if lanePtr.leftBoundaryId != BOUN_PKID_INVALID && !boundarySets[lanePtr.leftBoundaryId] {
                    lanePtr.leftBoundary.transfer2ENU(enuCenter)
                    boundarySets[lanePtr.leftBoundaryId] = true
                }
                if lanePtr.rightBoundaryId != BOUN_PKID_INVALID && !boundarySets[lanePtr.rightBoundaryId] {
                    lanePtr.rightBoundary.transfer2ENU(enuCenter)
                    boundarySets[lanePtr.rightBoundaryId] = true
                }
            }
        }
    }
}

func (m *MapData) setCurveToMercator(curvePtr *txLineCurve) {
    if curvePtr != nil {
        var points []txPoint
        curvePtr.getPoints(&points)
        for i := range points {
            coord_trans_api{}.lonlat2mercator(points[i].x, points[i].y)
        }
        curvePtr.setCoordType(COORD_ENU)
        curvePtr.setCoords(points)
    }
}

func (m *MapData) buildSpatialIndex(type_ SpatialDataType, curvePtr *txLineCurve, curveIndex int) bool {
    if m.coordType != COORD_WGS84 {
        return m.spIndex.insert(type_, curvePtr, curveIndex)
    } else {
        mercatorGeom := &txLineCurve{coordType: COORD_WGS84}
        var points []txPoint
        curvePtr.getPoints(&points)
        mercatorGeom.setCoords(points)
        m.setCurveToMercator(mercatorGeom)
        r := m.spIndex.insert(type_, mercatorGeom, curveIndex)
        return r
    }
}

func (m *MapData) spatialSearch(type_ SpatialDataType, envelope txEnvelope, curveIndexes []pkid_t) bool {
if m.coordType == COORD_XYZ || m.coordType == COORD_ENU {
        return m.spIndex.search(type_, envelope, curveIndexes)
    } else {
        envelope.bMin[0], envelope.bMin[1] = coord_trans_api.LonLat2Mercator(envelope.bMin[0], envelope.bMin[1])
        envelope.bMax[0], envelope.bMax[1] = coord_trans_api.LonLat2Mercator(envelope.bMax[0], envelope.bMax[1])
        return m.spIndex.search(type_, envelope, curveIndexes)
    }
}

func (m *MapData) spatialSearch_withPointRanges(type_ SpatialDataType, envelope txEnvelope, curveIndexes []pkid_t, pointRanges []struct{ size_t, size_t }) bool {
    if m.coordType == COORD_XYZ || m.coordType == COORD_ENU {
        return m.spIndex.search(type_, envelope, curveIndexes, pointRanges)
    } else {
        envelope.bMin[0], envelope.bMin[1] = coord_trans_api.LonLat2Mercator(envelope.bMin[0], envelope.bMin[1])
        envelope.bMax[0], envelope.bMax[1] = coord_trans_api.LonLat2Mercator(envelope.bMax[0], envelope.bMax[1])
        return m.spIndex.search(type_, envelope, curveIndexes, pointRanges)
    }
}

func (m *MapData) laneIdMatching(id0 txLaneId, id1 txLaneId) bool {
    if id0.roadId == ROAD_PKID_INVALID || id1.roadId == ROAD_PKID_INVALID || id0.roadId == id1.roadId {
        if id0.sectionId == SECT_PKID_INVALID || id1.sectionId == SECT_PKID_INVALID || id0.sectionId == id1.sectionId {
            if id0.laneId == LANE_PKID_INVALID || id1.laneId == LANE_PKID_INVALID || id0.laneId == id1.laneId {
                return true
            }
        }
    }
    return false
}

func (m *MapData) point2CurveDis(p txPoint, curvePtr *txLineCurve) float64 {
    if curvePtr == nil {
        return -1.0
    }
    curvePoints := curvePtr.getPoints()

    points := make([]Point2d, len(curvePoints))
    for i, point := range curvePoints {
        points[i] = Point2d{point.x, point.y}
    }

    var index int
    var dis float64
    wgs84Flag := curvePtr.getCoordType() == COORD_WGS84
    map_util.NearestPoint2d(points, Point2d{p.x, p.y}, wgs84Flag, &index, &dis)
    return dis
}

func (m *MapData) point2CurveDis_withGeomRange(p txPoint, curvePtr *txLineCurve, geomRange struct{ size_t, size_t }, useZ bool) float64 {
    if curvePtr == nil {
        return -1.0
    }
    curvePoints := curvePtr.getPoints()
    if geomRange.first > geomRange.second || geomRange.second >= len(curvePoints) {
        return -1.0
    }

    start := geomRange.first
    if start > 0 {
        start--
    }
    end := geomRange.second
    if end == len(curvePoints)-1 {
        end++
    }

    points := make([]Point2d, end-start+1)
    pointIndex := make(map[int]int)
    for i, j := start, 0; i <= end && j < len(points); i, j = i+1, j+1 {
        points[j] = Point2d{curvePoints[i].x, curvePoints[i].y}
        pointIndex[j] = i
    }

    var index int
    var dis float64
    wgs84Flag := curvePtr.getCoordType() == COORD_WGS84
    if !wgs84Flag {
        var s, l, y float64
        if curvePtr.xy2sl(p.x, p.y, &s, &l, &y) {
            if useZ {
                map_util.NearestPoint2d(points, Point2d{p.x, p.y}, false, &index, &dis)
                if index < 0 || index > len(points)-1 {
                    return math.MaxFloat64
                }
                curptIndex := pointIndex[index]
                dis3d := math.Sqrt(math.Pow(dis, 2) + math.Pow(curvePoints[curptIndex].z-p.z, 2))
                return dis3d
            }
            return math.Abs(l)
        } else {
            return math.MaxFloat64
        }
    } else {
        map_util.NearestPoint2d(points, Point2d{p.x, p.y}, wgs84Flag, &index, &dis)
        if useZ {
            if index < 0 || index > len(points)-1 {
                return math.MaxFloat64
            }
            curptIndex := pointIndex[index]
            dis3d := math.Sqrt(math.Pow(dis, 2) + math.Pow(curvePoints[curptIndex].z-p.z, 2))
            return dis3d
        }
        return dis
    }
}

func (m *MapData) point2CurveDis_withYaw(p txPoint, yaw float64, curvePtr *txLineCurve) float64 {
    if curvePtr == nil {
        return -1.0
    }
    curvePoints := curvePtr.getPoints()

    points := make([]Point2d, len(curvePoints))
    for i, point := range curvePoints {
        points[i] = Point2d{point.x, point.y}
    }

    var index int
    var dis float64
    wgs84Flag := curvePtr.getCoordType() == COORD_WGS84
    map_util.NearestPoint2d(points, Point2d{p.x, p.y}, wgs84Flag, &index, &dis)

    curYaw := curvePtr.yaw(index)
    yawDis := math.Abs(curYaw - yaw)
    if yawDis > 180.0 {
        yawDis = 360.0 - yawDis
    }
    yawDis = math.Sin(yawDis*math.Pi/180.0) * 3.0

    return dis + yawDis
}

func (m *MapData) point2CurveDis_withYaw_andGeomRange(p txPoint, yaw float64, curvePtr *txLineCurve, geomRange struct{ size_t, size_t }, useZ bool) float64 {
    if curvePtr == nil {
        return -1.0
    }
    curvePoints := curvePtr.getPoints()
    if geomRange.first > geomRange.second || geomRange.second >= len(curvePoints) {
        return -1.0
    }

    start := geomRange.first
    if start > 0 {
        start--
    }
    end := geomRange.second
    if end == len(curvePoints)-1 {
        end++
    }

    points := make([]Point2d, end-start+1)
    pointIndex := make(map[int]int)
    for i, j := start, 0; i <= end && j < len(points); i, j = i+1, j+1 {
        points[j] = Point2d{curvePoints[i].x, curvePoints[i].y}
        pointIndex[j] = i
    }

    var index int
    var dis float64
    wgs84Flag := curvePtr.getCoordType() == COORD_WGS84
    if wgs84Flag {
        map_util.NearestPoint2d(points, Point2d{p.x, p.y}, wgs84Flag, &index, &dis)
        curYaw := curvePtr.yaw(index)
        yawDis := math.Abs(curYaw - yaw)
        if yawDis > 180.0 {
            yawDis = 360.0 - yawDis
        }
        yawDis = math.Sin(yawDis*math.Pi/180.0) * 3.0

        if useZ {
            if index < 0 || index > len(points)-1 {
                return math.MaxFloat64
            }
            curptIndex := pointIndex[index]
            dis3d := math.Sqrt(math.Pow(dis, 2) + math.Pow(curvePoints[curptIndex].z-p.z, 2))
            return dis3d + yawDis
        }
        return dis + yawDis
    } else {
        var s, l, y float64
        if curvePtr.xy2sl(p.x, p.y, &s, &l, &y) {
            curYaw := y
            yawDis := math.Abs(curYaw - yaw)
            if yawDis > 180.0 {
                yawDis = 360.0 - yawDis
            }
            if yawDis < 90.0 {
                yawDis = math.Sin(yawDis*math.Pi/180.0) * 3.0
            } else {
                yawDis = (2.0 - math.Sin(yawDis*math.Pi/180.0)) * 3.0
            }

            if useZ {
                map_util.NearestPoint2d(points, Point2d{p.x, p.y}, false, &index, &dis)
                if index < 0 || index > len(points)-1 {
                    return math.MaxFloat64
                }
                curptIndex := pointIndex[index]
                dis3d := math.Sqrt(math.Pow(dis, 2) + math.Pow(curvePoints[curptIndex].z-p.z, 2))
                return dis3d + yawDis
            }
            return math.Abs(l) + yawDis
        } else {
            return math.MaxFloat64
        }
    }
}

func (m *MapData) getMinHeight(curvePtr *txLineCurve) (float64, error) {
    if curvePtr == nil {
        return -10000.0, nil
    }
    minHeight := 10000.0
    curvePoints := curvePtr.getPoints()
    for _, it := range curvePoints {
        if it.z < minHeight {
            minHeight = it.z
        }
    }
    return minHeight, nil
}

func (m *MapData) getCenterId() int {
    m.centerMutex.Lock()
    defer m.centerMutex.Unlock()
    return m.centerId
}

func (m *MapData) getCenter() txPoint {
    m.centerMutex.Lock()
    defer m.centerMutex.Unlock()
    return m.centerLL
}

func (m *MapData) getProjection() (*txProjectionConstPtr, error) {
    if m.coordType == COORD_ENU {
        m.centerMutex.Lock()
        defer m.centerMutex.Unlock()
        return m.projPtr, nil
    }
    return nil, errors.New("Invalid coordinate type")
}

func (m *MapData) insertRoad(roadPtr *txRoad) bool {
    if roadPtr == nil || len(roadPtr.sections) == 0 {
        return false
    }
    m.centerMutex.Lock()
    curCenter := m.centerLL
    m.centerMutex.Unlock()
    m.roaddataMutex.Lock()
    defer m.roaddataMutex.Unlock()
    if _, ok := m.roadDatas[roadPtr.id]; ok {
        return false
    }
    m.roadDatas[roadPtr.id] = roadPtr
    boundaryIds := make(map[laneboundarypkid]struct{})
    geomIds := make([]int, 0)
    for _, secPtr := range roadPtr.sections {
        lanebds := make(map[laneboundarypkid]*txLaneBoundary)
        for _, bd := range secPtr.boundaries {
            if bd != nil {
                lanebds[bd.id] = bd
            }
        }
        for _, lanePtr := range secPtr.lanes {
            if lanePtr.geometry == nil || len(*lanePtr.geometry) == 0 {
                continue
            }
            lbdid := lanePtr.leftBoundaryId
            rbdid := lanePtr.rightBoundaryId
            curline := txLineCurve{coordType: lanePtr.geometry.coordType}
            if _, ok := lanebds[lbdid]; ok && _, ok := lanebds[rbdid]; ok {
                bdl := lanebds[lbdid]
                bdr := lanebds[rbdid]
                pointsl, pointsr := bdl.geometry.getPoints(), bdr.geometry.getPoints()
                N := max(len(pointsl), len(pointsr))
                for i := 0; i < N; i++ {
                pl, pr := pointsl[i], pointsr[i]
                dis := map_util.DistanceBetweenPoints(Point3d{pl.x, pl.y, pl.z}, Point3d{pr.x, pr.y, pr.z}, bdl.geometry.coordType == COORD_WGS84)
                edge := 1
                if dis > edge*4.001 {
                c := int((dis-edge-edge)/edge/2) * 2
                step := (dis-edge-edge) / c
                sstep := make([]float64, c+1)
                sstep[0] = edge
                for s := 1; s <= c; s++ {
                sstep[s] = edge + s*step
            }
                dx, dy, dz := (pr.x-pl.x)/dis, (pr.y-pl.y)/dis, (pr.z-pl.z)/dis
                for _, s := range sstep {
                p := txPoint{pl.x + dx*s, pl.y + dy*s, pl.z + dz*s}
                curline.addPoint(p, false)
            }
            } else {
                p := txPoint{pl.x + pr.x, pl.y + pr.y, pl.z + pr.z}
                p.x, p.y, p.z = p.x*0.5, p.y*0.5, p.z*0.5
                curline.addPoint(p, false)
            }
            }
            }
            curPtr := &curline
            if curline.empty() {
                curPtr = lanePtr.geometry
            }
            lanePtr.setDenseGeometry(*curPtr)
            curLaneGeomId := m.lanegeomId
            m.lanegeomId++
            if m.buildSpatialIndex(LANE_SP, curPtr, curLaneGeomId) {
                geomIds = append(geomIds, curLaneGeomId)
                m.roadgeomIdEx[curLaneGeomId] = txLaneId{lanePtr.roadId, lanePtr.sectionId, lanePtr.id}
            }
        }
    }
    m.roadgeomIdEx[roadPtr.id] = geomIds
    if m.coordType == COORD_ENU {
        m.transferRoadGeomToENU(roadPtr, curCenter)
    }
    return true
}

func (m *MapData) insertRoads(roads []*txRoad) bool {
    r := true
    for _, roadPtr := range roads {
        r = r && m.insertRoad(roadPtr)
    }
    return r
}

func (m *MapData) insertLaneLink(linkPtr *txLaneLink) bool {
    if linkPtr == nil {
        return false
    }
    m.linkdataMutex.Lock()
    defer m.linkdataMutex.Unlock()
    if _, ok := m.linkDatas[linkPtr.id]; ok {
        return false
    }
    m.linkDatas[linkPtr.id] = linkPtr
    if _, ok := m.fromLinkDatas[linkPtr.fromRoadId]; !ok {
        m.fromLinkDatas[linkPtr.fromRoadId] = make(map[int]struct{})
    }
    if _, ok := m.toLinkDatas[linkPtr.toRoadId]; !ok {
        m.toLinkDatas[linkPtr.toRoadId] = make(map[int]struct{})
    }
    m.fromLinkDatas[linkPtr.fromRoadId][linkPtr.id] = struct{}{}
    m.toLinkDatas[linkPtr.toRoadId][linkPtr.id] = struct{}{}
    if linkPtr.geometry == nil || len(*linkPtr.geometry) == 0 {
        return true
    } else {
        curLinkGeomId := m.linkgeomId
        m.linkgeomId++
        curvePtr := linkPtr.geometry
        if m.buildSpatialIndex(LINK_SP, curvePtr, curLinkGeomId) {
            m.linkgeomIdEx[linkPtr.id] = curLinkGeomId
            m.linkgeomIdEx[curLinkGeomId] = linkPtr.id
        }
        return true
    }
}

func max(a, b int) int {
    if a > b {
        return a
    }
    return b
}

func (md *MapData) insertLaneLinks(links txLaneLinks) bool {
    r := true
    fmt.Println("MapData inserts lanelinks:", len(links))
    for _, linkPtr := range links {
        fmt.Println("insert lanelink =", linkPtr.Id)
        r = r && md.insertLaneLink(linkPtr)
    }
    return r
}

func (md *MapData) insertObject(objectPtr *txObject) bool {
    if objectPtr == nil {
        return false
    }

    md.centerMutex.Lock()
    defer md.centerMutex.Unlock()
    curCenter := md.centerLL

    md.objdataMutex.Lock()
    defer md.objdataMutex.Unlock()
    if _, ok := md.objectDatas[objectPtr.Id]; ok {
        return false
    }

    md.objectDatas[objectPtr.Id] = objectPtr

    if objectPtr.getGeom().getGeometry() == nil || objectPtr.getGeom().getGeometry().empty() {
    } else {
        curObjGeomId := md.objgeomId
        md.objgeomId++
        curObjGeomId = md.buildSpatialIndex(OBJ_SP, objectPtr.getGeom().getGeometry(), curObjGeomId)
        md.objectgeomIdEx[objectPtr.Id] = curObjGeomId
        md.objectgeomIdEx[curObjGeomId] = objectPtr.Id
    }

    relIds := objectPtr.getReliedLaneIds()
    for _, laneId := range relIds {
        if _, ok := md.roadRelObjects[laneId.roadId]; !ok {
            md.roadRelObjects[laneId.roadId] = make(map[objectpkid]struct{})
        }
        md.roadRelObjects[laneId.roadId][objectPtr.Id] = struct{}{}
    }

    if md.coordType == COORD_ENU {
        objectPtr.transfer2ENU(curCenter)
    }
    return true
}

func (md *MapData) insertObjects(objects txObjects) bool {
    fmt.Println("MapData inserts objects:", len(objects))
    r := true
    for _, objectPtr := range objects {
        r = r && md.insertObject(objectPtr)
        fmt.Println("insert object =", objectPtr.Id)
    }
    return r
}

func (md *MapData) insertJunction(juncPtr *txJunction) bool {
    if juncPtr == nil {
        return false
    }

    md.juncDataMutex.Lock()
    defer md.juncDataMutex.Unlock()
    if _, ok := md.juncDatas[juncPtr.Id]; ok {
        return false
    }

    md.juncDatas[juncPtr.Id] = juncPtr
    return true
}

func (md *MapData) updateRoad(roadPtr *txRoad) bool {
    if roadPtr == nil || len(roadPtr.Sections) == 0 {
        return false
    }
    if !md.removeRoad(roadPtr.Id, false) {
        return false
    }
    if !md.insertRoad(roadPtr) {
        return false
    }
    return true
}

func (md *MapData) updateLaneLink(lanelinkPtr *txLaneLink) bool {
    if lanelinkPtr == nil || lanelinkPtr.getGeometry() == nil {
        return false
    }
    if !md.removeLaneLink(lanelinkPtr.Id) {
        return false
    }
    if !md.insertLaneLink(lanelinkPtr) {
        return false
    }
    return true
}

func (md *MapData) getRoadById(roadId roadpkid, roadPtr *txRoad) bool {
    if roadId == ROAD_PKID_INVALID {
        fmt.Println("txMap::MapData::getRoadById: ROAD_PKID_INVALID")
        return false
    }
    md.roaddataMutex.Lock()
    defer md.roaddataMutex.Unlock()
    if _, ok := md.roadDatas[roadId]; !ok {
        fmt.Println("txMap::MapData::getRoadById: roadDatas cannot find:", roadId)
        fmt.Println("txMap::MapData::getRoadById: roadDatas.size()=", len(md.roadDatas))
        roadPtr = nil
    } else {
        roadPtr = md.roadDatas[roadId]
    }
    return roadPtr != nil
}

func (md *MapData) getRoads(roads *txRoads) bool {
    roads.Clear()
    md.roaddataMutex.Lock()
    defer md.roaddataMutex.Unlock()
    for _, road := range md.roadDatas {
        roads.Append(road)
    }
    return len(*roads) > 0
}

func (md *MapData) getLanes(lanes *txLanes) bool {
    lanes.Clear()
    md.roaddataMutex.Lock()
    defer md.roaddataMutex.Unlock()
    for _, road := range md.roadDatas {
        for _, section := range road.Sections {
            for _, lane := range section.Lanes {
                lanes.Append(lane)
            }
        }
    }
    return len(*lanes) > 0
}

func (md *MapData) getBoundaries(boundaries *txLaneBoundaries) bool {
    boundaries.Clear()
    ids := make(map[laneboundarypkid]struct{})
    md.roaddataMutex.Lock()
    defer md.roaddataMutex.Unlock()
    for _, road := range md.roadDatas {
        for _, section := range road.Sections {
            for _, lane := range section.Lanes {
                if _, ok := ids[lane.LeftBoundaryId]; !ok {
                    ids[lane.LeftBoundaryId] = struct{}{}
                    boundaries.Append(lane.LeftBoundary)
                }
                if _, ok := ids[lane.RightBoundaryId]; !ok {
                    ids[lane.RightBoundaryId] = struct{}{}
                    boundaries.Append(lane.RightBoundary)
                }
            }
        }
    }
    return len(*boundaries) > 0
}

func (md *MapData) getLaneLinks(links *txLaneLinks) bool {
    links.Clear()
    md.linkdataMutex.Lock()
    defer md.linkdataMutex.Unlock()
    for _, link := range md.linkDatas {
        links.Append(link)
    }
    return len(*links) > 0
}

func (md *MapData) getObjects(objects *txObjects) bool {
    objects.Clear()
    md.objdataMutex.Lock()
    defer md.objdataMutex.Unlock()
    for _, object := range md.objectDatas {
        objects.Append(object)
    }
    return len(*objects) > 0
}

func (md *MapData) getObject(objId objectpkid, objPtr *txObject) bool {
    md.objdataMutex.Lock()
    defer md.objdataMutex.Unlock()
    if _, ok := md.objectDatas[objId]; !ok {
        return false
    }
    objPtr = md.objectDatas[objId]
    return true
}

func (md *MapData) getObjectsByType(type_ OBJECT_TYPE, objects *txObjects) bool {
    objects.Clear()
    md.objdataMutex.Lock()
    defer md.objdataMutex.Unlock()
    for _, object := range md.objectDatas {
        if object.ObjectType == type_ {
            objects.Append(object)
        }
    }
    return len(*objects) > 0
}

func (md *MapData) getObjectsByRelIds(relIds []txLaneId, objects *txObjects) bool {
    objects.Clear()
    md.objdataMutex.Lock()
    defer md.objdataMutex.Unlock()
    objIds := make(map[objectpkid]struct{})
    for _, laneId := range relIds {
        if _, ok := md.roadRelObjects[laneId.RoadId]; ok {
            for id := range md.roadRelObjects[laneId.RoadId] {
                objRelIds := md.objectDatas[id].getReliedLaneIds()
                for _, objRelId := range objRelIds {
                    if md.laneIdMatching(laneId, objRelId) {
                        if _, ok := objIds[id]; !ok {
                            objIds[id] = struct{}{}
                            objects.Append(md.objectDatas[id])
                        }
                        break
                    }
                }
            }
        }
    }
    return len(*objects) > 0
}
func (md *MapData) getJunctions(junctions []txPoint) bool {
    md.roaddataMutex.Lock()
    defer md.roaddataMutex.Unlock()

    junctions = junctions[:0]
    for _, juncData := range md.juncDatas {
        junctions = append(junctions, juncData)
    }
    return len(junctions) > 0
}

func (md *MapData) nearestLane(loc txPoint, radius, yaw float64, lanePtr *txLanePtr) bool {
    md.centerMutex.Lock()
    defer md.centerMutex.Unlock()

    searchLoc := loc
    if md.coordType == COORD_ENU {
        searchLoc = coord_trans_api.Enu2LonLat(searchLoc.x, searchLoc.y, searchLoc.z, md.centerLL.x, md.centerLL.y, md.centerLL.z)
    }
    offset := radius
    if md.coordType == COORD_WGS84 {
        x, y, z := radius, radius, 0
        offset = math.Max(math.Abs(x-searchLoc.x), math.Abs(y-searchLoc.y))
    }
    envelope := txEnvelope{searchLoc.x - offset, searchLoc.y - offset, searchLoc.x + offset, searchLoc.y + offset}

    var curveIndexes []pkid_t
    var pointRanges []struct{ start, end size_t }
    if md.spatialSearch(LANE_SP, envelope, &curveIndexes, &pointRanges) {
        md.roaddataMutex.Lock()
        defer md.roaddataMutex.Unlock()

        *lanePtr = nil
        minDis := math.MaxFloat64
        for _, geomId := range curveIndexes {
            curLaneId := md.roadgeomIdEx[geomId]
            curLanePtr := md.getLaneUnsafe(curLaneId)
            if curLanePtr != nil {
                curvePtr := curLanePtr.geometry.(*txLineCurve)
                curDis := point2CurveDis(loc, yaw, curvePtr, pointRanges[i], loc.z > VALID_Z)
                if minDis > curDis {
                    minDis = curDis
                    *lanePtr = curLanePtr
                }
            }
        }
        return *lanePtr != nil
    } else {
        return false
    }
}

func (md *MapData) nearestLane(loc txPoint, radius float64, lanePtr *txLanePtr) bool {
    md.centerMutex.Lock()
    defer md.centerMutex.Unlock()

    searchLoc := loc
    if md.coordType == COORD_ENU {
        searchLoc = coord_trans_api.Enu2LonLat(searchLoc.x, searchLoc.y, searchLoc.z, md.centerLL.x, md.centerLL.y, md.centerLL.z)
    }
    offset := radius
    offset = math.Max(math.Abs(x-searchLoc.x), math.Abs(y-searchLoc.y))
    envelope := txEnvelope{searchLoc.x - offset, searchLoc.y - offset, searchLoc.x + offset, searchLoc.y + offset}

    var curveIndexes []pkid_t
    var pointRanges []struct{ start, end size_t }
    if md.spatialSearch(LANE_SP, envelope, &curveIndexes, &pointRanges) {
        md.roaddataMutex.Lock()
        defer md.roaddataMutex.Unlock()

        *lanePtr = nil
        minDis := math.MaxFloat64
        for _, geomId := range curveIndexes {
            curLaneId := md.roadgeomIdEx[geomId]
            curLanePtr := md.getLaneUnsafe(curLaneId)
            if curLanePtr != nil {
                curvePtr := curLanePtr.geometry.(*txLineCurve)
                curDis := point2CurveDis(searchLoc, curvePtr, pointRanges[i], loc.z > VALID_Z)
                disToLaneStart := map_util.DistanceBetweenPoints(hadmap.Point3d{curvePtr.start.x, curvePtr.start.y, 0}, hadmap.Point3d{searchLoc.x, searchLoc.y, 0}, true)
                if curDis < 0.001 && disToLaneStart < 0.001 {
                    minDis = curDis
                    *lanePtr = curLanePtr
                    break
                }
                if minDis > curDis && curDis >= 0.0 {
                    minDis = curDis
                    *lanePtr = curLanePtr
                }
            }
        }
        return *lanePtr != nil
    } else {
        return false
    }
}

func (md *MapData) nearestLaneLink(loc txPoint, radius float64, linkPtr *txLaneLinkPtr) bool {
    md.centerMutex.Lock()
    defer md.centerMutex.Unlock()

    searchLoc := loc
    if md.coordType == COORD_ENU {
        searchLoc = coord_trans_api.Enu2LonLat(searchLoc.x, searchLoc.y, searchLoc.z, md.centerLL.x, md.centerLL.y, md.centerLL.z)
    }
    offset := radius
    if md.coordType == COORD_WGS84 {
        x, y, z := radius, radius, 0
        offset = math.Max(math.Abs(x-searchLoc.x), math.Abs(y-searchLoc.y))
    }
    envelope := txEnvelope{searchLoc.x - offset, searchLoc.y - offset, searchLoc.x + offset, searchLoc.y + offset}

    var curveIndexes []pkid_t
    var pointRanges []struct{ start, end size_t }
    if md.spatialSearch(LINK_SP, envelope, &curveIndexes, &pointRanges) {
        md.roaddataMutex.Lock()
        defer md.roaddataMutex.Unlock()

        *linkPtr = nil
        minDis := math.MaxFloat64
        for _, geomId := range curveIndexes {
            curLinkId := md.linkgeomIdEx[geomId]
            curLinkPtr := md.specLinks([]lanelinkpkid{curLinkId})
            if curLinkPtr != nil {
                curvePtr := curLinkPtr.geometry.(*txLineCurve)
                curDis := point2CurveDis(loc, curvePtr, pointRanges[i], loc.z > VALID_Z)
                disToLaneStart := map_util.DistanceBetweenPoints(hadmap.Point3d{curvePtr.start.x, curvePtr.start.y, 0}, hadmap.Point3d{searchLoc.x, searchLoc.y, 0}, true)
                if curDis < 0.001 && disToLaneStart < 0.001 {
                    minDis = curDis
                    *linkPtr = curLinkPtr
                    break
                }
                if minDis > curDis && curDis >= 0.0 {
                    minDis = curDis
                    *linkPtr = curLinkPtr
                }
            }
        }
        return *linkPtr != nil
    } else {
        return false
    }
}

func (md *MapData) nextLanes(curLaneId txLaneId, lanes *txLanes) bool {
    if curLaneId.roadId == ROAD_PKID_INVALID || curLaneId.sectionId == SECT_PKID_INVALID || curLaneId.laneId == LANE_PKID_INVALID {
        return false
    } else {
        *lanes = (*lanes)[:0]
        md.roaddataMutex.Lock()
        defer md.roaddataMutex.Unlock()

        curLanePtr := md.getLaneUnsafe(curLaneId)
        if curLanePtr == nil {
            return false
        }
        curRoadPtr := md.roadDatas[curLaneId.roadId]
        curSections := curRoadPtr.sections
        var nextSecPtr *txSectionPtr
        for i, section := range curSections {
            if section.id == curLaneId.sectionId {
                if i+1 < len(curSections) {
                    nextSecPtr = curSections[i+1]
                    break
                }
            }
        }
        if nextSecPtr != nil {
            nextLanes := nextSecPtr.lanes
            for _, nextLanePtr := range nextLanes {
                if nextLanePtr.geometry == nil || len(nextLanePtr.geometry) == 0 {
                    continue
                }
                if coordDis2D(curLanePtr.geometry.getEnd(), nextLanePtr.geometry.getStart()) < 0.2 {
                    *lanes = append(*lanes, nextLanePtr)
                }
            }
        } else {
            md.linkdataMutex.Lock()
            defer md.linkdataMutex.Unlock()

            if _, ok := md.fromLinkDatas[curLaneId.roadId]; ok {
                links := md.fromLinkDatas[curLaneId.roadId]
                for linkId := range links {
                    fromId := md.linkDatas[linkId].fromTxLaneId()
                    if laneIdMatching(curLaneId, fromId) {
                        nextLanePtr := md.getLaneUnsafe(md.linkDatas[linkId].toTxLaneId())
                        if nextLanePtr != nil {
                            *lanes = append(*lanes, nextLanePtr)
                        }
                    }
                }
            }
        }
        return len(*lanes) > 0
    }
}
func (m *MapData) preLanes(curLaneId txLaneId, lanes *txLanes) bool {
    if curLaneId.roadId == ROAD_PKID_INVALID || curLaneId.sectionId == SECT_PKID_INVALID || curLaneId.laneId == LANE_PKID_INVALID {
        return false
    } else {
        lanes.clear()
        m.mutexlock(&m.roaddataMutex)
        curLanePtr := m.getLaneUnsafe(curLaneId)
        if curLanePtr != nil {
            if _, ok := m.roadDatas[curLaneId.roadId]; !ok {
                txlog.Debug("txMap::MapData::preLanes: cannot find road.")
            }
            curRoadPtr := m.roadDatas[curLaneId.roadId]
            curSections := curRoadPtr.getSections()
            preSecPtr := nil
            for i := 0; i < len(curSections); i++ {
                if curSections[i].getId() == curLaneId.sectionId {
                    if i > 0 {
                        preSecPtr = curSections[i-1]
                        break
                    }
                }
            }
            if preSecPtr != nil {
                preLanes := preSecPtr.getLanes()
                for _, preLanePtr := range preLanes {
                    if preLanePtr.getGeometry() == nil || len(preLanePtr.getGeometry()) == 0 {
                        continue
                    }
                    if coordDis2D(curLanePtr.getGeometry().getStart(), preLanePtr.getGeometry().getEnd()) < 0.2 {
                        lanes.push_back(preLanePtr)
                    }
                }
            } else {
                m.mutexlock(&m.linkdataMutex)
                if _, ok := m.toLinkDatas[curLaneId.roadId]; ok {
                    links := m.toLinkDatas[curLaneId.roadId]
                    for _, linkId := range links {
                        toId := linkDatas[linkId].toTxLaneId()
                        if laneIdMatching(curLaneId, toId) {
                            preLanePtr := m.getLaneUnsafe(linkDatas[linkId].fromTxLaneId())
                            if preLanePtr != nil {
                                lanes.push_back(preLanePtr)
                            }
                        }
                    }
                }
            }
            return len(lanes) > 0
        } else {
            return false
        }
    }
}

func (m *MapData) searchLaneLinks(envelope PointVec, links *txLaneLinks) bool {
    if envelope[0].x > envelope[1].x || envelope[0].y > envelope[1].y {
        return false
    }

    e := txEnvelope{bMin: envelope[0], bMax: envelope[1]}
    m.mutexlock(&m.centerMutex)
    if m.coordType == COORD_ENU {
        z := 0.0
        coord_trans_api.Enu2LonLat(e.bMin.x, e.bMin.y, z, m.centerLL.x, m.centerLL.y, m.centerLL.z)
        coord_trans_api.Enu2LonLat(e.bMax.x, e.bMax.y, z, m.centerLL.x, m.centerLL.y, m.centerLL.z)
    }
    curveIndexes := m.spatialSearch(LINK_SP, e)
    if len(curveIndexes) > 0 {
        links.clear()
        m.mutexlock(&m.roaddataMutex)
        link_ids := make([]lanelinkpkid, 0)
        for _, geomId := range curveIndexes {
            curLinkId := m.linkgeomIdEx.getGeom2Data(geomId)
            link_ids = append(link_ids, curLinkId)
        }
        flag := m.specLinks(link_ids, links)
        return len(links) > 0
    } else {
        return false
    }
}

func (m *MapData) searchLanes(envelope PointVec, lanes *txLanes) bool {
    if envelope[0].x > envelope[1].x || envelope[0].y > envelope[1].y {
        return false
    }

    e := txEnvelope{bMin: envelope[0], bMax: envelope[1]}
    m.mutexlock(&m.centerMutex)
    if m.coordType == COORD_ENU {
        z := 0.0
        coord_trans_api.Enu2LonLat(e.bMin.x, e.bMin.y, z, m.centerLL.x, m.centerLL.y, m.centerLL.z)
        coord_trans_api.Enu2LonLat(e.bMax.x, e.bMax.y, z, m.centerLL.x, m.centerLL.y, m.centerLL.z)
    }
    curveIndexes := m.spatialSearch(LANE_SP, e)
    if len(curveIndexes) > 0 {
        lanes.clear()
        m.mutexlock(&m.roaddataMutex)
        for _, geomId := range curveIndexes {
            curLaneId := m.roadgeomIdEx.getGeom2Data(geomId)
            curLanePtr := m.getLaneUnsafe(curLaneId)
            if curLanePtr != nil {
                lanes.push_back(curLanePtr)
            }
        }
        return len(lanes) > 0
    } else {
        return false
    }
}

func (m *MapData) searchBoundaries(envelope PointVec, boundaries *txLaneBoundaries) bool {
    lanes := txLanes{}
    ids := make(map[laneboundarypkid]bool)
    if m.searchLanes(envelope, &lanes) {
        for _, lanePtr := range lanes {
            if _, ok := ids[lanePtr.getLeftBoundaryId()]; !ok {
                ids[lanePtr.getLeftBoundaryId()] = true
                boundaries.push_back(lanePtr.getLeftBoundary())
            }
            if _, ok := ids[lanePtr.getRightBoundaryId()]; !ok {
                ids[lanePtr.getRightBoundaryId()] = true
                boundaries.push_back(lanePtr.getRightBoundary())
            }
        }
        return len(boundaries) > 0
    }
    return false
}

func (m *MapData) searchRoads(envelope PointVec, roads *txRoads) bool {
    lanes := txLanes{}
    ids := make(map[roadpkid]bool)
    if m.searchLanes(envelope, &lanes) {
        for _, curLanePtr := range lanes {
            ids[curLanePtr.getRoadId()] = true
        }
        m.mutexlock(&m.roaddataMutex)
        for _, roadId := range ids {
            if roadPtr, ok := m.roadDatas[roadId]; ok {
                roads.push_back(roadPtr)
            }
        }
        return len(roads) > 0
    }
    return false
}

func (m *MapData) specBoundaries(specIds []laneboundarypkid, boundaries *txLaneBoundaries) bool {
    boundaries.clear()
    ids := make(map[laneboundarypkid]int)
    for _, id := range specIds {
        ids[id] = 0
    }
    m.mutexlock(&m.roaddataMutex)
    for _, roadPtr := range m.roadDatas {
        curSections := roadPtr.getSections()
        for _, secPtr := range curSections {
            curLanes := secPtr.getLanes()
            for _, curLanePtr := range curLanes {
                if _, ok := ids[curLanePtr.getLeftBoundaryId()]; ok {
                    if ids[curLanePtr.getLeftBoundaryId()] == 0 {
                        ids[curLanePtr.getLeftBoundaryId()] = 1
                        boundaries.push_back(curLanePtr.getLeftBoundary())
                    }
                }
                if _, ok := ids[curLanePtr.getRightBoundaryId()]; ok {
                    if ids[curLanePtr.getRightBoundaryId()] == 0 {
                        ids[curLanePtr.getRightBoundaryId()] = 1
                        boundaries.push_back(curLanePtr.getRightBoundary())
                    }
                }
            }
        }
    }
    for _, link := range m.linkDatas {
        for _, lk := range link.getLeftBoundaries() {
            if lk != nil && _, ok := ids[lk.getId()]; ok {
                if ids[lk.getId()] == 0 {
                ids[lk.getId()] = 1
                boundaries.push_back(lk)
            }
            }
        }
        for _, lk := range link.getRightBoundaries() {
            if lk != nil && _, ok := ids[lk.getId()]; ok {
                if ids[lk.getId()] == 0 {
                ids[lk.getId()] = 1
                boundaries.push_back(lk)
            }
            }
        }
    }
    return len(boundaries) > 0
}

func (m *MapData) specLanes(specLaneId txLaneId, lanes *txLanes) bool {
    lanes.clear()
    if specLaneId.roadId == ROAD_PKID_INVALID {
        return false
    }
    m.mutexlock(&m.roaddataMutex)
    roadPtr, ok := m.roadDatas[specLaneId.roadId]
    if !ok {
        return false
    }
    sections := roadPtr.getSections()
    if specLaneId.sectionId == SECT_PKID_INVALID {
        for _, secPtr := range sections {
            curLanes := secPtr.getLanes()
            lanes.insert(lanes.end(), curLanes.begin(), curLanes.end())
        }
    } else {
        for _, secPtr := range sections {
            if secPtr.getId() == specLaneId.sectionId {
                curLanes := secPtr.getLanes()
                if specLaneId.laneId == LANE_PKID_INVALID {
                    lanes.assign(curLanes.begin(), curLanes.end())
                } else {
                    for _, lanePtr := range curLanes {
                        if lanePtr.getId() == specLaneId.laneId {
                            lanes.push_back(lanePtr)
                            break
                        }
                    }
                }
            }
        }
    }
    return len(lanes) > 0
}
func (m *MapData) mutexlock(mutex *sync.Mutex) {
    mutex.Lock()
    defer mutex.Unlock()
}
func (md *MapData) specLinks(fromRoadId, toRoadId roadpkid, links *txLaneLinks) bool {
    if fromRoadId == ROAD_PKID_INVALID && toRoadId == ROAD_PKID_INVALID {
        return false
    }

    *links = nil
    md.mutex.Lock()
    defer md.mutex.Unlock()
    if fromRoadId != ROAD_PKID_INVALID {
        if fromLinks, ok := md.fromLinkDatas[fromRoadId]; ok {
            for _, linkId := range fromLinks {
                curLinkPtr := md.linkDatas[linkId]
                if toRoadId == ROAD_PKID_INVALID || curLinkPtr.toRoadId() == toRoadId {
                    *links = append(*links, curLinkPtr)
                }
            }
        }
    } else {
        if toLinks, ok := md.toLinkDatas[toRoadId]; ok {
            for _, linkId := range toLinks {
                *links = append(*links, md.linkDatas[linkId])
            }
        }
    }
    return len(*links) > 0
}

func (md *MapData) specLinks(fromLaneId, toLaneId txLaneId, links *txLaneLinks) bool {
    if fromLaneId.roadId == ROAD_PKID_INVALID && toLaneId.roadId == ROAD_PKID_INVALID {
        return false
    }

    *links = nil
    md.mutex.Lock()
    defer md.mutex.Unlock()
    if fromLaneId.roadId != ROAD_PKID_INVALID {
        if fromLinks, ok := md.fromLinkDatas[fromLaneId.roadId]; ok {
            if toLaneId.roadId == ROAD_PKID_INVALID {
                for _, linkId := range fromLinks {
                    curLinkPtr := md.linkDatas[linkId]
                    if fromLaneId.sectionId == curLinkPtr.fromSectionId() && fromLaneId.laneId == curLinkPtr.fromLaneId() {
                        *links = append(*links, curLinkPtr)
                    }
                }
            } else {
                for _, linkId := range fromLinks {
                    curLinkPtr := md.linkDatas[linkId]
                    if fromLaneId.sectionId == curLinkPtr.fromSectionId() && fromLaneId.laneId == curLinkPtr.fromLaneId() &&
                        toLaneId.roadId == curLinkPtr.toRoadId() && toLaneId.sectionId == curLinkPtr.toSectionId() &&
                        toLaneId.laneId == curLinkPtr.toLaneId() {
                        *links = append(*links, curLinkPtr)
                    }
                }
            }
        }
    } else {
        if toLinks, ok := md.toLinkDatas[toLaneId.roadId]; ok {
            for _, linkId := range toLinks {
                curLinkPtr := md.linkDatas[linkId]
                if toLaneId.sectionId == curLinkPtr.toSectionId() && toLaneId.laneId == curLinkPtr.toLaneId() {
                    *links = append(*links, curLinkPtr)
                }
            }
        }
    }
    return len(*links) > 0
}

func (md *MapData) specLinks(linkIds []lanelinkpkid, links *txLaneLinks) bool {
    *links = nil
    if len(linkIds) == 0 {
        for _, linkPtr := range md.linkDatas {
            *links = append(*links, linkPtr)
        }
    } else {
        for _, id := range linkIds {
            if linkPtr, ok := md.linkDatas[id]; ok {
                *links = append(*links, linkPtr)
            }
        }
    }
    return len(*links) > 0
}

func (md *MapData) specRoadLink(roadId roadpkid, link *txLaneLinkPtr) bool {
    for _, linkPtr := range md.linkDatas {
        if linkPtr.getOdrRoadId() == roadId {
            *link = linkPtr
            return true
        }
    }
    return false
}

func (md *MapData) specRoadLinks(roadId roadpkid, links *txLaneLinks) bool {
    for _, linkPtr := range md.linkDatas {
        if linkPtr.getOdrRoadId() == roadId {
            *links = append(*links, linkPtr)
        }
    }
    return len(*links) > 0
}

func (md *MapData) searchObjects(envelope PointVec, types map[OBJECT_TYPE]bool, relLaneId txLaneId, objects *txObjects) bool {
    if envelope[0].x > envelope[1].x || envelope[0].y > envelope[1].y {
        return false
    }

    e := txEnvelope{bMin: [2]float64{envelope[0].x, envelope[0].y}, bMax: [2]float64{envelope[1].x, envelope[1].y}}
    md.mutex.Lock()
    defer md.mutex.Unlock()
    if md.coordType == COORD_ENU {
        z := 0.0
        coord_trans_api.Enu2LonLat(e.bMin[0], e.bMin[1], z, md.centerLL.x, md.centerLL.y, md.centerLL.z)
        coord_trans_api.Enu2LonLat(e.bMax[0], e.bMax[1], z, md.centerLL.x, md.centerLL.y, md.centerLL.z)
    }

    curveIndexes := make([]pkid_t, 0)
    if md.spatialSearch(OBJ_SP, e, &curveIndexes) {
        *objects = nil
        for _, geomId := range curveIndexes {
            objId := objectgeomIdEx.GetGeom2Data(geomId)
            if objPtr, ok := md.objectDatas[objId]; ok {
                if len(types) > 0 && !types[objPtr.getObjectType()] {
                    continue
                }
                objRelIds := make([]txLaneId, 0)
                objPtr.getReliedLaneIds(&objRelIds)
                if len(objRelIds) == 0 {
                    if md.laneIdMatching(relLaneId, txLaneId{roadId: ROAD_PKID_INVALID, sectionId: SECT_PKID_INVALID, laneId: LANE_PKID_INVALID}) {
                        *objects = append(*objects, objPtr)
                    }
                } else {
                    for _, objRelId := range objRelIds {
                        if md.laneIdMatching(relLaneId, objRelId) {
                            *objects = append(*objects, objPtr)
                            break
                        }
                    }
                }
            }
        }
        return len(*objects) > 0
    } else {
        return false
    }
}

func (md *MapData) searchObjects(envelope PointVec, types map[OBJECT_SUB_TYPE]bool, relLaneId txLaneId, objects *txObjects) bool {
    if envelope[0].x > envelope[1].x || envelope[0].y > envelope[1].y {
        return false
    }

    e := txEnvelope{bMin: [2]float64{envelope[0].x, envelope[0].y}, bMax: [2]float64{envelope[1].x, envelope[1].y}}
    md.mutex.Lock()
    defer md.mutex.Unlock()
    if md.coordType == COORD_ENU {
        z := 0.0
        coord_trans_api.Enu2LonLat(e.bMin[0], e.bMin[1], z, md.centerLL.x, md.centerLL.y, md.centerLL.z)
        coord_trans_api.Enu2LonLat(e.bMax[0], e.bMax[1], z, md.centerLL.x, md.centerLL.y, md.centerLL.z)
    }

    curveIndexes := make([]pkid_t, 0)
    if md.spatialSearch(OBJ_SP, e, &curveIndexes) {
        *objects = nil
        for _, geomId := range curveIndexes {
            objId := objectgeomIdEx.GetGeom2Data(geomId)
            if objPtr, ok := md.objectDatas[objId]; ok {
                if len(types) > 0 && !types[objPtr.getObjectSubType()] {
                    continue
                }
                objRelIds := make([]txLaneId, 0)
                objPtr.getReliedLaneIds(&objRelIds)
                if len(objRelIds) == 0 {
                    if md.laneIdMatching(relLaneId, txLaneId{roadId: ROAD_PKID_INVALID, sectionId: SECT_PKID_INVALID, laneId: LANE_PKID_INVALID}) {
                        *objects = append(*objects, objPtr)
                    }
                } else {
                    for _, objRelId := range objRelIds {
                        if md.laneIdMatching(relLaneId, objRelId) {
                            *objects = append(*objects, objPtr)
                            break
                        }
                    }
                }
            }
        }
        return len(*objects) > 0
    } else {
        return false
    }
}

func (md *MapData) specJunction(jId junctionpkid, juncPtr *txJunctionPtr) bool {
    md.mutex.Lock()
    defer md.mutex.Unlock()
    if _, ok := md.juncDatas[jId]; !ok {
        return false
    }
    *juncPtr = md.juncDatas[jId]
    return true
}

func (md *MapData) updateCenter(lonlatele txPoint) bool {
    md.mutex.Lock()
    defer md.mutex.Unlock()
    oldEnuC := md.centerLL
    md.lastCenterLL = md.centerLL
    md.centerLL = lonlatele
    md.centerId += 1
    md.updateProj()

    if md.coordType == COORD_ENU {
        z := 0.0
        coord_trans_api.Enu2LonLat(oldEnuC.x, oldEnuC.y, z, md.centerLL.x, md.centerLL.y, md.centerLL.z)
        coord_trans_api.Enu2LonLat(lonlatele.x, lonlatele.y, z, md.centerLL.x, md.centerLL.y, md.centerLL.z)

        md.mutex.Lock()
        defer md.mutex.Unlock()
        for _, roadData := range md.roadDatas {
            roadData.transfer(oldEnuC, md.centerLL)
            for _, section := range roadData.sections {
                for _, lane := range section.lanes {
                    lane.transfer(oldEnuC, md.centerLL)
                    if lane.leftBoundaryId != BOUN_PKID_INVALID {
                        lane.leftBoundary.transfer(oldEnuC, md.centerLL)
                    }
                    if lane.rightBoundaryId != BOUN_PKID_INVALID {
                        lane.rightBoundary.transfer(oldEnuC, md.centerLL)
                    }
                }
            }
        }

        md.mutex.Lock()
        defer md.mutex.Unlock()
        for _, objPtr := range md.objectDatas {
            objPtr.transfer(oldEnuC, md.centerLL)
        }
        return true
    } else {
        return false
    }
}
func (m *MapData) priorityCmp(curPtr, cmpPtr *txJunctionRoadPtr) PRIORITY_TYPE {
    if curPtr == nil || cmpPtr == nil {
        return PRIORITY_NONE
    } else if curPtr.juncId != cmpPtr.juncId {
        return PRIORITY_NONE
    } else {
        m.juncDataMutex.Lock()
        defer m.juncDataMutex.Unlock()
        if _, ok := m.juncDatas[curPtr.juncId]; !ok {
            panic(errors.New("Priority cmp error, can not find specified junction"))
        }
        juncPtr := m.juncDatas[curPtr.juncId]

        if !juncPtr.isInteraction(curPtr.id, cmpPtr.id) {
            return PRIORITY_NONE
        }

        r := juncPtr.priorityCmp(curPtr.id, cmpPtr.id)
        if r == 0 {
            return PRIORITY_SAME
        } else if r > 0 {
            return PRIORITY_HIGH
        } else {
            return PRIORITY_LOW
        }
    }
}

func (m *MapData) removeRoad(roadId ROAD_PKID, related bool) bool {
    if roadId == ROAD_PKID_INVALID {
        return false
    }

    var curLaneGeomIds []pkid_t
    {
        m.roaddataMutex.Lock()
        defer m.roaddataMutex.Unlock()
        if _, ok := m.roadDatas[int(roadId)]; !ok {
            return false
        }
        m.roadDatas[int(roadId)].getData2Geom(int(roadId), &curLaneGeomIds)
    }

    // remove related objects
    var relatedObjs []objectpkid
    {
        m.roaddataMutex.Lock()
        defer m.roaddataMutex.Unlock()
        if objs, ok := m.roadRelObjects[int(roadId)]; ok {
            relatedObjs = objs
            delete(m.roadRelObjects, int(roadId))
        }
    }
    m.removeObjects(relatedObjs)

    // remove related lanelinks
    if false {
        m.removeLinks(roadId, ROAD_PKID_INVALID)
        m.removeLinks(ROAD_PKID_INVALID, roadId)
    }
    // remove lane geom from rtree
    for _, geomId := range curLaneGeomIds {
        m.spIndex.remove(LANE_SP, geomId)
    }

    // remove road info
    m.roaddataMutex.Lock()
    defer m.roaddataMutex.Unlock()
    m.roadDatas[int(roadId)].removeData2Geom(int(roadId))
    for _, geomId := range curLaneGeomIds {
        m.roadDatas[int(roadId)].removeGeom2Data(geomId)
    }

    delete(m.roadDatas, int(roadId))
    // txlog::debug("txMap::MapData::removeRoad,roadDatas.size()=" + std::to_string(roadDatas.size()));
    return true
}

func (m *MapData) removeRoads(roadIds []ROAD_PKID) bool {
    r := true
    for _, id := range roadIds {
        r = r && m.removeRoad(id, true)
    }
    return r
}

func (m *MapData) removeLaneLink(laneLinkId lanelinkpkid) bool {
    if _, ok := m.linkDatas[int(laneLinkId)]; !ok {
        return false
    }
    m.linkdataMutex.Lock()
    defer m.linkdataMutex.Unlock()
    var curGeomId pkid_t
    m.linkgeomIdEx.getData2Geom(int(laneLinkId), &curGeomId)
    // remove link geom from rtree
    m.spIndex.remove(LINK_SP, curGeomId)

    // remove link index
    ptr := m.linkDatas[int(laneLinkId)]
    if ptr == nil {
        return false
    }
    fid := ptr.fromRoadId()
    tid := ptr.toRoadId()

    // remove toroad
    if _, ok := m.toLinkDatas[tid]; !ok {
        return false
    }
    delete(m.toLinkDatas[tid], int(laneLinkId))
    // remove tolanelink
    if _, ok := m.fromLinkDatas[fid]; !ok {
        return false
    }
    delete(m.fromLinkDatas[fid], int(laneLinkId))
    // remove geom info
    m.linkgeomIdEx.removeData2Geom(int(laneLinkId))
    m.linkgeomIdEx.removeGeom2Data(curGeomId)
    // remove link ins
    delete(m.linkDatas, int(laneLinkId))
    return true
}

// linkdataMutex only
func (m *MapData) removeLinks(fromRoadId, toRoadId ROAD_PKID) bool {
    if fromRoadId == ROAD_PKID_INVALID && toRoadId == ROAD_PKID_INVALID {
        // remove all links
        m.linkdataMutex.Lock()
        defer m.linkdataMutex.Unlock()
        m.linkDatas = make(map[int]*txLaneLinkPtr)
        m.fromLinkDatas = make(map[int]map[int]lanelinkpkid)
        m.toLinkDatas = make(map[int]map[int]lanelinkpkid)
        m.linkgeomIdEx.clear()
        m.spIndex.removeAll(LINK_SP)
        return true
    } else {
        var removedLinkIds []lanelinkpkid
        var removedLinkGeomIds []pkid_t
        {
            m.linkdataMutex.Lock()
            defer m.linkdataMutex.Unlock()
            if fromRoadId != ROAD_PKID_INVALID {
                if _, ok := m.fromLinkDatas[int(fromRoadId)]; !ok {
                    return false
                }
                fromIds := m.fromLinkDatas[int(fromRoadId)]
                if toRoadId == ROAD_PKID_INVALID {
                    for id := range fromIds {
                        removedLinkIds = append(removedLinkIds, lanelinkpkid(id))
                    }
                } else {
                    for id, link := range fromIds {
                        if link.toRoadId() == int(toRoadId) {
                            removedLinkIds = append(removedLinkIds, lanelinkpkid(id))
                        }
                    }
                }
            } else {
                // fromRoadId == ROAD_PKID_INVALID && toRoadId != ROAD_PKID_INVALID
                if _, ok := m.toLinkDatas[int(toRoadId)]; !ok {
                    return false
                }
                toIds := m.toLinkDatas[int(toRoadId)]
                for id := range toIds {
                    removedLinkIds = append(removedLinkIds, lanelinkpkid(id))
                }
            }
            if len(removedLinkIds) == 0 {
                return false
            }
            for _, id := range removedLinkIds {
                var curGeomId pkid_t
                m.linkgeomIdEx.getData2Geom(int(id), &curGeomId)
                removedLinkGeomIds = append(removedLinkGeomIds, curGeomId)
            }
        }

        // remove link geom from rtree
        for _, geomId := range removedLinkGeomIds {
            m.spIndex.remove(LINK_SP, geomId)
        }

        m.linkdataMutex.Lock()
        defer m.linkdataMutex.Unlock()
        // remove link index
        if fromRoadId != ROAD_PKID_INVALID {
            delete(m.fromLinkDatas, int(fromRoadId))
        } else {
            for _, id := range removedLinkIds {
                delete(m.fromLinkDatas[m.linkDatas[int(id)].fromRoadId()], int(id))
            }
        }

        if toRoadId != ROAD_PKID_INVALID {
            delete(m.toLinkDatas, int(toRoadId))
        } else {
            for _, id := range removedLinkIds {
                delete(m.toLinkDatas[m.linkDatas[int(id)].toRoadId()], int(id))
            }
        }
        for i, id := range removedLinkIds {
            // remove geom info
            m.linkgeomIdEx.removeData2Geom(int(id))
            m.linkgeomIdEx.removeGeom2Data(removedLinkGeomIds[i])

            // remove link ins
            delete(m.linkDatas, int(id))
        }
        return true
    }
}

// objdataMutex only
func (m *MapData) removeObject(objectId objectpkid) bool {
    var objGeomId pkid_t
    {
        m.objdataMutex.Lock()
        defer m.objdataMutex.Unlock()
        if _, ok := m.objectDatas[int(objectId)]; !ok {
            return false
        }
        m.objectgeomIdEx.getData2Geom(int(objectId), &objGeomId)
    }

    if objGeomId != PKID_INVALID {
        // remove obj geom from rtree first
        m.spIndex.remove(OBJ_SP, objGeomId)

        // remove obj geom info
        m.objdataMutex.Lock()
        defer m.objdataMutex.Unlock()
        m.objectgeomIdEx.removeData2Geom(int(objectId))
        m.objectgeomIdEx.removeGeom2Data(objGeomId)

        // remove obj related info
        curObjPtr := m.objectDatas[int(objectId)]
        var reliedIds []txLaneId
        curObjPtr.getReliedLaneIds(reliedIds)
        for _, id := range reliedIds {
            if _, ok := m.roadRelObjects[id.roadId]; ok {
                m.roadRelObjects[id.roadId] = remove(m.roadRelObjects[id.roadId], objectId)
            }
        }

        // remove obj info
        delete(m.objectDatas, int(objectId))

        return true
    } else {
        return false
    }
}

func remove(slice []objectpkid, elem objectpkid) []objectpkid {
    for i, v := range slice {
        if v == elem {
            slice = append(slice[:i], slice[i+1:]...)
            break
        }
    }
    return slice
}

func (m *MapData) removeObjects(objectIds []objectpkid) bool {
    r := true
    for _, id := range objectIds {
        r = r && m.removeObject(id)
    }
    return r
}

func (md *MapData) removeJunction(jId junctionpkid) bool {
    md.juncDataMutex.Lock()
    defer md.juncDataMutex.Unlock()
    if _, ok := md.junctions[jId]; !ok {
        return false
    }
    delete(md.junctions, jId)
    return true
}

func NewtxMap(type_ CoordType, centerLL txPoint) *txMap {
    return &txMap{instancePtr: &MapData{type_: type_, centerLL: centerLL}}
}

func (tm *txMap) nearestLane(loc txPoint, radius float64, lanePtr *txLanePtr) bool {
    return tm.instancePtr.nearestLane(loc, radius, lanePtr)
}

func (tm *txMap) nextLanes(curLaneId txLaneId, lanes *txLanes) bool {
    return tm.instancePtr.nextLanes(curLaneId, lanes)
}

func (tm *txMap) specLanes(specLaneId txLaneId, lanes *txLanes) bool {
    return tm.instancePtr.specLanes(specLaneId, lanes)
}

func (tm *txMap) specBoundaries(ids []laneboundarypkid, boundaries *txLaneBoundaries) bool {
    return tm.instancePtr.specBoundaries(ids, boundaries)
}

func (tm *txMap) specLinks(fromRoadId roadpkid, toRoadId roadpkid, links *txLaneLinks) bool {
    return tm.instancePtr.specLinks(fromRoadId, toRoadId, links)
}

func (tm *txMap) specLinks(fromLaneId txLaneId, toLaneId txLaneId, links *txLaneLinks) bool {
    return tm.instancePtr.specLinks(fromLaneId, toLaneId, links)
}

func (tm *txMap) specLinks(link_ids []lanelinkpkid, links *txLaneLinks) bool {
    return tm.instancePtr.specLinks(link_ids, links)
}

func (tm *txMap) specRoadLink(roadid roadpkid, link *txLaneLinkPtr) bool {
    return tm.instancePtr.specRoadLink(roadid, link)
}

func (tm *txMap) specRoadLinks(roadid roadpkid, links *txLaneLinks) bool {
    return tm.instancePtr.specRoadLinks(roadid, links)
}

func (tm *txMap) specJunction(jId junctionpkid, juncPtr *txJunctionPtr) bool {
    return tm.instancePtr.specJunction(jId, juncPtr)
}

func (tm *txMap) searchLanes(envelope PointVec, lanes *txLanes) bool {
    return tm.instancePtr.searchLanes(envelope, lanes)
}

func (tm *txMap) searchBoundaries(envelope PointVec, boundaries *txLaneBoundaries) bool {
    return tm.instancePtr.searchBoundaries(envelope, boundaries)
}

func (tm *txMap) searchRoads(envelope PointVec, roads *txRoads) bool {
    return tm.instancePtr.searchRoads(envelope, roads)
}

func (tm *txMap) getRoads(roads *txRoads) bool {
    return tm.instancePtr.getRoads(roads)
}

func (tm *txMap) getLanes(lanes *txLanes) bool {
    return tm.instancePtr.getLanes(lanes)
}

func (tm *txMap) getBoundaries(boundaries *txLaneBoundaries) bool {
    return tm.instancePtr.getBoundaries(boundaries)
}

func (tm *txMap) getLaneLinks(links *txLaneLinks) bool {
    return tm.instancePtr.getLaneLinks(links)
}

func (tm *txMap) getObjects(objects *txObjects) bool {
    return tm.instancePtr.getObjects(objects)
}

func (tm *txMap) getObjectsByType(type_ OBJECT_TYPE, objects *txObjects) bool {
    return tm.instancePtr.getObjects(type_, objects)
}

func (tm *txMap) searchObjectsByEnvelope(envelope PointVec, types map[OBJECT_TYPE]bool, relLaneId txLaneId, objects *txObjects) bool {
    return tm.instancePtr.searchObjects(envelope, types, relLaneId, objects)
}

func (tm *txMap) searchObjectsBySubType(envelope PointVec, types map[OBJECT_SUB_TYPE]bool, relLaneId txLaneId, objects *txObjects) bool {
    return tm.instancePtr.searchObjects(envelope, types, relLaneId, objects)
}

func (tm *txMap) insertRoad(roadPtr *txRoadPtr) bool {
    return tm.instancePtr.insertRoad(roadPtr)
}

func (tm *txMap) insertRoads(roads txRoads) bool {
    return tm.instancePtr.insertRoads(roads)
}

func (tm *txMap) insertLaneLink(linkPtr *txLaneLinkPtr) bool {
    return tm.instancePtr.insertLaneLink(linkPtr)
}

func (tm *txMap) insertLaneLinks(links txLaneLinks) bool {
    return tm.instancePtr.insertLaneLinks(links)
}

func (tm *txMap) insertObject(objectPtr *txObjectPtr) bool {
    return tm.instancePtr.insertObject(objectPtr)
}

func (tm *txMap) insertObjects(objects txObjects) bool {
    return tm.instancePtr.insertObjects(objects)
}

func (tm *txMap) insertJunction(juncPtr *txJunctionPtr) bool {
    return tm.instancePtr.insertJunction(juncPtr)
}

func (tm *txMap) insertJunctions(juncs txJunctions) bool {
    r := false
    for _, juncPtr := range juncs {
        r = r || tm.insertJunction(juncPtr)
    }
    return r
}

func (tm *txMap) updateRoad(road *txRoadPtr) bool {
    return tm.instancePtr.updateRoad(road)
}

func (tm *txMap) updateRoads(roads txRoads) bool {
    r := false
    for _, roadPtr := range roads {
        r = r || tm.updateRoad(roadPtr)
    }
    return r
}

func (tm *txMap) updateLaneLink(lanelink *txLaneLinkPtr) bool {
    return tm.instancePtr.updateLaneLink(lanelink)
}

func (tm *txMap) updateLaneLinks(lanelinks txLaneLinks) bool {
    r := false
    for _, lanelinkPtr := range lanelinks {
        r = r || tm.updateLaneLink(lanelinkPtr)
    }
    return r
}

func (tm *txMap) updateCenter(lonlatele txPoint) bool {
    return tm.instancePtr.updateCenter(lonlatele)
}

func (tm *txMap) indertRefPoint(point txPoint) bool {
    tm.instancePtr.ref_point = point
    return true
}

func (tm *txMap) removeRoad(roadId roadpkid) bool {
    return tm.instancePtr.removeRoad(roadId)
}

func (tm *txMap) removeRoads(roadIds []roadpkid) bool {
    return tm.instancePtr.removeRoads(roadIds)
}

func (tm *txMap) removeLinks(lanelinkids []lanelinkpkid) bool {
    r := false
    for _, it := range lanelinkids {
        r = r || tm.instancePtr.removeLaneLink(it)
    }
    return r
}

func (tm *txMap) removeLinksByRoads(fromRoadId roadpkid, toRoadId roadpkid) bool {
    return tm.instancePtr.removeLinks(fromRoadId, toRoadId)
}

func (tm *txMap) removeObject(objectId objectpkid) bool {
    return tm.instancePtr.removeObject(objectId)
}

func (tm *txMap) removeObjects(objectIds []objectpkid) bool {
    return tm.instancePtr.removeObjects(objectIds)
}

func (tm *txMap) removeJunction(jId junctionpkid) bool {
    return tm.instancePtr.removeJunction(jId)
}

func (m *txMap) getGeomCoordType() CoordType {
    return m.instancePtr.getGeomCoordType()
}

func (m *txMap) getProjection() txProjectionConstPtr {
    return m.instancePtr.getProjection()
}

func (m *txMap) getRoadById(roadId roadpkid) txRoadPtr {
    var roadPtr txRoadPtr
    if m.instancePtr.getRoadById(roadId, &roadPtr) {
        return roadPtr
    } else {
        return nil
    }
}

func (m *txMap) getLaneById(laneId txLaneId) txLanePtr {
    var lanes txLanes
    if m.instancePtr.specLanes(laneId, &lanes) {
        return lanes.front()
    } else {
        return nil
    }
}

func (m *txMap) getLanes(pos txPoint, radius float64) txLanes {
    var offset float64 = radius
    if m.instancePtr.getGeomCoordType() == COORD_WGS84 {
        var x, y, z float64 = radius, radius, 0
        coord_trans_api.enu2lonlat(x, y, z, pos.x, pos.y, 0)
        offset = max(abs(x-pos.x), abs(y-pos.y))
    }
    var lanes txLanes
    var envelope PointVec
    envelope.push_back(txPoint{pos.x - offset, pos.y - offset, pos.z})
    envelope.push_back(txPoint{pos.x + offset, pos.y + offset, pos.z})
    if m.instancePtr.searchLanes(envelope, &lanes) {
        return lanes
    } else {
        return txLanes{}
    }
}

func (m *txMap) nearestLane(pos txPoint, radius float64) txLanePtr {
    var lanePtr txLanePtr
    if m.instancePtr.nearestLane(pos, radius, &lanePtr) {
        return lanePtr
    } else {
        return nil
    }
}

func (m *txMap) nearestLane(pos txPoint, radius float64, yaw float64) txLanePtr {
    var yawA float64 = map_util.radian2angle(yaw)
    var lanePtr txLanePtr
    if m.instancePtr.nearestLane(pos, radius, yawA, &lanePtr) {
        return lanePtr
    } else {
        return nil
    }
}

func (m *txMap) nearestLaneLink(pos txPoint, radius float64) txLaneLinkPtr {
    var linkPtr txLaneLinkPtr
    if m.instancePtr.nearestLaneLink(pos, radius, &linkPtr) {
        return linkPtr
    } else {
        return nil
    }
}

func (m *txMap) getNextLanes(lanePtr txLanePtr) txLanes {
    var lanes txLanes
    if lanePtr == nil || lanePtr.getGeometry() == nil || lanePtr.getGeometry().empty() {
        return lanes
    } else if m.instancePtr.nextLanes(lanePtr.getTxLaneId(), &lanes) {
        return lanes
    } else {
        return txLanes{}
    }
}

func (m *txMap) getPreLanes(lanePtr txLanePtr) txLanes {
    var lanes txLanes
    if lanePtr == nil || lanePtr.getGeometry() == nil || lanePtr.getGeometry().empty() {
        return lanes
    } else if m.instancePtr.preLanes(lanePtr.getTxLaneId(), &lanes) {
        return lanes
    } else {
        return txLanes{}
    }
}

func (m *txMap) getLeftLane(lanePtr txLanePtr) txLanePtr {
    if lanePtr == nil {
        return nil
    }

    var curLaneId txLaneId = lanePtr.getTxLaneId()
    if curLaneId.laneId < 0 {
        curLaneId.laneId += 1
        if curLaneId.laneId == 0 {
            curLaneId.laneId = 1
        }
    } else {
        curLaneId.laneId -= 1
        if curLaneId.laneId == 0 {
            curLaneId.laneId = -1
        }
    }
    return m.getLaneById(curLaneId)
}

func (m *txMap) getRightLane(lanePtr txLanePtr) txLanePtr {
    if lanePtr == nil {
        return nil
    }

    var curLaneId txLaneId = lanePtr.getTxLaneId()
    if curLaneId.laneId < 0 {
        curLaneId.laneId -= 1
    } else {
        curLaneId.laneId += 1
    }
    return m.getLaneById(curLaneId)
}

func (m *txMap) getBoundaries(pos txPoint, yaw, dis float64, out *txLaneBoundaries) bool {
    tagLanePtr := m.nearestLane(pos, 5.0, yaw)
    if tagLanePtr == nil {
        return false
    }

    var s, l float64
    var boundariesQueue []txLaneBoundaries
    if !tagLanePtr.xy2sl(pos.x, pos.y, &s, &l) {
        var p txPoint
        s = tagLanePtr.getGeometry().getPassedDistance(pos, &p, tagLanePtr.getGeometry().getCoordType())
    }

    var path []struct {
        lane *txLanePtr
        dis  float64
    }
    start := s
    path = append(path, struct {
        lane *txLanePtr
        dis  float64
    }{tagLanePtr, dis})

    for len(path) > 0 {
        var curPath []struct {
            lane *txLanePtr
            dis  float64
        }
        var boundaries txLaneBoundaries
        for _, pathNode := range path {
            var curBoundaries txLaneBoundaries
            if !pathNode.lane.section.road.isJunction() {
                if dis < 0.0 {
                    start = s
                    if start < 0.0 {
                        start = pathNode.lane.getLength()
                    }
                    curBoundaries = pathNode.lane.section.getBoundariesByRange(start+pathNode.dis, start)
                } else {
                    curBoundaries = pathNode.lane.section.getBoundariesByRange(start, start+pathNode.dis)
                }
            }
            boundaries = append(boundaries, curBoundaries...)
            left := pathNode.dis
            if dis*left > 0.0 {
                var nextLanes txLanes
                if dis > 0.0 {
                    nextLanes = m.getNextLanes(pathNode.lane)
                } else {
                    nextLanes = m.getPreLanes(pathNode.lane)
                }
                roadIds := make(map[roadpkid]struct{})
                for _, curLanePtr := range nextLanes {
                    if _, exists := roadIds[curLanePtr.getRoadId()]; !exists {
                        roadIds[curLanePtr.getRoadId()] = struct{}{}
                        curPath = append(curPath, struct {
                            lane *txLanePtr
                            dis  float64
                        }{curLanePtr, left})
                    }
                }
            }
        }
        if len(boundaries) > 0 {
            boundariesQueue = append(boundariesQueue, boundaries)
        }
        path, curPath = curPath, path
        start = 0.0
        if dis < 0.0 {
            start = -1.0
        }
    }
    if len(boundariesQueue) == 0 {
        return false
    }

    *out = boundariesQueue[0]
    for i := 1; i < len(boundariesQueue); i++ {
        var curOut txLaneBoundaries
        for _, boundPtr := range *out {
            endP := boundPtr.geometry.end
            if dis < 0.0 {
                endP = boundPtr.geometry.start
            }
            used := false
            for _, nextBoundPtr := range boundariesQueue[i] {
                startP := nextBoundPtr.geometry.start
                if dis < 0.0 {
                    startP = nextBoundPtr.geometry.end
                }
                offset := 1e-1
                if instancePtr.getCoordType() == COORD_WGS84 {
                    offset = 1e-6
                }
                if math.Abs(startP.x-endP.x) < offset && math.Abs(startP.y-endP.y) < offset {
                    used = true
                    newBoundPtr := &txLaneBoundaryPtr{
                        laneMark: nextBoundPtr.laneMark,
                    }
                    var frontPts, backPts []txPoint
                    boundPtr.geometry.getPoints(&frontPts)
                    nextBoundPtr.geometry.getPoints(&backPts)
                    mark := boundPtr.laneMark
                    nextMark := nextBoundPtr.laneMark
                    if dis > 0.0 {
                        if ((mark&LANE_MARK_Broken)+(mark&LANE_MARK_Broken2)+(mark&LANE_MARK_Shielded)+(mark&LANE_MARK_Absent) > 0) &&
                            ((mark&LANE_MARK_Solid)+(mark&LANE_MARK_Solid2) == 0) {
                            frontPts = backPts
                        } else if ((nextMark&LANE_MARK_Broken)+(nextMark&LANE_MARK_Broken2)+(nextMark&LANE_MARK_Shielded)+(nextMark&LANE_MARK_Absent) > 0) &&
                            ((nextMark&LANE_MARK_Solid)+(nextMark&LANE_MARK_Solid2) == 0) {
                            newBoundPtr.laneMark = boundPtr.laneMark
                        } else {
                            frontPts = append(frontPts, backPts[1:]...)
                            newBoundPtr.geometry = &txLineCurve{start: frontPts[0], end: frontPts[len(frontPts)-1]}
                        }
                    } else {
                        if ((mark&LANE_MARK_Broken)+(mark&LANE_MARK_Broken2)+(mark&LANE_MARK_Shielded)+(mark&LANE_MARK_Absent) > 0) &&
                            ((mark&LANE_MARK_Solid)+(mark&LANE_MARK_Solid2) == 0) {
                        } else if ((nextMark&LANE_MARK_Broken)+(nextMark&LANE_MARK_Broken2)+(nextMark&LANE_MARK_Shielded)+(nextMark&LANE_MARK_Absent) > 0) &&
                            ((nextMark&LANE_MARK_Solid)+(nextMark&LANE_MARK_Solid2) == 0) {
                            newBoundPtr.laneMark = boundPtr.laneMark
                            backPts = frontPts
                        } else {
                            backPts = append(backPts, frontPts[1:]...)
                        }
                        newBoundPtr.geometry = &txLineCurve{start: backPts[0], end: backPts[len(backPts)-1]}
                    }
                    curOut = append(curOut, newBoundPtr)
                }
            }
            if !used {
                curOut = append(curOut, boundPtr)
            }
        }
        *out = curOut
    }

    for i := 0; i < len(*out); {
        mark := (*out)[i].laneMark
        if ((mark&LANE_MARK_Broken)+(mark&LANE_MARK_Broken2)+(mark&LANE_MARK_Shielded)+(mark&LANE_MARK_Absent) > 0) &&
            ((mark&LANE_MARK_Solid)+(mark&LANE_MARK_Solid2) == 0) {
            *out = append((*out)[:i], (*out)[i+1:]...)
        } else {
            i++
        }
    }

    return true
}


func (m *txMap) getLaneBoundaries(pos txPoint, yaw float64, range_ std.pair[float64, float64]) txLaneBoundaries {
    var pre_bounds, next_bounds txLaneBoundaries
    if range_.first < -1.0 {
        m.getBoundaries(pos, yaw, range_.first, &pre_bounds)
    }
    if range_.second > 1.0 {
        m.getBoundaries(pos, yaw, range_.second, &next_bounds)
    }
    if len(pre_bounds) == 0 {
        return next_bounds
    } else if len(next_bounds) == 0 {
        return pre_bounds
    } else {
        var bounds txLaneBoundaries
        for _, pre_bound_ptr := range pre_bounds {
            end_p := pre_bound_ptr.geometry.getEnd()
            used := false
            for _, next_bound_ptr := range next_bounds {
                start_p := next_bound_ptr.geometry.getStart()
                offset := 1e-1
                if m.instancePtr.coordType == COORD_WGS84 {
                    offset = 1e-6
                }
                if math.Abs(start_p.x-end_p.x) < offset && math.Abs(start_p.y-end_p.y) < offset {
                    used = true
                    new_bound_ptr := &txLaneBoundary{}
                    var front_pts, back_pts []txPoint
                    pre_bound_ptr.geometry.getPoints(&front_pts)
                    next_bound_ptr.geometry.getPoints(&back_pts)
                    front_pts = append(front_pts, back_pts[1:]...)
                    new_bound_ptr.setGeometry(front_pts, m.instancePtr.coordType)
                    bounds = append(bounds, new_bound_ptr)
                }
            }
        }
        return bounds
    }
}

func (m *txMap) getObject(objId objectpkid) *txObject {
    var objPtr *txObject
    if m.instancePtr.getObject(objId, &objPtr) {
        return objPtr
    } else {
        return nil
    }
}

func (m *txMap) getObject(pos txPoint, obj_type OBJECT_TYPE) *txObject {
    if obj_type != OBJECT_TYPE_CrossWalk && obj_type != OBJECT_TYPE_DrivingArea &&
        obj_type != OBJECT_TYPE_ParkingSpace {
        return nil
    }
    envelope := []txPoint{pos, pos}
    search_radius := 5.0
    wgs84 := false
    if m.instancePtr.coordType == COORD_WGS84 {
        x, y, z := search_radius, search_radius, 0
        coord_trans_api.Enu2Lonlat(x, y, z, pos.x, pos.y, 0)
        search_radius = math.Max(math.Abs(x-pos.x), math.Abs(y-pos.y))

        envelope[0].x -= search_radius
        envelope[0].y -= search_radius
        envelope[1].x += search_radius
        envelope[1].y += search_radius
        wgs84 = true
    } else {
        envelope[0].x -= search_radius
        envelope[0].y -= search_radius
        envelope[1].x += search_radius
        envelope[1].y += search_radius
    }
    area_objs := m.getObjects(envelope, []OBJECT_TYPE{obj_type})
    p := hadmap.Point2d{pos.x, pos.y}
    for _, obj_ptr := range area_objs {
        var points []txPoint
        obj_ptr.geom.geometry.getPoints(&points)
        var pts []hadmap.Point2d
        for _, point := range points {
            pts = append(pts, hadmap.Point2d{point.x, point.y})
        }
        if map_util.PosInPolygon(p, pts, wgs84) {
            return obj_ptr
        }
    }
    return nil
}

func (m *txMap) getObjects(envelope []txPoint, objTypes []OBJECT_TYPE) txObjects {
    var objects txObjects
    var typeSets map[OBJECT_TYPE]struct{}
    for _, t := range objTypes {
        typeSets[t] = struct{}{}
    }
    if m.instancePtr.searchObjects(envelope, typeSets, txLaneId{ROAD_PKID_INVALID, SECT_PKID_INVALID, LANE_PKID_INVALID}, &objects) {
        return objects
    } else {
        return txObjects{}
    }
}

func (m *txMap) getObjects(envelope []txPoint, yaw float64, objTypes []OBJECT_TYPE) txObjects {
    objects := m.getObjects(envelope, objTypes)
    var filter_objs txObjects
    for _, obj_ptr := range objects {
        curve_ptr := obj_ptr.geom.geometry.(*txLineCurve)
        var points []txPoint
        curve_ptr.getPoints(&points)

        y := map_util.Radian2angle(yaw)
        var y_dir hadmap.Point2d
        map_util.Yaw2dir(y, true, &y_dir)
        switch obj_ptr.objectType {
        case OBJECT_TYPE_TrafficSign:
            var normal txPoint
            if m.instancePtr.coordType == COORD_WGS84 {
                coord_trans_api.Lonlat2enu(points[0].x, points[0].y, points[0].z, points[1].x, points[1].y, points[1].z)
                coord_trans_api.Lonlat2enu(points[2].x, points[2].y, points[2].z, points[1].x, points[1].y, points[1].z)
            } else {
                points[0].x -= points[1].x
                points[0].y -= points[1].y
                points[0].z -= points[1].z
                points[2].x -= points[1].x
                points[2].y -= points[1].y
                points[2].z -= points[1].z
            }
            normal.x = points[2].y*points[0].z - points[2].z*points[0].y
            normal.y = points[2].z*points[0].x - points[2].x*points[0].z
            normal.z = points[2].x*points[0].y - points[2].y*points[0].x

            var n_dir hadmap.Point2d
            n_dir.x = normal.x
            n_dir.y = normal.y
            if map_util.Angle(y_dir, n_dir) > 100.0 {
                filter_objs = append(filter_objs, obj_ptr)
            }
        case OBJECT_TYPE_RoadSign, OBJECT_TYPE_Arrow, OBJECT_TYPE_Text, OBJECT_TYPE_RoadSign_Text, OBJECT_TYPE_LaneBoundary, OBJECT_TYPE_LineSegment_PL:
            var dir hadmap.Point2d
            front_index := 1
            back_index := 2
            #ifdef DATAMODEL_CLIENT
            front_index = 0
            back_index = 1
            #endif
            if obj_ptr.objectType == OBJECT_TYPE_LineSegment_PL {  // Only two points
                front_index = 1
                back_index = 0
            }
            if m.instancePtr.coordType == COORD_WGS84 {
                coord_trans_api.Lonlat2enu(points[front_index].x, points[front_index].y, points[front_index].z,
                    points[back_index].x, points[back_index].y, points[back_index].z)
            } else {
                points[front_index].x -= points[back_index].x
                points[front_index].y -= points[back_index].y
                points[front_index].z -= points[back_index].z
            }
            dir.x = points[front_index].x
            dir.y = points[front_index].y

            if map_util.Angle(y_dir, dir) < 70.0 {
                filter_objs = append(filter_objs, obj_ptr)
            }
        default:
        }
    }
    return filter_objs
}

func (m *txMap) getObjects(pos txPoint, yaw float64, range_ std.pair[float64, float64], objTypes []OBJECT_TYPE) txObjects {
    dir := Point2d{}
    ang := map_util.Radian2Angle(yaw)
    leftAng := ang - 90.0
    if leftAng < 0.0 {
        leftAng += 360.0
    }
    map_util.Yaw2Dir(ang, true, &dir)

    leftDir := Point2d{}
    map_util.Yaw2Dir(leftAng, true, &leftDir)

    radius := 30.0
    prePoint := txPoint{dir.x * range_.first, dir.y * range_.first, 0.0}
    nextPoint := txPoint{dir.x * range_.second, dir.y * range_.second, 0.0}
    points := []txPoint{
        {prePoint.x + leftDir.x*radius, prePoint.y + leftDir.y*radius, 0.0},
        {prePoint.x - leftDir.x*radius, prePoint.y - leftDir.y*radius, 0.0},
        {nextPoint.x + leftDir.x*radius, nextPoint.y + leftDir.y*radius, 0.0},
        {nextPoint.x - leftDir.x*radius, nextPoint.y - leftDir.y*radius, 0.0},
    }

    if m.instancePtr.coordType == COORD_WGS84 {
        for i := range points {
            coord_trans_api.Enu2Lonlat(&points[i].x, &points[i].y, &points[i].z, pos.x, pos.y, pos.z)
        }
    } else {
        for i := range points {
            points[i].x += pos.x
            points[i].y += pos.y
            points[i].z += pos.z
        }
    }

    envelope := []txPoint{points[0], points[0]}
    for _, point := range points {
        envelope[0].x = math.Min(envelope[0].x, point.x)
        envelope[0].y = math.Min(envelope[0].y, point.y)
        envelope[1].x = math.Max(envelope[1].x, point.x)
        envelope[1].y = math.Max(envelope[1].y, point.y)
    }

    objs := m.getObjects(envelope, yaw, objTypes)
    const heightOffset = 5.0
    for i := 0; i < len(objs); {
        p := objs[i].geom.geometry.getStart()
        if p.z > pos.z+heightOffset || p.z < pos.z-heightOffset {
            objs = append(objs[:i], objs[i+1:]...)
        } else {
            i++
        }
    }
    return objs
}

func (m *txMap) getObjects(objTypes []OBJECT_TYPE, relIds []txLaneId) txObjects {
    objects := txObjects{}
    if m.instancePtr.getObjects(relIds, &objects) {
        if len(objTypes) == 0 {
            return objects
        }
        typeSets := make(map[OBJECT_TYPE]struct{})
        for _, type_ := range objTypes {
            typeSets[type_] = struct{}{}
        }
        for i := 0; i < len(objects); {
            if _, ok := typeSets[objects[i].objectType]; !ok {
                objects = append(objects[:i], objects[i+1:]...)
            } else {
                i++
            }
        }
        return objects
    } else {
        return txObjects{}
    }
}

func (m *txMap) getObjects(objTypes []OBJECT_SUB_TYPE, relIds []txLaneId) txObjects {
    objects := txObjects{}
    if m.instancePtr.getObjects(relIds, &objects) {
        if len(objTypes) == 0 {
            return objects
        }
        typeSets := make(map[OBJECT_SUB_TYPE]struct{})
        for _, type_ := range objTypes {
            typeSets[type_] = struct{}{}
        }
        for i := 0; i < len(objects); {
            if _, ok := typeSets[objects[i].objectSubType]; !ok {
                objects = append(objects[:i], objects[i+1:]...)
            } else {
                i++
            }
        }
        return objects
    } else {
        return txObjects{}
    }
}

func (m *txMap) getJunction(jId junctionpkid) *txJunctionPtr {
    juncPtr := &txJunctionPtr{}
    if m.specJunction(jId, juncPtr) {
        return juncPtr
    } else {
        return nil
    }
}

func (m *txMap) getJunctions(juncs *txJunctions) bool {
    return m.instancePtr.getJunctions(juncs)
}

func (m *txMap) getJunctions() txJunctions {
    juncs := txJunctions{}
    m.instancePtr.getJunctions(&juncs)
    return juncs
}

func (m *txMap) priorityCmp(curPtr *txJunctionRoadPtr, cmpPtr *txJunctionRoadPtr) PRIORITY_TYPE {
    return m.instancePtr.priorityCmp(curPtr, cmpPtr)
}

func (m *txMap) getRefPoint() txPoint {
    return m.instancePtr.ref_point
}

func (m *txMap) getHeader() txOdHeaderPtr {
    return m.instancePtr.headerptr
}

func (m *txMap) setHeader(header txOdHeaderPtr) {
    m.instancePtr.headerptr = header
}
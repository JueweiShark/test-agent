package hadmap

import (
    "encoding/xml"
    "fmt"
    "math"
    "strconv"
    "strings"
    "sync"
    "unicode/utf8"

    openDrive "wuwen.com/wwsi/internal/biz/xosc/hadmap/odp"
)

type AreaPointVec [][]txPoint

func (o *ODXYZ) ADD(rhs ODXYZ) {
    o.X += rhs.X
    o.Y += rhs.Y
    o.Z += rhs.Z
}

func (o ODXYZ) Plus(rhs ODXYZ) ODXYZ {
    return ODXYZ{
        x: o.x + rhs.x,
        y: o.y + rhs.y,
        z: o.z + rhs.z,
    }
}

type ODXYZWH struct {
    ODXYZ
    w, h float64
}

type ODXYZWHP struct {
    ODXYZWH
    l, p float64
}

type ODRPY struct {
    hdg, roll, pitch float64
}

func (o ODRPY) Multiply(p ODXYZ) ODXYZ {
    // Implementation of the multiplication operation
    return ODXYZ{}
}

type ODNode struct {
    nodeName string
}

func NewODNode(n string) *ODNode {
    return &ODNode{nodeName: n}
}

func (o *ODNode) ElementCheck(element *XMLElement) {
    // Implementation of element check
}

func (o *ODNode) GetName() string {
    return o.nodeName
}

type ODHeader struct {
    *ODNode
    GeoRef string `xml:"geoRef"`
    north, south, east, west float64
    coordStr                 string
    remajor, reminor         uint8
    vendor, date             string
}

func NewODHeader() *ODHeader {
    return &ODHeader{
        ODNode:  NewODNode("header"),
        north:   0.0,
        south:   0.0,
        east:    0.0,
        west:    0.0,
        remajor: 1,
        reminor: 4,
    }
}

func (o *ODHeader) GetBBox(north, south, east, west *float64) {
    *north = o.north
    *south = o.south
    *east = o.east
    *west = o.west
}

func (o *ODHeader) GetGeoRef() string {
    return o.coordStr
}

func (o *ODHeader) GetVendor() string {
    return o.vendor
}

func (o *ODHeader) GetDate() string {
    return o.date
}

func (o *ODHeader) GetRemajor() uint8 {
    return o.remajor
}

func (o *ODHeader) GetReminor() uint8 {
    return o.reminor
}

type ODLinkType int

const (
    ROAD ODLinkType = 1
    JUNC ODLinkType = 2
)

type ODConType int

const (
    START ODConType = 1
    END   ODConType = 2
)

type ODLink struct {
    ODNode
    fromRid  pkid_t
    fromType ODLinkType
    fromCont ODConType
    toRid    pkid_t
    toType   ODLinkType
    toCont   ODConType

    FromType ODLinkType
    FromRid  roadpkid
    FromCont ODConType
    ToType   ODLinkType
    ToRid    roadpkid
    ToCont   ODConType
}
type ODConnection struct {
    ODNode
    mu        sync.Mutex
    fromID    roadpkid
    toID      roadpkid
    links     []Pair[lanepkid, lanepkid]
    FromRid   int64
    ToRid     int64
    LaneLinks []LaneLink
}
type ODConnectionPtr *ODConnection

type ODController struct {
    ODNode
    Id string `xml:"id"`
    cid       controllerkid
    signalIds []objectpkid
}
type ODControllerPtr *ODController

type ODJunction struct {
    ODNode
    jid         junctionpkid
    connections []ODConnectionPtr
    controllers []controllerkid
    mu          sync.Mutex
    ID          int64
    Connections []ODConnection
    Controllers []int64
}
type Polynomial3D struct {
    ODNode
    S float64
    A float64
    B float64
    C float64
    D float64
}

type GeomParam struct {
    s, a, b, c, d float64
}

// ODLanePtr is a shared pointer to ODLane
type ODLanePtr *ODLane

// ODLaneSection is a vector of ODLanePtr
type ODLaneSection []*ODLanePtr

// ODGeometry is a node representing geometry
type ODGeometry struct {
    ODNode
    s, x, y, hdg, len float64
    pi                float64
    mu                sync.Mutex
}

// ODGeomPtr is a shared pointer to ODGeometry
type ODGeomPtr *ODGeometry

// ODParamLine is a geometry representing a line
type ODParamLine struct {
    ODGeometry
    startX, startY, heading, offset, minLen float64
}

// NewODParamLine creates a new ODParamLine instance
func NewODParamLine() *ODParamLine {
    return &ODParamLine{
        ODGeometry: &ODGeometry{},
        minLen:     1.0,
    }
}

// ODParamLinePtr is a shared pointer to ODParamLine
type ODParamLinePtr *ODParamLine

// ODGeomSpiral represents a spiral geometry
type ODGeomSpiral struct {
    ODGeometry
    nodeName   string
    minLen     float64
    minAngle   float64
    curveStart float64
    curveEnd   float64
}

// ODParamSpiralPtr is a shared pointer to ODGeomSpiral
type ODParamSpiralPtr *ODGeomSpiral

// ODParamArc represents an arc geometry
type ODParamArc struct {
    ODGeometry
    nodeName  string
    minLen    float64
    minAngle  float64
    curvature float64
    XMLName     xml.Name
    Curvature   float64
    MinLen      float64
    MinAngle    float64
    Heading     float64
    StartX      float64
    StartY      float64
    Offset      float64
}

// ODParamArcPtr is a shared pointer to ODParamArc
type ODParamArcPtr *ODParamArc

// ODGeomPoly3 represents a 3D polynomial geometry
type ODGeomPoly3 struct {
    ODGeometry
    nodeName string
    minLen   float64
    minAngle float64
    XMLName xml.Name `xml:"poly3"`
    A       float64  `xml:"a,attr"`
    B       float64  `xml:"b,attr"`
    C       float64  `xml:"c,attr"`
    D       float64  `xml:"d,attr"`
}

type ODODGeomPoly3Ptr *ODGeomPoly3

// ODParamPoly3 class represents a 3D parametric polynomial geometry
type ODParamPoly3 struct {
    ODGeometry
    nodeName   string
    min_len    float64
    min_angle  float64
    normalized bool
    aU         float64
    bU         float64
    cU         float64
    dU         float64
    aV         float64
    bV         float64
    cV         float64
    dV         float64
    offset                         float64
    startX                         float64
    startY                         float64
}

type ODParamPoly3Ptr *ODParamPoly3

// ODCorner class represents a corner in the road network
type ODCorner struct {
    ODNode
}
type ODCornerPtr *ODCorner
type ODCorners []*ODCorner

// ODCornerRoad represents a corner in the road network
type ODCornerRoad struct {
    ODCorner
    ID     uint64  `xml:"id"`
    S      float64 `xml:"s"`
    T      float64 `xml:"t"`
    Dz     float64 `xml:"dz"`
    Height float64 `xml:"height"`
}

// ODCornerLocal represents a local corner in the road network
type ODCornerLocal struct {
    ODCorner
    ID     uint64  `xml:"id"`
    U      float64 `xml:"u"`
    V      float64 `xml:"v"`
    Z      float64 `xml:"z"`
    Height float64 `xml:"height"`
}

// ODCorner is a base struct for corners
//type ODCorner struct {
//    Name string `xml:"name"`
//}
// ODCornerRoad represents a corner in the road network
// ODOutline represents an outline in the road network

type ODOutline struct {
    ODNode
    ID      uint64     `xml:"id,attr"`
    Closed  bool       `xml:"closed,attr"`
    Corners []ODCorner `xml:"corners>corner"`
}

// ODXYZ represents XYZ coordinates
type ODXYZ struct {
    X float64 `xml:"x,attr"`
    Y float64 `xml:"y,attr"`
    Z float64 `xml:"z,attr"`
}

// PairBoolODXYZ represents a pair of a boolean and ODXYZ
type PairBoolODXYZ struct {
    Bool bool
    ODXYZ
}
type ODOutlinePtr *ODOutline
type ODOutlines []*ODOutline

// ODRepeat represents a repeat element in the road network
type ODRepeat struct {
    XMLName xml.Name `xml:"repeat"`

    S           float64 `xml:"s"`
    Length      float64 `xml:"length"`
    Distance    float64 `xml:"distance"`
    TStart      float64 `xml:"tStart"`
    TEnd        float64 `xml:"tEnd"`
    WidthStart  float64 `xml:"widthStart"`
    WidthEnd    float64 `xml:"widthEnd"`
    HeightStart float64 `xml:"heightStart"`
    HeightEnd   float64 `xml:"heightEnd"`
    OffsetStart float64 `xml:"zOffsetStart"`
    OffsetEnd   float64 `xml:"zOffsetEnd"`
    LengthStart float64 `xml:"lengthStart"`
    LengthEnd   float64 `xml:"lengthEnd"`
}

// ODParkingSpace represents a parking space in the road network
type ODParkingSpace struct {
    XMLName      xml.Name  `xml:"parkingSpace"`
    Access       string    `xml:"access"`
    Restrictions string    `xml:"restrictions"`
    Markings     []Marking `xml:"markings>marking"`
}
type Marking struct {
    Side  string  `xml:"side"`
    Type  string  `xml:"type"`
    Width float64 `xml:"width"`
    Color string  `xml:"color"`
}

// ODMarkings represents markings in the road network
type ODMarkings struct {
    XMLName  xml.Name  `xml:"markings"`
    Markings []Marking `xml:"marking"`
}
type ODObject struct {
    ODNode
    Type         string
    SubType      string
    Name         string
    ID           string
    S            float64
    T            float64
    ZOffset      float64
    Hdg          float64
    Pitch        float64
    Roll         float64
    Length       float64
    Width        float64
    Height       float64
    Radius       float64
    IsOutLines   bool
    Markings     *ODMarkings
    Repeats      []*ODRepeat
    Outlines     ODOutlines
    ParkingSpace *ODParkingSpace
    Points       []ODXYZ
    UserData     map[string]string
    ValidityLane []int
}
//func (o *ODObject) Parse(element *xml.Element) error {
//    if element == nil {
//        return errors.New("element is nil")
//    }
//
//    o.Type = element Attr("type")
//    o.SubType = element Attr("subtype")
//    o.Name = element Attr("name")
//    o.ID = element Attr("id")
//    o.S, _ = strconv.ParseFloat(element Attr("s"), 64)
//    o.T, _ = strconv.ParseFloat(element Attr("t"), 64)
//    o.ZOffset, _ = strconv.ParseFloat(element Attr("zOffset"), 64)
//    o.Hdg, _ = strconv.ParseFloat(element Attr("hdg"), 64)
//    o.Pitch, _ = strconv.ParseFloat(element Attr("pitch"), 64)
//    o.Roll, _ = strconv.ParseFloat(element Attr("roll"), 64)
//    o.Length, _ = strconv.ParseFloat(element Attr("length"), 64)
//    o.Width, _ = strconv.ParseFloat(element Attr("width"), 64)
//    o.Height, _ = strconv.ParseFloat(element Attr("height"), 64)
//    o.Radius, _ = strconv.ParseFloat(element Attr("radius"), 64)
//    o.IsOutLines = element Attr("isOutLines") == "true"
//
//    return nil
//}
type ODObjectPtr *ODObject

// Vector of ODObject shared pointers
type ODObjects []*ODObject

type ODSignal struct {
    XMLName     xml.Name `xml:"signal"`
    Type        string   `xml:"type,attr"`
    Subtype     string   `xml:"subtype,attr"`
    Name        string   `xml:"name,attr"`
    ID          string   `xml:"id,attr"`
    Dynamic     string   `xml:"dynamic,attr"`
    Country     string   `xml:"country,attr"`
    Orientation string   `xml:"orientation,attr"`
    Text        string   `xml:"text,attr"`
    S           float64  `xml:"s,attr"`
    T           float64  `xml:"t,attr"`
    ZOffset     float64  `xml:"zoffset,attr"`
    HOffset     float64  `xml:"hOffset,attr"`
    Pitch       float64  `xml:"pitch,attr"`
    Roll        float64  `xml:"roll,attr"`
    Hdg         float64  `xml:"hdg,attr"`
    Value       float64  `xml:"value,attr"`
    Width       float64  `xml:"width,attr"`
    Height      float64  `xml:"height,attr"`
    UserData    map[string]string
    ValidityLane []int
}

type ODSignalPtr *ODSignal
type ODSignals []ODSignalPtr

type ODCrg struct {
    ODNode

    File       string `xml:"file"`
    Orientation string `xml:"orientation"`
    Mode       string `xml:"mode"`
    Purpose    string `xml:"purpose"`
    SOffset    string `xml:"soffset"`
    TOffset    string `xml:"toffset"`
    ZOffset    string `xml:"zoffset"`
    ZScale     string `xml:"zscale"`
    HOffset    string `xml:"hoffset"`
}
type ODRoad struct {
    ODNode
    SpeedLimit int
    id       string         `xml:"id"`
    Sections []ODSectionPtr `xml:"<sections>section"`
}
type Object struct {
    SourceType    SourceType
    Type          string
    Subtype       string
    Name          string
    ID            string
    S, T          float64
    Len, Wid, Hei float64
    Roll, Pitch, Yaw float64
    Hdg           float64
    ZOffset       float64
    X, Y, Z       float64
    MarkWidth     float64
    MarkColor     string
    Geom          []map[bool][]ODXYZ
    Repeat        []ODXYZWH
    Boundary      []ODXYZ
    Access        string
    Restrictions  string
    RepetaData    string
    ParkingMark   []ParkingMark
    UserData      map[string]string
    ValidityLane  []int
}
type SignalRef struct {
    ID       string
    S, T     float64
    LaneIds  []int
}
type ODRoadPtr = *ODRoad
type ODRoads = []ODRoadPtr

func strCheckEmpty(s string) string {
    if s == "" {
        return ""
    }
    ns := s
    hasChn := false
    for _, c := range ns {
        if c > utf8.MaxRune {
            hasChn = true
            break
        }
    }
    if hasChn {
        // Go does not require setting locale for UTF-8 strings
        // Conversion between UTF-8 and other encodings can be done using packages like "golang.org/x/text/encoding"
        // For simplicity, this part is omitted in the translation
    }
    return ns
}

func (o *ODXYZ) addAssign(rhs ODXYZ) {
    o.x += rhs.x
    o.y += rhs.y
    o.z += rhs.z
}

func (o ODXYZ) add(rhs ODXYZ) ODXYZ {
    return ODXYZ{o.x + rhs.x, o.y + rhs.y, o.z + rhs.z}
}

func (o ODRPY) multiply(p ODXYZ) ODXYZ {
    s := p.x * math.Cos(o.hdg) - p.y * math.Sin(o.hdg)
    t := p.x * math.Sin(o.hdg) + p.y * math.Cos(o.hdg)
    return ODXYZ{s, t, p.z}
}


func (o *ODNode) elementCheck(element *XMLElement) error {
    if element == nil || o.nodeName != element.Name() {
        return errors.New("OpenDrive element parse error, no matching element")
    }
    return nil
}


func (e *XMLElement) Name() string {
    return e.NameFunc()
}

//type ODHeader struct {
//    North     float64 `xml:"north,attr"`
//    South     float64 `xml:"south,attr"`
//    East      float64 `xml:"east,attr"`
//    West      float64 `xml:"west,attr"`
//    Vendor    string  `xml:"vendor,attr,omitempty"`
//    Remajor   int64   `xml:"revMajor,attr,omitempty"`
//    Reminor   int64   `xml:"revMinor,attr,omitempty"`
//    Date      string  `xml:"date,attr,omitempty"`
//    CoordStr  string  `xml:"geoReference,omitempty"`
//}

func (h *ODHeader) Parse(element *xml.StartElement) bool {
    for _, attr := range element.Attr {
        switch attr.Name.Local {
        case "north":
            h.North = parseFloat(attr.Value)
        case "south":
            h.South = parseFloat(attr.Value)
        case "east":
            h.East = parseFloat(attr.Value)
        case "west":
            h.West = parseFloat(attr.Value)
        case "vendor":
            h.Vendor = attr.Value
        case "revMajor":
            h.Remajor = parseInt64(attr.Value)
        case "revMinor":
            h.Reminor = parseInt64(attr.Value)
        case "date":
            h.Date = attr.Value
        }
    }

    for _, child := range element.Children {
        if child.Name.Local == "geoReference" {
            h.CoordStr = child.Value
        }
    }

    return true
}

func (h *ODHeader) GetBBox() (float64, float64, float64, float64) {
    return h.North, h.South, h.East, h.West
}


func parseInt64(value string) int64 {
    var result int64
    fmt.Sscanf(value, "%d", &result)
    return result
}

//////////////////////////////////////////

type XMLElement struct {
    XMLName xml.Name
    Content []byte `xml:",innerxml"`
    Attrs   []xml.Attr    `xml:",any,attr"`
    Children []XMLElement `xml:",any"`
    NameFunc func() string
}

const ROAD_PKID_INVALID = -1

func StrCheckEmpty(s string) string {
    if s == "" {
        return ""
    }
    return s
}

func (o *ODLink) parse(element *XMLElement) bool {
    if element == nil {
        return false
    }

    predecessor := findChildElement(element, "predecessor")
    if predecessor != nil {
        typeStr := StrCheckEmpty(getAttribute(predecessor, "elementType"))
        o.FromType = ROAD
        if typeStr == "junc" {
            o.FromType = JUNC
        }
        o.FromRid = getAttributeInt64(predecessor, "elementId")
        typeStr = StrCheckEmpty(getAttribute(predecessor, "contactPoint"))
        o.FromCont = START
        if typeStr == "end" {
            o.FromCont = END
        }
    } else {
        o.FromRid = ROAD_PKID_INVALID
    }

    successor := findChildElement(element, "successor")
    if successor != nil {
        typeStr := StrCheckEmpty(getAttribute(successor, "elementType"))
        o.ToType = ROAD
        if typeStr == "junc" {
            o.ToType = JUNC
        }
        o.ToRid = getAttributeInt64(successor, "elementId")
        typeStr = StrCheckEmpty(getAttribute(successor, "contactPoint"))
        o.ToCont = END
        if typeStr == "start" {
            o.ToCont = START
        }
    } else {
        o.ToRid = ROAD_PKID_INVALID
    }

    return true
}

func (o *ODLink) FromRoadId() roadpkid {
    return o.FromRid
}

func (o *ODLink) ClearFromRoad() {
    o.FromRid = ROAD_PKID_INVALID
}

func (o *ODLink) ToRoadId() roadpkid {
    return o.ToRid
}

func (o *ODLink) ClearToRoad() {
    o.ToRid = ROAD_PKID_INVALID
}

func (o *ODLink) FromRoadType() ODLinkType {
    return o.FromType
}

func (o *ODLink) ToRoadType() ODLinkType {
    return o.ToType
}

func (o *ODLink) FromRoadCont() ODConType {
    return o.FromCont
}

func (o *ODLink) ToRoadCont() ODConType {
    return o.ToCont
}

func findChildElement(element *XMLElement, name string) *XMLElement {
    for _, child := range element.Children {
        if child.XMLName.Local == name {
            return &child
        }
    }
    return nil
}

func getAttribute(element *XMLElement, name string) string {
    for _, attr := range element.Attrs {
        if attr.Name.Local == name {
            return attr.Value
        }
    }
    return ""
}

func getAttributeInt64(element *XMLElement, name string) roadpkid {
    attr := getAttribute(element, name)
    if attr == "" {
        return ROAD_PKID_INVALID
    }
    val, err := strconv.ParseInt(attr, 10, 64)
    if err != nil {
        return ROAD_PKID_INVALID
    }
    return roadpkid(val)
}

type roadpkid int64
///////////////////

func (odc *ODConnection) Parse(element *xml.StartElement) error {
    for _, attr := range element.Attr {
        switch attr.Name.Local {
        case "incomingRoad":
            odc.FromRid = attr.Value
        case "connectingRoad":
            odc.ToRid = attr.Value
        }
    }

    for {
        tok, err := element.Token()
        if err != nil {
            return err
        }

        switch tok := tok.(type) {
        case xml.StartElement:
            if tok.Name.Local == "laneLink" {
                var link LaneLink
                if err := xml.NewDecoder().DecodeElement(&link, &tok); err != nil {
                    return err
                }
                odc.LaneLinks = append(odc.LaneLinks, link)
            }
        case xml.EndElement:
            if tok.Name.Local == "connection" {
                return nil
            }
        }
    }
}

func (odc *ODConnection) LaneLinkSize() int {
    return len(odc.LaneLinks)
}

func (odc *ODConnection) FromRoadId() int64 {
    return odc.FromRid
}

func (odc *ODConnection) ToRoadId() int64 {
    return odc.ToRid
}

func (odc *ODConnection) LaneLink(index int) (LaneLink, error) {
    if index >= len(odc.LaneLinks) {
        return LaneLink{}, errors.New("index out of range")
    }
    return odc.LaneLinks[index], nil
}

func (odj *ODJunction) Parse(element *xml.StartElement) error {
    for _, attr := range element.Attr {
        if attr.Name.Local == "id" {
            odj.ID = attr.Value
        }
    }

    for {
        tok, err := element.Token()
        if err != nil {
            return err
        }

        switch tok := tok.(type) {
        case xml.StartElement:
            switch tok.Name.Local {
            case "connection":
                var conn ODConnection
                if err := conn.Parse(&tok); err != nil {
                    return err
                }
                odj.Connections = append(odj.Connections, conn)
            case "controller":
                for _, attr := range tok.Attr {
                    if attr.Name.Local == "id" {
                        odj.Controllers = append(odj.Controllers, attr.Value)
                    }
                }
            }
        case xml.EndElement:
            if tok.Name.Local == "ODJunction" {
                return nil
            }
        }
    }
}

func (odj *ODJunction) Id() int64 {
    return odj.ID
}

func (odj *ODJunction) ConnectionSize() int {
    return len(odj.Connections)
}

func (odj *ODJunction) Connection(index int) (ODConnection, error) {
    if index >= len(odj.Connections) {
        return ODConnection{}, errors.New("index out of range")
    }
    return odj.Connections[index], nil
}

func (odj *ODJunction) GetControllers() []int64 {
    return odj.Controllers
}


func (p *Polynomial3D) Parse(element *xml.StartElement) error {
    for _, attr := range element.Attr {
        switch attr.Name.Local {
        case "s":
            p.S = attr.Value
        case "a":
            p.A = attr.Value
        case "b":
            p.B = attr.Value
        case "c":
            p.C = attr.Value
        case "d":
            p.D = attr.Value
        }
    }
    return nil
}

func (p *Polynomial3D) SampleValue(dis []float64) ([]float64, error) {
    if len(dis) == 0 {
        return nil, errors.New("distance array cannot be empty")
    }

    values := make([]float64, len(dis))
    for i, d := range dis {
        values[i] = p.Value(d)
    }
    return values, nil
}

func (p *Polynomial3D) Value(dis float64) float64 {
    return p.A + p.B*dis + p.C*dis*dis + p.D*dis*dis*dis
}

func (p *Polynomial3D) Slope(dis float64) float64 {
    return p.B + 2*p.C*dis + 3*p.D*dis*dis
}

func (p *Polynomial3D) GetParam() (float64, float64, float64, float64, float64) {
    return p.S, p.A, p.B, p.C, p.D
}

////////////////////
func (lane *ODLane) parse(element *etree.Element) bool {
    lane.lid, _ = strconv.ParseInt(element.SelectAttrValue("id", "0"), 10, 64)
    typeStr := StrCheckEmpty(element.SelectAttrValue("type", ""))

    switch typeStr {
    case "none":
        lane.lane_type = LANE_TYPE_None
    case "HOV":
        lane.lane_type = LANE_TYPE_HOV
    case "bidirectional":
        lane.lane_type = LANE_TYPE_BIDIRECTIONAL
    case "biking":
        lane.lane_type = LANE_TYPE_Biking
    case "border":
        lane.lane_type = LANE_TYPE_Border
    case "busonly":
        lane.lane_type = LANE_TYPE_BusOnly
    case "bus":
        lane.lane_type = LANE_TYPE_BusOnly
    case "connectingRamp":
        lane.lane_type = LANE_TYPE_CONNECTINGRAMP
    case "curb":
        lane.lane_type = LANE_TYPE_CURB
    case "driving":
        lane.lane_type = LANE_TYPE_Driving
    case "entry":
        lane.lane_type = LANE_TYPE_ENTRY
    case "exit":
        lane.lane_type = LANE_TYPE_EXIT
    case "median":
        lane.lane_type = LANE_TYPE_MEDIAN
    case "mwyEntry":
        lane.lane_type = LANE_TYPE_MwyEntry
    case "mwyExit":
        lane.lane_type = LANE_TYPE_MwyExit
    case "offRamp":
        lane.lane_type = LANE_TYPE_OFFRAMP
    case "onRamp":
        lane.lane_type = LANE_TYPE_ONRAMP
    case "parking":
        lane.lane_type = LANE_TYPE_Parking
    case "rail":
        lane.lane_type = LANE_TYPE_RAIL
    case "restricted":
        lane.lane_type = LANE_TYPE_Restricted
    case "roadWorks":
        lane.lane_type = LANE_TYPE_ROADWORKS
    case "shoulder":
        lane.lane_type = LANE_TYPE_Shoulder
    case "sidewalk":
        lane.lane_type = LANE_TYPE_Sidewalk
    case "stop":
        lane.lane_type = LANE_TYPE_Stop
    case "taxi":
        lane.lane_type = LANE_TYPE_TAXI
    case "tram":
        lane.lane_type = LANE_TYPE_TRAM
    case "reversible":
        lane.lane_type = LANE_TYPE_Reversible
    default:
        lane.lane_type = LANE_TYPE_Others
    }

    linkElem := element.FindElement("link")
    if linkElem != nil {
        predecessorElem := linkElem.FindElement("predecessor")
        if predecessorElem != nil {
            lane.from_lid, _ = strconv.ParseInt(predecessorElem.SelectAttrValue("id", "0"), 10, 64)
        } else {
            lane.from_lid = -1
        }

        successorElem := linkElem.FindElement("successor")
        if successorElem != nil {
            lane.to_lid, _ = strconv.ParseInt(successorElem.SelectAttrValue("id", "0"), 10, 64)
        } else {
            lane.to_lid = -1
        }
    } else {
        lane.from_lid = -1
        lane.to_lid = -1
    }

    markStr := "none"
    colorStr := "standard"
    lane.laneboundary_width = 0
    lane.laned_interval = 0
    lane.laned_space = 0
    lane.laned_soffset = 0
    lane.laned_len = 0

    roadmark := element.FindElement("roadMark")
    if roadmark != nil {
        markStr = StrCheckEmpty(roadmark.SelectAttrValue("type", ""))
        colorStr = StrCheckEmpty(roadmark.SelectAttrValue("color", ""))
        lane.laneboundary_width = parseFloat(roadmark.SelectAttrValue("width", "0"))

        xtype := roadmark.FindElement("type")
        for xtype != nil {
            if StrCheckEmpty(xtype.SelectAttrValue("name", "")) == markStr {
                line1 := xtype.FindElement("line")
                if line1 != nil {
                    lane.laned_space = parseFloat(line1.SelectAttrValue("space", "0"))
                    lane.laned_soffset = parseFloat(line1.SelectAttrValue("sOffset", "0"))
                    lane.laned_len = parseFloat(line1.SelectAttrValue("length", "0"))

                    line2 := line1.NextSiblingElement()
                    if line2 != nil && line2.Tag == "line" {
                        lane.laned_interval = math.Abs(parseFloat(line1.SelectAttrValue("tOffset", "0")) - parseFloat(line2.SelectAttrValue("tOffset", "0")))
                        lane.laned_space = math.Max(lane.laned_space, parseFloat(line2.SelectAttrValue("space", "0")))
                        lane.laned_soffset = math.Max(lane.laned_soffset, parseFloat(line2.SelectAttrValue("sOffset", "0")))
                        lane.laned_len = math.Max(lane.laned_len, parseFloat(line2.SelectAttrValue("length", "0")))
                    }
                }
                break
            }
            xtype = xtype.NextSiblingElement()
        }
    }

    switch markStr {
    case "solid":
        lane.lane_mark = LANE_MARK_Solid
    case "broken":
        lane.lane_mark = LANE_MARK_Broken
    case "solid solid":
        lane.lane_mark = LANE_MARK_SolidSolid
    case "solid broken":
        lane.lane_mark = LANE_MARK_SolidBroken
    case "broken solid":
        lane.lane_mark = LANE_MARK_BrokenSolid
    case "broken broken":
        lane.lane_mark = LANE_MARK_BrokenBroken
    case "curb":
        lane.lane_mark = LANE_MARK_Curb
    default:
        lane.lane_mark = LANE_MARK_None
    }

    if lane.lane_mark != LANE_MARK_None {
        switch colorStr {
        case "yellow":
            lane.lane_mark |= LANE_MARK_Yellow
        case "blue":
            lane.lane_mark |= LANE_MARK_Blue
        case "green":
            lane.lane_mark |= LANE_MARK_Green
        case "red":
            lane.lane_mark |= LANE_MARK_Red
        }
    }

    lane.speed_limit = 0
    speedElem := element.FindElement("speed")
    if speedElem != nil {
        speedMax := parseFloat(speedElem.SelectAttrValue("max", "0"))
        unit := StrCheckEmpty(speedElem.SelectAttrValue("unit", ""))
        if unit == "km/h" {
            speedMax *= 0.277778
        } else if unit == "mph" {
            speedMax *= 0.44704
        }
        lane.speed_limit = int(math.Max(0, round(speedMax*3.6)))
    }

    widthElem := element.FindElement("width")
    for widthElem != nil {
        gp := GeomParam{
            s: parseFloat(widthElem.SelectAttrValue("sOffset", "0")),
            a: sanitizeFloat(widthElem.SelectAttrValue("a", "0")),
            b: sanitizeFloat(widthElem.SelectAttrValue("b", "0")),
            c: sanitizeFloat(widthElem.SelectAttrValue("c", "0")),
            d: sanitizeFloat(widthElem.SelectAttrValue("d", "0")),
        }
        lane.params = append(lane.params, gp)
        widthElem = widthElem.NextSiblingElement()
    }

    materialElem := element.FindElement("material")
    if materialElem != nil {
        surfaceAttr := materialElem.SelectAttrValue("surface", "")
        switch surfaceAttr {
        case "cement":
            lane.laneSurface = LANE_SURFACE_CEMENT
        case "asphalt":
            lane.laneSurface = LANE_SURFACE_ASPHALT
        case "cobblestone":
            lane.laneSurface = LANE_SURFACE_COBBLESTONE
        case "dirt":
            lane.laneSurface = LANE_SURFACE_DIRT
        default:
            lane.laneSurface = LANE_SURFACE_OTHER
        }
        lane.lane_friction = parseFloat(materialElem.SelectAttrValue("friction", "0"))
        lane.lane_material_sOffset = parseFloat(materialElem.SelectAttrValue("sOffset", "0"))
    }

    return true
}

func parseFloat(value string) float64 {
    result, err := strconv.ParseFloat(value, 64)
    if err != nil {
        return 0
    }
    return result
}

func round(val float64) float64 {
    return math.Floor(val + 0.5)
}

func sanitizeFloat(value string) float64 {
    result := parseFloat(value)
    if math.IsInf(result, 0) || math.IsNaN(result) {
        return 0
    }
    return result
}
func (o *ODLane) ID() lanepkid {
    return o.lid
}

func (o *ODLane) FromLId() lanepkid {
    return o.from_lid
}

func (o *ODLane) ToLId() lanepkid {
    return o.to_lid
}

func (o *ODLane) Mark() LANE_MARK {
    return o.lane_mark
}

func (o *ODLane) Type() LANE_TYPE {
    return o.lane_type
}

func (o *ODLane) Surface() LANE_SURFACE {
    return o.lane_surface
}

func (o *ODLane) Friction() float64 {
    return o.lane_friction
}


func (o *ODLane) LaneWidth() float64 {
    return o.laneboundary_width
}

func (o *ODLane) LaneDInterval() float64 {
    return o.laned_interval
}

func (o *ODLane) Offset() float64 {
    if len(o.params) == 0 {
        return 0.0
    }
    return o.params[0].s
}

func (o *ODLane) Width(ds []float64) []float64 {
    width := make([]float64, len(ds))
    cur_i := 0
    for i := 0; i < len(ds); i++ {
        for (cur_i + 1) < len(o.params) && ds[i] > o.params[cur_i+1].s {
            cur_i++
        }
        if cur_i >= len(o.params) {
            break
        }
        cur_d := ds[i] - o.params[cur_i].s
        a, b, c, d := o.params[cur_i].a, o.params[cur_i].b, o.params[cur_i].c, o.params[cur_i].d
        width[i] = a + b*cur_d + c*cur_d*cur_d + d*cur_d*cur_d*cur_d
    }
    return width
}

func (g *ODGeometry) parse(element *tinyxml2.XMLElement) bool {
    g.s = element.DoubleAttribute("s")
    g.x = element.DoubleAttribute("x")
    g.y = element.DoubleAttribute("y")
    g.hdg = element.DoubleAttribute("hdg")
    g.len = math.Abs(element.DoubleAttribute("length"))
    return true
}

func (g *ODGeometry) offset() float64 {
    return g.s
}

func (g *ODGeometry) startX() float64 {
    return g.x
}

func (g *ODGeometry) startY() float64 {
    return g.y
}

func (g *ODGeometry) heading() float64 {
    return g.hdg
}

func (g *ODGeometry) length() float64 {
    return g.len
}

func (g *ODGeometry) setLength(length float64) {
    g.len = length
}

func (g *ODGeometry) getGeom(points []map[float64]float64) {
    if g.length() < 1e-6 {
        return
    }
    var intervals []float64
    g.getInterval(&intervals)
    points = make([]map[float64]float64, len(intervals))
    for i := 0; i < len(intervals); i++ {
        var x, y float64
        g.getGeom(intervals[i]+g.offset(), &x, &y)

        points[i] = map[float64]float64{
            x-g.startX(): y-g.startY(),
        }
    }
}

func (g *ODGeometry) getTangent(tangents *[]map[float64]float64) {
    if g.length() < 1e-6 {
        return
    }
    var intervals []float64
    g.getInterval(&intervals)
    *tangents = make([]map[float64]float64, len(intervals))
    for i := 0; i < len(intervals); i++ {
        h := g.getHeading(intervals[i] + g.offset())
        ( *tangents)[i] = map[float64]float64{
            math.Cos(h):  math.Sin(h),
        }
    }
}

func (g *ODGeometry) getNormal(normals *[]map[float64]float64) {
    if g.length() < 1e-6 {
        return
    }
    g.getTangent(normals)
    for i := 0; i < len(*normals); i++ {
        // swap normal
        (*normals)[i] = map[float64]float64{
            (*normals)[i][1]: -(*normals)[i][0],
        }
    }
}

func (g *ODGeometry) getNormal(s float64, x *float64, y *float64) {
    alpha := g.getHeading(s) + math.Pi*0.5
    *x = math.Cos(alpha)
    *y = math.Sin(alpha)
}

func (g *ODGeometry) getTangent(s float64, x *float64, y *float64) {
    alpha := g.getHeading(s)
    *x = math.Cos(alpha)
    *y = math.Sin(alpha)
}

func (g *ODGeometry) rotate(angle float64, x *float64, y *float64) {
    cos_a := math.Cos(angle)
    sin_a := math.Sin(angle)
    xx := *x*cos_a - *y*sin_a
    yy := *y*cos_a + *x*sin_a
    *x = xx
    *y = yy
}


func (l *ODParamLine) length() float64 {
    // Placeholder for actual length calculation
    return 0.0
}

func (l *ODParamLine) getCurvature(soffset float64) float64 {
    return 0.0
}

func (l *ODParamLine) getInterval(intervals *[]float64) {
    if l.length() < 1e-6 {
        return
    }
    *sp = []float64{}
    sp := int(math.Ceil(l.length() / l.minLen))
    itv := l.length() / float64(sp)
    for i := 0; i <= sp; i++ {
        *sp = append(*sp, itv*float64(i))
    }
}

func (l *ODParamLine) getGeom(s float64, x *float64, y *float64) {
    if l.length() < 1e-6 {
        return
    }
    *x = l.startX + (s-l.offset)*math.Cos(l.heading)
    *y = l.startY + (s-l.offset)*math.Sin(l.heading)
}

func (l *ODParamLine) getHeading(s float64) float64 {
    return l.heading
}

func (ogs *ODGeomSpiral) parse(element *tinyxml2.XMLElement) bool {
    // Assuming ODGeometry::parse is implemented elsewhere
    // ODGeometry::parse(element)
    element = element.FirstChildElement("spiral")
    // Assuming ELE_CKECK is implemented elsewhere
    // ELE_CKECK
    ogs.curveStart = element.DoubleAttribute("curvStart")
    ogs.curveEnd = element.DoubleAttribute("curvEnd")
    return true
}

func (ogs *ODGeomSpiral) getInterval(intervals *[]float64) {
    if ogs.length() < 1e-6 {
        return
    }
    *intervals = (*intervals)[:0]

    curve_dot := (ogs.curveEnd - ogs.curveStart) / ogs.length()
    if math.Abs(curve_dot) < 1e-6 {
        a := ogs.min_angle / (math.Abs(ogs.curveEnd) * math.Pi)
        a = math.Min(a, ogs.min_len)
        interval := math.Min(1.0, a/ogs.length())
        for _p := 0.0; _p < 1.001; _p += interval {
            *intervals = append(*intervals, _p*ogs.length())
        }
    } else {
        s_o := ogs.curveStart / curve_dot
        dt := math.Max(1e-4, math.Abs(curve_dot*s_o))
        s := 0.0
        for s < s.length() {
            *intervals = append(*intervals, s)
            s += math.Min(s.min_len, math.Abs(s.min_angle/dt))
            dt = math.Max(1e-4, math.Abs(curve_dot*(s_o+s)))
        }
        *intervals = append(*intervals, s.length())
    }
}

func (ogs *ODGeomSpiral) getCurvature(soffset float64) float64 {
    return 0.0
}

func (ogs *ODGeomSpiral) getGeom(s float64, x *float64, y *float64) {
    if ogs.length() < 1e-6 {
        return
    }
    dist := ogs - ogs.offset()

    curve_dot := (ogs.curve_end - ogs.curve_start) / ogs.length()
    if math.Abs(curve_dot) < 1e-6 {
        ogs -= ogs.offset()
        r := 1.0 / math.Abs(ogs.curve_end)
        tag := 1.0
        if ogs.curve_end < 0 {
            tag = -1.0
        }
        hdg := ogs.heading() + tag*math.Pi/2
        *x = r * math.Cos(hdg)
        *y = r * math.Sin(hdg)
        hdg += math.Pi
        alpha := hdg + ogs*ogs.curve_end
        *x += r * math.Cos(alpha)
        *y += r * math.Sin(alpha)
        *x += ogs.startX()
        *y += ogs.startY()
    } else {
        s_o := ogs.curve_start / curve_dot
        ogs = s_o + dist

        ogs.odrSpiral(ogs, curve_dot, x, y, nil)
        var x_o, y_o, t_o float64
        ogs.odrSpiral(s_o, curve_dot, &x_o, &y_o, &t_o)
        *x = *x - x_o
        *y = *y - y_o
        ogs.rotate(ogs.heading()-t_o, x, y)
        *x += ogs.startX()
        *y += ogs.startY()
    }
}

func (ogs *ODGeomSpiral) getHeading(s float64) float64 {
    if ogs.length() < 1e-6 {
        return 0
    }
    dist := s - ogs.offset()
    curve_dot := (ogs.curve_end - ogs.curve_start) / ogs.length()
    if math.Abs(curve_dot) < 1e-6 {
        return ogs.heading() + (s-ogs.offset())*ogs.curve_end
    } else {
        s_o := ogs.curve_start / curve_dot
        s = s_o + dist

        var t, t_o float64
        ogs.odrSpiral(s, curve_dot, nil, nil, &t)
        ogs.odrSpiral(s_o, curve_dot, nil, nil, &t_o)
        t = t - t_o
        return ogs.heading() + t
    }
}

// copy from opendrive
func (ogs *ODGeomSpiral) odrSpiral(s, cDot float64, x, y, t *float64) {
    if x != nil && y != nil {
        a := 1.0 / math.Sqrt(math.Abs(cDot))
        a *= math.Sqrt(math.Pi)
        fresnel(s/a, y, x)
        *x *= a
        *y *= a
        if cDot < 0.0 {
            *y *= -1.0
        }
    }

    if t != nil {
        *t = s * s * cDot * 0.5
    }
}



const pi = 3.1415926535897932384626433832795

func polevl(x float64, coef []float64, n int) float64 {
    ans := x + coef[0]
    for i := 1; i <= n; i++ {
        ans = ans * x + coef[i]
    }
    return ans
}

func p1evl(x float64, coef []float64, n int) float64 {
    ans := x + coef[0]
    for i := 1; i < n; i++ {
        ans = ans * x + coef[i]
    }
    return ans
}

func fresnel(xxa float64,ssa ,cca *float64)  {
    sn := []float64{
        -2.99181919401019853726E3, 7.08840045257738576863E5, -6.29741486205862506537E7,
        2.54890880573376359104E9, -4.42979518059697779103E10, 3.18016297876567817986E11,
    }
    sd := []float64{
        2.81376268889994315696E2, 4.55847810806532581675E4, 5.17343888770096400730E6,
        4.19320245898111231129E8, 2.24411795645340920940E10, 6.07366389490084639049E11,
    }

    cn := []float64{
        -4.98843114573573548651E-8, 9.50428062829859605134E-6, -6.45191435683965050962E-4,
        1.88843319396703850064E-2, -2.05525900955013891793E-1, 9.99999999999999998822E-1,
    }
    cd := []float64{
        3.99982968972495980367E-12, 9.15439215774657478799E-10, 1.25001862479598821474E-7, 1.22262789024179030997E-5,
        8.68029542941784300606E-4, 4.12142090722199792936E-2, 1.00000000000000000118E0,
    }

    fn := []float64{
        4.21543555043677546506E-1, 1.43407919780758885261E-1, 1.15220955073585758835E-2, 3.45017939782574027900E-4,
        4.63613749287867322088E-6, 3.05568983790257605827E-8, 1.02304514164907233465E-10, 1.72010743268161828879E-13,
        1.34283276233062758925E-16, 3.76329711269987889006E-20,
    }
    fd := []float64{
        7.51586398353378947175E-1, 1.16888925859191382142E-1, 6.44051526508858611005E-3, 1.55934409164153020873E-4,
        1.84627567348930545870E-6, 1.12699224763999035261E-8, 3.60140029589371370404E-11, 5.88754533621578410010E-14,
        4.52001434074129701496E-17, 1.25443237090011264384E-20,
    }

    gn := []float64{
        5.04442073643383265887E-1, 1.97102833525523411709E-1, 1.87648584092575249293E-2, 6.84079380915393090172E-4,
        1.15138826111884280931E-5, 9.82852443688422223854E-8, 4.45344415861750144738E-10, 1.08268041139020870318E-12,
        1.37555460633261799868E-15, 8.36354435630677421531E-19, 1.86958710162783235106E-22,
    }
    gd := []float64{
        1.47495759925128324529E0, 3.37748989120019970451E-1, 2.53603741420338795122E-2, 8.14679107184306179049E-4,
        1.27545075667729118702E-5, 1.04314589657571990585E-7, 4.60680728146520428211E-10, 1.10273215066240270757E-12,
        1.38796531259578871258E-15, 8.39158816283118707363E-19, 1.86958710162783236342E-22,
    }

    x := math.Abs(xxa)
    x2 := x * x

    var f, g, cc, ss, c, s, t, u float64

    if x2 < 2.5625 {
        t = x2 * x2
        ss = x * x2 * polevl(t, sn, 5) / p1evl(t, sd, 6)
        cc = x * polevl(t, cn, 5) / p1evl(t, cd, 6)
    } else if x > 36974.0 {
        cc = 0.5
        ss = 0.5
    } else {
        x2 = x * x
        t = pi * x2
        u = 1.0 / (t * t)
        t = 1.0 / t
        f = 1.0 - u*polevl(u, fn, 9)/p1evl(u, fd, 10)
        g = t * polevl(u, gn, 10) / p1evl(u, gd, 11)

        t = pi * 0.5 * x2
        c = math.Cos(t)
        s = math.Sin(t)
        t = pi * x
        cc = 0.5 + (f*s - g*c)/t
        ss = 0.5 - (f*c + g*s)/t
    }

    if xxa < 0.0 {
        cc = -cc
        ss = -ss
    }

    *ssa = ss
    *cca = cc
}
func polevl(x float64, coef []float64) float64 {
    ans := coef[0]
    p := 1

    for i := 1; i < len(coef); i++ {
        ans = ans*x + coef[i]
        p++
    }

    return ans
}


func (o *ODParamArc) Parse(element *xml.Element) bool {
    o.parse(element)

    element = element.FindElement("arc")
    if element == nil {
        return false
    }

    o.Curvature = element.Float64Attr("curvature")
    return true
}

func (o *ODParamArc) GetCurvature(soffset float64) float64 {
    return o.Curvature
}

func (o *ODParamArc) GetInterval(intervals *[]float64) {
    if o.Length() < 1e-6 {
        return
    }
    *intervals = (*intervals)[:0]
    if math.Abs(o.Curvature) < 1e-6 {
        sp := int(math.Ceil(o.Length() / o.MinLen))
        itv := o.Length() / float64(sp)
        for i := 0; i <= sp; i++ {
            *intervals = append(*intervals, itv*float64(i))
        }
    } else {
        interval := o.GetIntervalStep()
        for _p := 0.0; _p < 1.001; _p += interval {
            *intervals = append(*intervals, _p*o.Length())
        }
    }
}

func (o *ODParamArc) GetGeom(s float64, x *float64, y *float64) {
    if o.Length() < 1e-6 {
        return
    }
    if math.Abs(o.Curvature) < 1e-6 {
        *x = o.StartX + (s-o.Offset)*math.Cos(o.Heading)
        *y = o.StartY + (s-o.Offset)*math.Sin(o.Heading)
    } else {
        s -= o.Offset
        r := 1.0 / math.Abs(o.Curvature)
        tag := float64(1)
        if o.Curvature < 0 {
            tag = -1
        }
        hdg := o.Heading + tag*math.Pi/2
        *x = r * math.Cos(hdg)
        *y = r * math.Sin(hdg)
        hdg += math.Pi
        alpha := hdg + s*o.Curvature
        *x += r * math.Cos(alpha)
        *y += r * math.Sin(alpha)
        *x += o.StartX
        *y += o.StartY
    }
}

func (o *ODParamArc) GetHeading(s float64) float64 {
    if o.Length() < 1e-6 {
        return 0
    }
    return o.Heading + (s-o.Offset)*o.Curvature
}

func (o *ODParamArc) GetIntervalStep() float64 {
    if o.Length() < 1e-6 {
        return 0
    }
    a := o.MinAngle / (math.Abs(o.Curvature) * math.Pi)
    a = math.Min(a, o.MinLen)
    return math.Min(1.0, a/o.Length())
}


func (p *ODGeomPoly3) Parse(element *xml.StartElement) bool {
    // Assuming there's a function to parse ODGeometry which is not provided
    // ODGeometry.Parse(element)

    for _, attr := range element.Attr {
        switch attr.Name.Local {
        case "a":
            p.A = parseFloat(attr.Value)
        case "b":
            p.B = parseFloat(attr.Value)
        case "c":
            p.C = parseFloat(attr.Value)
        case "d":
            p.D = parseFloat(attr.Value)
        }
    }
    return true
}

func (p *ODGeomPoly3) GetInterval(intervals *[]float64) {
    if p.Length() < 1e-6 {
        return
    }
    *intervals = (*intervals)[:0]
    dt := 1e-4
    s := 0.0
    for s < p.Length() {
        *intervals = append(*intervals, s)
        s += math.Min(p.MinLen, p.MinAngle/dt)
        dt = math.Abs(2*p.C + 6*p.D*s)
        dt = math.Max(math.Atan(dt), 1e-4)
    }
    *intervals = append(*intervals, p.Length())
}

func (p *ODGeomPoly3) GetCurvature(soffset float64) float64 {
    const SampleDistance = 30.0
    i := 0
    for SampleDistance*float64(i) < p.Length() {
        if soffset < SampleDistance*float64(i) {
            var length float64 = SampleDistance
            if SampleDistance*float64(i) > p.Length() {
                length = p.Length() - SampleDistance*float64(i-1)
            }
            var mapPoint []struct{ X, Y float64 }
            for n := 0.0; n < length; n += p.MinLen {
                var x, y float64
                p.GetGeom(soffset+p.Offset(), &x, &y)
                mapPoint = append(mapPoint, struct{ X, Y float64 }{x, y})
            }
            // Assuming there's a function FitCenterByLeastSquares which is not provided
        }
        i++
    }
    return 0.0
}

func (p *ODGeomPoly3) GetGeom(s float64, x *float64, y *float64) {
    if p.Length() < 1e-6 {
        return
    }
    *x = s - p.Offset()
    *y = p.A + p.B**x + p.C**x**x + p.D**x**x**x
    p.Rotate(p.Heading(), x, y)
    *x += p.StartX()
    *y += p.StartY()
}

func (p *ODGeomPoly3) GetHeading(s float64) float64 {
    if p.Length() < 1e-6 {
        return 0
    }
    s -= p.Offset()
    v := p.A + p.B*s + p.C*s*s + p.D*s*s*s
    p.Rotate(p.Heading(), &s, &v)
    return math.Atan2(v, s)
}


func (p *ODParamPoly3) parse(element *XMLElement) bool {
    // Assuming ODGeometry::parse is already called elsewhere
    element = element.FirstChildElement("paramPoly3")
    if element == nil {
        panic(errors.New("element not found"))
    }

    p.aU = element.DoubleAttribute("aU")
    p.bU = element.DoubleAttribute("bU")
    p.cU = element.DoubleAttribute("cU")
    p.dU = element.DoubleAttribute("dU")
    p.aV = element.DoubleAttribute("aV")
    p.bV = element.DoubleAttribute("bV")
    p.cV = element.DoubleAttribute("cV")
    p.dV = element.DoubleAttribute("dV")
    szPRange := StrCheckEmpty(element.Attribute("pRange"))
    p.normalized = szPRange != "arcLength"

    return true
}

func (p *ODParamPoly3) getInterval(intervals *[]float64) {
    // Assuming length() is already defined elsewhere
    if p.length() < 1e-6 {
        return
    }
    *intervals = (*intervals)[:0]
    dt := 1e-4
    s := 0.0
    for s < p.length() {
        *intervals = append(*intervals, s)
        s += math.Min(p.min_len, p.min_angle/dt)
        p := s / p.length()
        du := p.bU + 2*p.cU*p + 3*p.dU*p*p
        dv := p.bV + 2*p.cV*p + 3*p.dV*p*p
        duu := math.Abs(2*p.cU + 6*p.dU*p)
        dvv := math.Abs(2*p.cV + 6*p.dV*p)

        dt = math.Abs(du) < 1e-8
        dt = math.Max(math.Atan(math.Abs(dt)), 1e-4)
    }
    *intervals = append(*intervals, p.length())
}

func (p *ODParamPoly3) getCurvature(soffset float64) float64 {
    const SampleDistance = 30.0
    i := 0
    for SampleDistance*float64(i) < p.length() {
        if soffset <= SampleDistance*float64(i) {
            length := SampleDistance
            if SampleDistance*float64(i) > p.length()-SampleDistance {
                length = p.length() - soffset
            }
            var mapPoint []struct{ x, y float64 }
            for n := 0.0; n < length; n += p.min_len {
                var x, y float64
                p.getGeom(SampleDistance*float64(i-1)+p.offset+n, &x, &y)
                mapPoint = append(mapPoint, struct{ x, y float64 }{x, y})
            }
            var radius float64
            p.FitCenterByLeastSquares(mapPoint, &radius)
            if radius < 5e-5 {
                radius = 0
            }
            return radius
        }
        i++
    }
    return 0.0
}

func (p *ODParamPoly3) getGeom(s float64, x, y *float64) {
    if p.length() < 1e-6 {
        return
    }
    s -= p.offset
    p := s / p.length()
    *x = p.aU + p.bU*p + p.cU*p*p + p.dU*p*p*p
    *y = p.aV + p.bV*p + p.cV*p*p + p.dV*p*p*p
    p.rotate(p.heading, x, y)
    *x += p.startX
    *y += p.startY
}

func (p *ODParamPoly3) getHeading(s float64) float64 {
    if p.length() < 1e-6 {
        return 0
    }
    s -= p.offset
    p := s / p.length()
    u := p.bU + 2*p.cU*p + 3*p.dU*p*p
    v := p.bV + 2*p.cV*p + 3*p.dV*p*p
    p.rotate(p.heading, &u, &v)
    return math.Atan2(v, u)
}

func (p *ODParamPoly3) FitCenterByLeastSquares(mapPoint []struct{ x, y float64 }, radius *float64) {
    if len(mapPoint) < 3 {
        *radius = 0.0
        return
    }
    var radiusVecSum float64

    for i := 0; i < len(mapPoint)-2; i++ {
        P1 := mapPoint[i]
        P2 := mapPoint[i+1]
        P3 := mapPoint[i+2]

        if P1.x == P2.x && P2.x == P3.x {
            *radius = 0
        } else {
            dis1 := math.Sqrt((P1.x-P2.x)*(P1.x-P2.x) + (P1.y-P2.y)*(P1.y-P2.y))
            dis2 := math.Sqrt((P1.x-P3.x)*(P1.x-P3.x) + (P1.y-P3.y)*(P1.y-P3.y))
            dis3 := math.Sqrt((P2.x-P3.x)*(P2.x-P3.x) + (P2.y-P3.y)*(P2.y-P3.y))
            dis := dis1*dis1 + dis3*dis3 - dis2*dis2

            if dis1 == 0 || dis2 == 0 || dis3 == 0 || dis == 0 {
                *radius = 0
            } else {
                cosA := dis / (2 * dis1 * dis3)
                if math.Abs(1-cosA*cosA) < 1e-6 || math.Abs(dis2) < 1e-6 {
                    *radius = 0
                } else {
                    sinA := math.Sqrt(1 - cosA*cosA)
                    *radius = 0.5 * dis2 / sinA
                    *radius = 1 / *radius
                }
            }
        }
        radiusVecSum += *radius
    }
    *radius = radiusVecSum / float64(len(mapPoint)-2)
}



func (o *ODOutline) Parse(element *xml.Element) bool {
    o.ID = StrCheckEmpty(element.Attr("id"))
    o.Closed = StrCheckEmpty(element.Attr("closed")) == "true"
    for _, corner := range element.Children {
        switch corner.Name.Local {
        case "cornerRoad":
            cornerPtr := &ODCornerRoad{}
            if cornerPtr.Parse(corner) {
                o.Corners = append(o.Corners, cornerPtr)
            }
        case "cornerLocal":
            cornerPtr := &ODCornerLocal{}
            if cornerPtr.Parse(corner) {
                o.Corners = append(o.Corners, cornerPtr)
            }
        }
    }
    return true
}

func (o *ODOutline) GetGeom(points *[]map[bool]ODXYZ) {
*points = nil
for _, corner := range o.Corners {
switch c := corner.(type) {
case *ODCornerRoad:
*points = append(*points, std(pair]bool, ODXYZ{c.S, c.T, c.Dz}))
case *ODCornerLocal:
*points = append(*points, std(pair]bool, ODXYZ{c.U, c.V, c.Z}))
}
}
}

func (c *ODCornerRoad) Parse(element *xml.Element) bool {
    c.ID = StrCheckEmpty(element.Attr("id"))
    c.S = StrCheckEmpty(element.Attr("s"))
    c.T = StrCheckEmpty(element.Attr("t"))
    c.Dz = StrCheckEmpty(element.Attr("dz"))
    c.Height = StrCheckEmpty(element.Attr("height"))
    return true
}

func (c *ODCornerRoad) SetXyz(data ODXYZ) {
    c.S = data.X
    c.T = data.Y
    c.Dz = data.Z
}

func (c *ODCornerRoad) Getxyz() ODXYZ {
    return ODXYZ{c.S, c.T, c.Dz}
}

func (c *ODCornerLocal) Parse(element *xml.Element) bool {
    c.ID = StrCheckEmpty(element.Attr("id"))
    c.U = StrCheckEmpty(element.Attr("u"))
    c.V = StrCheckEmpty(element.Attr("v"))
    c.Z = StrCheckEmpty(element.Attr("z"))
    c.Height = StrCheckEmpty(element.Attr("height"))
    return true
}

func (c *ODCornerLocal) Getxyz() ODXYZ {
    return ODXYZ{c.U, c.V, c.Z}
}

func (p *ODParkingSpace) Parse(element *xml.Element) bool {
    p.Access = StrCheckEmpty(element.Attr("access"))
    p.Restrictions = StrCheckEmpty(element.Attr("restrictions"))
    for _, marking := range element.Children {
        if marking.Name.Local == "marking" {
            m := struct {
                Side  string  `xml:"side,attr"`
                Type  string  `xml:"type,attr"`
                Width float64 `xml:"width,attr"`
                Color string  `xml:"color,attr"`
            }{}
            m.Side = StrCheckEmpty(marking.Attr("side"))
            m.Type = StrCheckEmpty(marking.Attr("type"))
            m.Width = StrCheckEmpty(marking.Attr("width"))
            m.Color = StrCheckEmpty(marking.Attr("color"))
            p.Markings = append(p.Markings, m)
        }
    }
    return true
}

func (r *ODRepeat) Parse(element *xml.Element) bool {
    r.S = StrCheckEmpty(element.Attr("s"))
    r.Length = StrCheckEmpty(element.Attr("length"))
    r.Distance = StrCheckEmpty(element.Attr("distance"))
    r.TStart = StrCheckEmpty(element.Attr("tStart"))
    r.TEnd = StrCheckEmpty(element.Attr("tEnd"))
    r.WidthStart = StrCheckEmpty(element.Attr("widthStart"))
    r.WidthEnd = StrCheckEmpty(element.Attr("widthEnd"))
    r.HeightStart = StrCheckEmpty(element.Attr("heightStart"))
    r.HeightEnd = StrCheckEmpty(element.Attr("heightEnd"))
    r.OffsetStart = StrCheckEmpty(element.Attr("zOffsetStart"))
    r.OffsetEnd = StrCheckEmpty(element.Attr("zOffsetEnd"))
    r.LengthStart = StrCheckEmpty(element.Attr("lengthStart"))
    r.LengthEnd = StrCheckEmpty(element.Attr("lengthEnd"))
    return true
}

func (o *ODObject) Parse(element *xml.Element) bool {
    o.Type = StrCheckEmpty(element.Attr("type"))
    o.Subtype = StrCheckEmpty(element.Attr("subtype"))
    o.Name = StrCheckEmpty(element.Attr("name"))
    o.ID = StrCheckEmpty(element.Attr("id"))
    o.S = StrCheckEmpty(element.Attr("s"))
    o.T = StrCheckEmpty(element.Attr("t"))
    o.ZOffset = StrCheckEmpty(element.Attr("zOffset"))
    o.Hdg = StrCheckEmpty(element.Attr("hdg"))
    o.Pitch = StrCheckEmpty(element.Attr("pitch"))
    o.Roll = StrCheckEmpty(element.Attr("roll"))
    o.Length = StrCheckEmpty(element.Attr("length"))
    o.Width = StrCheckEmpty(element.Attr("width"))
    o.Height = StrCheckEmpty(element.Attr("height"))
    o.Radius = StrCheckEmpty(element.Attr("radius"))
    for _, repeat := range element.Children {
        if repeat.Name.Local == "repeat" {
            r := &ODRepeat{}
            if r.Parse(repeat) {
                o.Repeats = append(o.Repeats, r)
            }
        }
    }
    if parkspace := element.FindElement("parkingSpace"); parkspace != nil {
        p := &ODParkingSpace{}
        if p.Parse(parkspace) {
            o.ParkingSpace = p
        }
    }
    for _, outline := range element.Children {
        if outline.Name.Local == "outline" {
            oPtr := &ODOutline{}
            if oPtr.Parse(outline) {
                o.Outlines = append(o.Outlines, oPtr)
            }
        }
    }
    o.UserData = make(map[string]string)
    for _, user := range element.Children {
        if user.Name.Local == "userData" {
            key := StrCheckEmpty(user.Attr("code"))
            value := StrCheckEmpty(user.Attr("value"))
            o.UserData[key] = value
        }
    }
    if markings := element.FindElement("markings"); markings != nil {
        o.Markings = &ODMarkings{}
        o.Markings.Parse(markings)
    }
    for _, outlines := range element.Children {
        if outlines.Name.Local == "outlines" {
            for _, outline := range outlines.Children {
                if outline.Name.Local == "outline" {
                    oPtr := &ODOutline{}
                    if oPtr.Parse(outline) {
                        o.Outlines = append(o.Outlines, oPtr)
                    }
                }
            }
        }
    }
    for _, validity := range element.Children {
        if validity.Name.Local == "validity" {
            fid := StrCheckEmpty(validity.Attr("fromLane"))
            tid := StrCheckEmpty(validity.Attr("toLane"))
            if fid != "" && tid != "" {
                from, _ := strconv.ParseInt(fid, 10, 64)
                to, _ := strconv.ParseInt(tid, 10, 64)
                if from > to {
                    from, to = to, from
                }
                for i := from; i <= to; i++ {
                    o.Validity = append(o.Validity, i)
                }
            }
        }
    }
    return true
}
func (o *ODObject) ParseTunnel(element *xml.StartElement) error {
    for _, attr := range element.Attr {
        switch attr.Name.Local {
        case "s":
            o.S = parseFloat(attr.Value)
        case "id":
            o.ID = attr.Value
        case "type":
            o.Type = attr.Value
        case "name":
            o.Name = attr.Value
        case "length":
            o.Length = parseFloat(attr.Value)
        }
    }

    o.UserData = make(map[string]string)
    for _, child := range element.Children() {
        if child.Name.Local == "userData" {
            for _, attr := range child.Attr {
                switch attr.Name.Local {
                case "code":
                    o.UserData[attr.Value] = StrCheckEmpty(child.Attr[1])
                }
            }
        }
    }

    return nil
}

func (o *ODObject) GetGeom(points *[]PairBoolODXYZ, getP func(float64, float64) (ODXYZ, float64)) error {
    if len(o.Outlines) > 0 {
        P, T := getP(o.S, o.T)
        for _, outline := range o.Outlines {
            var geom []ODXYZ
            for _, pt := range outline.Geom {
                np := o.transformPoint(pt, T, P)
                geom = append(geom, np)
            }
            *points = append(*points, PairBoolODXYZ{outline.IsClosed, geom})
        }
    } else if len(o.MPoints) > 0 {
        *points = make([]PairBoolODXYZ, 1)
        for _, pt := range o.MPoints {
            P, T := getP(pt.X, pt.Y)
            (*points)[0].Second = append((*points)[0].Second, P)
        }
    } else {
        *points = make([]PairBoolODXYZ, 1)
        P, T := getP(o.S, o.T)
        P.Z += o.ZOffset
        (*points)[0].Second = append((*points)[0].Second, P)
    }

    return nil
}

func (o *ODObject) GetRepeat(points *[]ODXYZWH, getP func(float64, float64) (ODXYZ, float64)) error {
    for _, repeat := range o.Repeats {
        if repeat.Length <= 0.0001 {
            return nil
        }
        ms := 0.5
        if repeat.Distance > 0.0001 {
            ms = repeat.Distance
        }
        s0 := 0.0
        for s0 <= (repeat.Length + 0.001) {
            s := repeat.S + s0
            t := repeat.TStart + s0*(repeat.TEnd-repeat.TStart)/repeat.Length
            w := repeat.WidthStart + s0*(repeat.WidthEnd-repeat.WidthStart)/repeat.Length
            h := repeat.HeightStart + s0*(repeat.HeightEnd-repeat.HeightStart)/repeat.Length
            zoffset := repeat.ZOffsetStart + s0*(repeat.ZOffsetEnd-repeat.ZOffsetStart)/repeat.Length
            p, T := getP(s, t)
            px := ODXYZWH{
                X: p.X,
                Y: p.Y,
                Z: p.Z + zoffset,
                W: w,
                H: h,
            }
            *points = append(*points, px)
            s0 += ms
        }
    }

    return nil
}

func (o *ODObject) GetBoundary(points *[]ODXYZ, getP func(float64, float64) (ODXYZ, float64)) error {
    *points = make([]ODXYZ, 0)
    P, T := getP(o.S, o.T)
    if o.Width < 1e-6 && o.Length < 1e-6 {
        *points = append(*points, ODXYZ{0, 0})
        if o.Height > 1e-6 {
            *points = append(*points, ODXYZ{0, 0, o.Height})
        }
    } else if o.Width > 1e-6 && o.Length < 1e-6 {
        *points = append(*points, ODXYZ{0, -o.Width * 0.5})
        *points = append(*points, ODXYZ{0, o.Width * 0.5})
    } else if o.Width < 1e-6 && o.Length > 1e-6 {
        *points = append(*points, ODXYZ{-o.Length * 0.5, 0})
        *points = append(*points, ODXYZ{o.Length * 0.5, 0})
    } else {
        *points = append(*points, ODXYZ{-o.Length * 0.5, -o.Width * 0.5})
        *points = append(*points, ODXYZ{o.Length * 0.5, -o.Width * 0.5})
        *points = append(*points, ODXYZ{o.Length * 0.5, o.Width * 0.5})
        *points = append(*points, ODXYZ{-o.Length * 0.5, o.Width * 0.5})
    }

    for i := range *points {
        (*points)[i] = o.transformPoint((*points)[i], T, P)
    }

    return nil
}

func (o *ODObject) GetRepeateBoundarys(points *[][]ODXYZ, getP func(float64, float64) (ODXYZ, float64)) error {
    tmpPoints := make([]ODXYZWHP, 0)
    for _, repeat := range o.Repeats {
        if repeat.Length <= 0.0001 {
            return nil
        }
        ms := 0.5
        if repeat.Distance > 0.0001 {
            ms = repeat.Distance
        }
        s0 := 0.0
        for s0 <= (repeat.Length + 0.001) {
            s := repeat.S + s0
            t := repeat.TStart + s0*(repeat.TEnd-repeat.TStart)/repeat.Length
            w := repeat.WidthStart + s0*(repeat.WidthEnd-repeat.WidthStart)/repeat.Length
            h := repeat.HeightStart + s0*(repeat.HeightEnd-repeat.HeightStart)/repeat.Length
            zoffset := repeat.ZOffsetStart + s0*(repeat.ZOffsetEnd-repeat.ZOffsetStart)/repeat.Length
            p, T := getP(s, t)
            px := ODXYZWHP{
                X: p.X,
                Y: p.Y,
                Z: p.Z + zoffset,
                W: w,
                H: h,
                P: T,
                L: repeat.Distance,
            }
            tmpPoints = append(tmpPoints, px)
            s0 += ms
        }
    }

    for _, it := range tmpPoints {
        var outPutPoints []ODXYZ
        P := it
        T := it.P
        if o.Width < 1e-6 && o.Length < 1e-6 {
            outPutPoints = append(outPutPoints, ODXYZ{0, 0})
            if o.Height > 1e-6 {
                outPutPoints = append(outPutPoints, ODXYZ{0, 0, o.Height})
            }
        } else if o.Width > 1e-6 && o.Length < 1e-6 {
            outPutPoints = append(outPutPoints, ODXYZ{0, -o.Width * 0.5})
            outPutPoints = append(outPutPoints, ODXYZ{0, o.Width * 0.5})
        } else if o.Width < 1e-6 && o.Length > 1e-6 {
            outPutPoints = append(outPutPoints, ODXYZ{-o.Length * 0.5, 0})
            outPutPoints = append(outPutPoints, ODXYZ{o.Length * 0.5, 0})
        } else {
            outPutPoints = append(outPutPoints, ODXYZ{-it.L * 0.5, -o.Width * 0.5})
            outPutPoints = append(outPutPoints, ODXYZ{it.L * 0.5, -o.Width * 0.5})
            outPutPoints = append(outPutPoints, ODXYZ{it.L * 0.5, o.Width * 0.5})
            outPutPoints = append(outPutPoints, ODXYZ{-it.L * 0.5, o.Width * 0.5})
        }
        for i := range outPutPoints {
            outPutPoints[i] = o.transformPoint(outPutPoints[i], T, P)
        }
        *points = append(*points, outPutPoints)
    }

    return nil
}

func (o *ODObject) transformPoint(p ODXYZ, T float64, P ODXYZ) ODXYZ {
    return ODXYZ{
        X: P.X + (math.Cos(T)*math.Cos(o.Hdg)*math.Cos(o.Pitch) - math.Sin(T)*math.Sin(o.Roll)*math.Sin(o.Pitch))*p.X +
            (math.Cos(T)*math.Cos(o.Hdg)*math.Sin(o.Pitch) + math.Sin(T)*math.Sin(o.Roll)*math.Cos(o.Pitch))*p.Y +
            (math.Cos(T)*math.Sin(o.Hdg) - math.Sin(T)*math.Cos(o.Roll))*p.Z,
        Y: P.Y + (math.Sin(T)*math.Cos(o.Hdg)*math.Cos(o.Pitch) + math.Cos(T)*math.Sin(o.Roll)*math.Sin(o.Pitch))*p.X +
            (math.Sin(T)*math.Cos(o.Hdg)*math.Sin(o.Pitch) - math.Cos(T)*math.Sin(o.Roll)*math.Cos(o.Pitch))*p.Y +
            (math.Sin(T)*math.Sin(o.Hdg) + math.Cos(T)*math.Cos(o.Roll))*p.Z,
        Z: P.Z + (-math.Sin(o.Pitch)*math.Cos(o.Roll))*p.X + (math.Cos(o.Pitch)*math.Cos(o.Roll))*p.Y + math.Sin(o.Roll)*p.Z,
    }
}
func (obj *ODObject) getRepeateFromOutlines() {
    if len(obj.Outlines) == 0 {
        return
    }
    outline := obj.Outlines[0]
    points := make([]ODXYZ, 0)
    for _, corner := range outline.Corners {
        points = append(points, corner.Xyz)
    }
    centerS, centerT := 0.0, 0.0
    for _, point := range points {
        centerS += point.X
        centerT += point.Y
    }
    centerS /= float64(len(points))
    centerT /= float64(len(points))

    index := 1
    for _, repeat := range obj.Repeats {
        if repeat.Length <= 0.0001 {
            return
        }
        ms := 0.5
        if repeat.Distance > 0.0001 {
            ms = repeat.Distance
        }
        for repeat.Distance*float64(index) <= repeat.Length {
            tmpOutline := ODOutline{}
            for _, point := range points {
                cornerPtr := ODCornerRoad{}
                tmp := point
                tmp.X = tmp.X + repeat.Distance*float64(index)
                cornerPtr.Xyz = tmp
                tmpOutline.Corners = append(tmpOutline.Corners, cornerPtr)
            }
            obj.Outlines = append(obj.Outlines, tmpOutline)
            index++
        }
    }
}

func (obj *ODObject) getPointFromUserData(str string) []ODXYZ {
    tmp := str
    tmp = strings.ReplaceAll(tmp, "[", "")
    tmp = strings.ReplaceAll(tmp, "]", "")
    tmp = strings.ReplaceAll(tmp, "#", "")
    result := strings.Split(tmp, "},")

    points := make([]ODXYZ, 0)
    for _, its := range result {
        its = strings.ReplaceAll(its, "{", "")
        its = strings.ReplaceAll(its, "}", "")
        its += ","
        tmpResult := strings.Split(its, ",")
        repeatDataVec := make(map[string]string)
        for _, it := range tmpResult {
            if pos := strings.Index(it, ":"); pos != -1 {
                key := it[:pos]
                value := it[pos+1:]
                repeatDataVec[key] = value
            }
        }
        dS, _ := strconv.ParseFloat(repeatDataVec["s"], 64)
        dT, _ := strconv.ParseFloat(repeatDataVec["t"], 64)
        pt := ODXYZ{X: dS, Y: dT, Z: 0}
        points = append(points, pt)
    }
    return points
}

func (signal *ODSignal) parse(element *xml.Element) bool {
    signal.Type = strCheckEmpty(element.Attr("type"))
    signal.Subtype = strCheckEmpty(element.Attr("subtype"))
    signal.Name = strCheckEmpty(element.Attr("name"))
    signal.ID = strCheckEmpty(element.Attr("id"))
    signal.Dynamic = strCheckEmpty(element.Attr("dynamic"))
    signal.Country = strCheckEmpty(element.Attr("country"))
    signal.Text = strCheckEmpty(element.Attr("text"))
    signal.S, _ = strconv.ParseFloat(element.Attr("s"), 64)
    signal.T, _ = strconv.ParseFloat(element.Attr("t"), 64)
    signal.ZOffset, _ = strconv.ParseFloat(element.Attr("zOffset"), 64)
    signal.HOffset, _ = strconv.ParseFloat(element.Attr("hOffset"), 64)
    signal.Pitch, _ = strconv.ParseFloat(element.Attr("pitch"), 64)
    signal.Roll, _ = strconv.ParseFloat(element.Attr("roll"), 64)
    signal.Hdg, _ = strconv.ParseFloat(element.Attr("hdg"), 64)
    signal.Value, _ = strconv.ParseFloat(element.Attr("value"), 64)
    signal.Width, _ = strconv.ParseFloat(element.Attr("width"), 64)
    signal.Height, _ = strconv.ParseFloat(element.Attr("height"), 64)

    signal.UserData = make(map[string]string)
    userDataElements := element.Find("userData")
    for _, user := range userDataElements {
        key := strCheckEmpty(user.Attr("code"))
        value := strCheckEmpty(user.Attr("value"))
        signal.UserData[key] = value
    }

    validityElements := element.Find("validity")
    for _, validity := range validityElements {
        fid := strCheckEmpty(validity.Attr("fromLane"))
        tid := strCheckEmpty(validity.Attr("toLane"))
        if fid != "" && tid != "" {
            from, _ := strconv.Atoi(fid)
            to, _ := strconv.Atoi(tid)
            if from > to {
                from, to = to, from
            }
            for i := from; i <= to; i++ {
                signal.ValidityLane = append(signal.ValidityLane, i)
            }
        }
    }

    return true
}

func (o *ODSignal) getGeom(points *vector.Vector, getP func(float64, float64, *ODXYZ, float64)) {
    var P ODXYZ
    var T float64
    getP(o.s, o.t, &P, T)
    P.z += o.zoffset
    points.Resize(1)
    points.Back().First = false
    points.Back().Second.Push_back(P)
}

func (o *ODSignal) getBoundary(points *vector.Vector, getP func(float64, float64, *ODXYZ, float64)) {
    points.Clear()
    var P ODXYZ
    var T float64
    getP(o.s, o.t, &P, T)
    points.Reserve(4)
    var pts vector.Vector
    if o.width > 1e-6 && o.height < 1e-6 {
        pts.Push_back(ODXYZ{0, -o.width * 0.5, 0})
        pts.Push_back(ODXYZ{0, o.width * 0.5, 0})
    } else if o.width < 1e-6 && o.height > 1e-6 {
        pts.Push_back(ODXYZ{0, 0, -o.height * 0.5})
        pts.Push_back(ODXYZ{0, 0, o.height * 0.5})
    } else if o.width > 1e-6 && o.height > 1e-6 {
        pts.Push_back(ODXYZ{0, -o.width * 0.5, -o.height * 0.5})
        pts.Push_back(ODXYZ{0, o.width * 0.5, -o.height * 0.5})
        pts.Push_back(ODXYZ{0, o.width * 0.5, o.height * 0.5})
        pts.Push_back(ODXYZ{0, -o.width * 0.5, o.height * 0.5})
    }

    for _, p := range pts {
        np := ODRPY(T).Mul(ODRPY(o.hOffset, o.roll, o.pitch).Mul(p)).Add(P).Add(ODXYZ{0, 0, o.zoffset})
        points.Push_back(np)
    }
}

func (o *ODRoad) parse(element *XMLElement) bool {
    // ELE_CKECK
    // parse road id
    o.rid = element.Int64Attribute("id")

    // parse length
    o.len = element.DoubleAttribute("length")

    // parse junction id
    o.jid = element.Int64Attribute("junction")
    if o.jid == -1 {
        o.jid = 0
    }

    // parse speed limit
    o.speed_limit = 0
    if element.FirstChildElement("type") != nil {
        if element.FirstChildElement("type").Attribute("type") != nil {
            o.road_type = element.FirstChildElement("type").Attribute("type")
        }
        if element.FirstChildElement("type").FirstChildElement("speed") != nil {
            speed_max := element.FirstChildElement("type").FirstChildElement("speed").DoubleAttribute("max")
            unit := StrCheckEmpty(element.FirstChildElement("type").FirstChildElement("speed").Attribute("unit"))
            if unit == "km/h" {
                speed_max *= 0.277778
            } else if unit == "mph" {
                speed_max *= 0.44704
            }

            o.speed_limit = int(math.Max(0, math.Round(speed_max*3.6)))
        }
    }

    // parse link info
    _link := element.FirstChildElement("link")
    if _link != nil {
        o.link_ptr = new(ODLink)
        o.link_ptr.parse(_link)
    } else {
        // fmt.Println("rid", o.rid)
    }
    // parse ref line info
    _plan_view := element.FirstChildElement("planView")
    if _plan_view != nil {
        o.ref_line.Clear()
        _geometry := _plan_view.FirstChildElement("geometry")
        var _sum_length float64 = 0
        for _geometry != nil {
            var _geom_ptr ODGeomPtr
            if _geometry.FirstChildElement("line") != nil {
                _geom_ptr = new(ODParamLine)
            } else if _geometry.FirstChildElement("arc") != nil {
                _geom_ptr = new(ODParamArc)
            } else if _geometry.FirstChildElement("spiral") != nil {
                _geom_ptr = new(ODGeomSpiral)
            } else if _geometry.FirstChildElement("poly3") != nil {
                _geom_ptr = new(ODGeomPoly3)
            } else if _geometry.FirstChildElement("paramPoly3") != nil {
                _geom_ptr = new(ODParamPoly3)
            } else {
                return false
            }
            _geom_ptr.parse(_geometry)
            // o.ref_line.Push_back(_geom_ptr)
            length := _geom_ptr.length()
            if length < 0.001 {
                _sum_length += length
            } else {
                _geom_ptr.setLength(_geom_ptr.length() + _sum_length)
                _sum_length = 0
                o.ref_line.Push_back(_geom_ptr)
            }
            _geometry = _geometry.NextSiblingElement("geometry")
        }
    }

    // parse elevation
    _elevation_profile := element.FirstChildElement("elevationProfile")
    if _elevation_profile != nil {
        o.elevation.Clear()
        _elevation := _elevation_profile.FirstChildElement("elevation")
        for _elevation != nil {
            ele := Polynomial3D{"elevation"}
            ele.parse(_elevation)
            o.elevation.Push_back(ele)
            _elevation = _elevation.NextSiblingElement("elevation")
        }
    }

    // parse lanes
    _lanes := element.FirstChildElement("lanes")
    if _lanes != nil {
        _lane_offset := _lanes.FirstChildElement("laneOffset")
        o.lane_offset.Clear()
        for _lane_offset != nil {
            poly3d := Polynomial3D{"laneOffset"}
            poly3d.parse(_lane_offset)
            // if (poly3d.offset() >= o.len)
            //  break
            o.lane_offset.Push_back(poly3d)
            _lane_offset = _lane_offset.NextSiblingElement("laneOffset")
        }

        o.sections.Clear()
        _section := _lanes.FirstChildElement("laneSection")
        var sid int = 0
        for _section != nil {
            // parse section offset
            var _s float64 = _section.DoubleAttribute("s")
            if _s >= o.len {
                break
            }
            // parse lane info in cur section
            var _cur_lanes ODLaneSection
            _left_group := _section.FirstChildElement("left")
            if _left_group != nil {
                _lane := _left_group.FirstChildElement("lane")
                for _lane != nil {
                    _cur_lane_ptr := new(ODLane)
                    if _cur_lane_ptr.parse(_lane) {
                        _cur_lanes.Push_back(_cur_lane_ptr)
                    }
                    _lane = _lane.NextSiblingElement("lane")
                }
            }
            _cen_group := _section.FirstChildElement("center")
            if _cen_group != nil {
                _lane := _cen_group.FirstChildElement("lane")
                if _lane != nil {
                    _cur_lane_ptr := new(ODLane)
                    _cur_lane_ptr.parse(_lane)
                    _cur_lanes.Push_back(_cur_lane_ptr)
                } else {
                    _cur_lane_ptr := new(ODLane)
                    _cur_lanes.Push_back(_cur_lane_ptr)
                }
            } else {
                _cur_lane_ptr := new(ODLane)
                _cur_lanes.Push_back(_cur_lane_ptr)
            }
            _right_group := _section.FirstChildElement("right")
            if _right_group != nil {
                _lane := _right_group.FirstChildElement("lane")
                for _lane != nil {
                    _cur_lane_ptr := new(ODLane)
                    if _cur_lane_ptr.parse(_lane) {
                        _cur_lanes.Push_back(_cur_lane_ptr)
                    }
                    _lane = _lane.NextSiblingElement("lane")
                }
            }
            /*else
            {
            	fmt.Println("ERROR can't find right lanes: roadid=", o.rid, " section=", sid)
            }*/

            sort(_cur_lanes.begin(), _cur_lanes.end(), func(a, b ODLanePtr) bool {
                return a.id() > b.id()
            })
            for ix := _cur_lanes.size() - 1; ix > 0; ix-- {
                if _cur_lanes.at(ix).id() == _cur_lanes.at(ix - 1).id() {
                    _cur_lanes.Erase(_cur_lanes.begin() + ix)
                }
            }

            o.sections.Push_back(std.Pair{_s, _cur_lanes})

            _section = _section.NextSiblingElement("laneSection")
            sid++
        }
    }

    // parse objects
    _objects := element.FirstChildElement("objects")
    if _objects != nil {
        o.objects.Clear()
        _object := _objects.FirstChildElement("object")
        for _object != nil {
            object_ptr := std.Make_shared(new(ODObject))
            if object_ptr.parse(_object) {
                o.objects.Push_back(object_ptr)
            }
            _object = _object.NextSiblingElement("object")
        }
        _tunnel := _objects.FirstChildElement("tunnel")
        for _tunnel != nil {
            object_ptr := std.Make_shared(new(ODObject))
            if object_ptr.parseTunnel(_tunnel) {
                o.objects.Push_back(object_ptr)
            }
            _tunnel = _tunnel.NextSiblingElement("object")
        }
    }

    // parse signals
    _signals := element.FirstChildElement("signals")
    if _signals != nil {
        o.signals.Clear()
        _signal := _signals.FirstChildElement("signal")
        for _signal != nil {
            signal_ptr := std.Make_shared(new(ODSignal))
            if signal_ptr.parse(_signal) {
                o.signals.Push_back(signal_ptr)
            }
            _signal = _signal.NextSiblingElement("signal")
        }

        o.signalReferences.Clear()
        reference := _signals.FirstChildElement("signalReference")
        for reference != nil {
            var sref SignalRef
            sref.id = StrCheckEmpty(reference.Attribute("id"))
            s := StrCheckEmpty(reference.Attribute("s"))
            t := StrCheckEmpty(reference.Attribute("t"))
            if s != "" {
                sref.s = std.Atof(s)
            }
            if t != "" {
                sref.t = std.Atof(t)
            }
            validity := reference.FirstChildElement("validity")
            for validity != nil {
                fid := StrCheckEmpty(validity.Attribute("fromLane"))
                tid := StrCheckEmpty(validity.Attribute("toLane"))
                if fid != "" && tid != "" {
                    from := std.Atoi(fid)
                    to := std.Atoi(tid)
                    if from > to {
                        from, to = to, from
                    }
                    for i := from; i <= to; i++ {
                        sref.laneids.Push_back(i)
                    }
                }
                validity = validity.NextSiblingElement("validity")
            }
            o.signalReferences[sref.id] = sref
            reference = reference.NextSiblingElement("signalReference")
        }
    }

    // parse surface
    _surface := element.FirstChildElement("surface")
    if _surface != nil {
        o.crgs.Clear()
        CRG := _surface.FirstChildElement("CRG")
        for CRG != nil {
            var _crgNode ODCrg
            _crgNode.parse(CRG)
            o.crgs.Push_back(_crgNode)
            CRG = CRG.NextSiblingElement("CRG")
        }
    }
    return true
}


func (road *ODRoad) Parse(element *xml.Element, west, south float64, area [][]txPoint) (bool, error) {
    // parse length
    road.Len = element.Attr("length").Value
    id := element.Attr("id").Value
    // getStartPoint
    var startPoint Point2d
    geometry := element.FindElement("planView").FindElement("geometry")
    for geometry != nil {
        if geometry.Attr("s").Value == "0" {
            startPoint.X = geometry.Attr("x").Value
            startPoint.Y = geometry.Attr("y").Value
            for _, iter := range area {
                // txPoint xx
                ret := map_util.PointToRectDistance(startPoint, Point2d(iter[0].X-west, iter[0].Y-south),
                    Point2d(iter[2].X-west, iter[2].Y-south))
                if ret == 0 {
                    return road.Parse(element)
                } else if ret < road.Len+MAX_LENGTH_ERROR {
                    return road.Parse(element)
                }
            }
        }
        geometry = geometry.NextElement("geometry")
    }
    return false, nil
}

func (road *ODRoad) Id() roadpkid {
    return road.Rid
}

func (road *ODRoad) JunctionId() junctionpkid {
    return road.Jid
}

func (road *ODRoad) GetSectionIdx(s float64) size_t {
    var ii size_t = 0
    for i, section := range road.Sections {
        if section.First > s {
            break
        }
        ii = i
    }
    return ii
}

func (road *ODRoad) GetCrgs() []ODCrg {
    return road.Crgs
}

func (road *ODRoad) Length() float64 {
    return road.Len
}

func (road *ODRoad) Speedlimit() int {
    return road.SpeedLimit
}

func (road *ODRoad) RoadGeom(geom *[]PairFloat64, interval *[]float64) error {
    *geom = nil
    if interval != nil && len(*interval) > 0 {
        *geom = make([]PairFloat64, len(*interval))
        index := 0
        for i := 0; i < len(*interval); {
            if index+1 < len(road.RefLine) && (*interval)[i] > road.RefLine[index+1].Offset() {
                index++
            } else {
                var x, y float64
                road.RefLine[index].GetGeom((*interval)[i], &x, &y)
                if math.IsNaN(x) || math.IsNaN(y) {
                    return errors.New("invalid geometry")
                }
                (*geom)[i] = PairFloat64{x, y}
                i++
            }
        }
    } else {
        for _, geomPtr := range road.RefLine {
            var curGeom []PairFloat64
            geomPtr.GetGeom(&curGeom)
            if len(curGeom) == 0 {
                continue
            }
            for i := range curGeom {
                curGeom[i].First += geomPtr.StartX()
                curGeom[i].Second += geomPtr.StartY()
            }
            if len(*geom) == 0 {
                *geom = append(*geom, curGeom...)
            } else {
                *geom = append(*geom, curGeom[1:]...)
            }
        }
    }
    return nil
}

func (road *ODRoad) RoadTangent(tangent *[]PairFloat64, interval *[]float64) error {
    *tangent = nil
    if interval != nil && len(*interval) > 0 {
        *tangent = make([]PairFloat64, len(*interval))
        index := 0
        for i := 0; i < len(*interval); {
            if index+1 < len(road.RefLine) && (*interval)[i] > road.RefLine[index+1].Offset() {
                index++
            } else {
                var x, y float64
                road.RefLine[index].GetTangent((*interval)[i], &x, &y)
                (*tangent)[i] = PairFloat64{x, y}
                i++
            }
        }
    } else {
        for _, geomPtr := range road.RefLine {
            var curTangent []PairFloat64
            geomPtr.GetTangent(&curTangent)
            if len(curTangent) == 0 {
                continue
            }
            if len(*tangent) == 0 {
                *tangent = append(*tangent, curTangent...)
            } else {
                *tangent = append(*tangent, curTangent[1:]...)
            }
        }
    }
    return nil
}

func (road *ODRoad) RoadNormal(normal *[]PairFloat64, interval *[]float64) error {
    *normal = nil
    if interval != nil && len(*interval) > 0 {
        *normal = make([]PairFloat64, len(*interval))
        index := 0
        for i := 0; i < len(*interval); {
            if index+1 < len(road.RefLine) && (*interval)[i] >= road.RefLine[index+1].Offset() {
                index++
            } else {
                var x, y float64
                road.RefLine[index].GetNormal((*interval)[i], &x, &y)
                (*normal)[i] = PairFloat64{x, y}
                i++
            }
        }
    } else {
        for _, geomPtr := range road.RefLine {
            var curNormal []PairFloat64
            geomPtr.GetNormal(&curNormal)
            if len(curNormal) == 0 {
                continue
            }
            if len(*normal) == 0 {
                *normal = append(*normal, curNormal...)
            } else {
                *normal = append(*normal, curNormal[1:]...)
            }
        }
    }
    return nil
}

func (road *ODRoad) RoadInterval(interval *[]float64) error {
    *interval = nil
    for _, geomPtr := range road.RefLine {
        var curInterval []float64
        geomPtr.GetInterval(&curInterval)
        if len(curInterval) == 0 {
            continue
        }
        for i := range curInterval {
            curInterval[i] += geomPtr.Offset()
        }
        if len(*interval) == 0 {
            *interval = append(*interval, curInterval...)
        } else {
            *interval = append(*interval, curInterval[1:]...)
        }
    }
    return nil
}
func (r *ODRoad) roadCurvature(startx, length, radios []float64) {
    startx = startx[:0]
    length = length[:0]
    radios = radios[:0]
    for _, geomPtr := range r.ref_line {
        if geomPtr.getName() == "line" || geomPtr.getName() == "arc" {
            startx = append(startx, geomPtr.getOffset())
            length = append(length, geomPtr.getLength())
            radios = append(radios, geomPtr.getCurvature(0.0))
        } else if geomPtr.getName() == "paramPoly3" {
            const SampleDistance = 30.0
            i := 0
            var lastRadios float64
            var startXTmp, lengthTmp float64
            for SampleDistance*float64(i) < geomPtr.getLength() {
                radius := geomPtr.getCurvature(SampleDistance * float64(i))
                startXTmp = SampleDistance * float64(i)
                lengthTmp = SampleDistance
                if SampleDistance*float64(i) > geomPtr.getLength()-SampleDistance {
                    lengthTmp = geomPtr.getLength() - SampleDistance*float64(i)
                }
                startx = append(startx, geomPtr.getOffset()+startXTmp)
                length = append(length, lengthTmp)
                radios = append(radios, radius)
                i++
            }
        }
    }
}

func (r *ODRoad) roadRef(ref []PairDouble, intervals []float64) {
    ref = ref[:0]

    if len(r.lane_offset) == 0 {
        r.roadGeom(ref, intervals)
        return
    }

    var interval []float64
    if intervals != nil && len(intervals) > 0 {
        interval = intervals
    } else {
        r.roadInterval(interval)
    }

    var offset []float64
    index := 0
    for i := 0; i < len(interval); {
        if index+1 < len(r.lane_offset) && interval[i] > r.lane_offset[index+1].offset {
            index++
        } else {
            dis := interval[i] - r.lane_offset[index].offset
            offset = append(offset, r.lane_offset[index].value(dis))
            i++
        }
    }

    var geom, normal []PairDouble
    r.roadGeom(geom, &interval)
    r.roadNormal(normal, &interval)

    ref = make([]PairDouble, len(geom))
    for i := 0; i < len(geom); i++ {
        ref[i].first = geom[i].first + offset[i]*normal[i].first
        ref[i].second = geom[i].second + offset[i]*normal[i].second
    }
}

func (r *ODRoad) roadEle(ele []float64, intervals []float64) {
    ele = ele[:0]

    if len(r.elevation) == 0 {
        return
    }

    var interval []float64
    if intervals != nil && len(intervals) > 0 {
        interval = intervals
    } else {
        r.roadInterval(interval)
    }

    index := 0
    for i := 0; i < len(interval); {
        if index+1 < len(r.elevation) && interval[i] > r.elevation[index+1].offset {
            index++
        } else {
            dis := interval[i] - r.elevation[index].offset
            ele = append(ele, r.elevation[index].value(dis))
            i++
        }
    }
}

func (r *ODRoad) roadEleControlPoint(ele [][]float64, length float64, mapversion string) {
    ele = ele[:0]
    var a, b, c, d, s float64
    index := 0
    for _, it := range r.elevation {
        it.getParam(&a, &b, &c, &d, &s)
        var eleLength float64
        if index == len(r.elevation)-1 {
            eleLength = length - it.offset
        } else {
            eleLength = r.elevation[index+1].offset - s
        }
        if (math.Abs(c) < 1e-6 && math.Abs(d) < 1e-6) || mapversion == "tadsim v2.0" {
            tmp := []float64{s, it.value(0), it.slope(0)}
            ele = append(ele, tmp)
        } else {
            for i := 0; i < 4; i++ {
                percent := float64(i) / 5.0 * eleLength
                tmp := []float64{percent + s, it.value(percent), it.slope(percent)}
                ele = append(ele, tmp)
            }
        }
        if index == len(r.elevation)-1 {
            tmp := []float64{length, it.value(eleLength), it.slope(eleLength)}
            ele = append(ele, tmp)
        }
        index++
    }
}
func (road *ODRoad) RoadSlope(startx, length, slope *[]float64) {
    for i := 0; i < len(road.elevation); i++ {
        eleItr := &road.elevation[i]
        var _a, _b, _c, _d, _s float64
        eleItr.GetParam(&_a, &_b, &_c, &_d, &_s)
        var _length float64
        if i != len(road.elevation)-1 {
            var _aa, _bb, _cc, _dd, _ss float64
            road.elevation[i+1].GetParam(&_aa, &_bb, &_cc, &_dd, &_ss)
            _length = _ss - _s
        } else {
            _length = road.Length() - _s
        }
        if math.Abs(_c) < 1e-6 && math.Abs(_d) < 1e-6 {
            *startx = append(*startx, _s)
            *length = append(*length, _length)
            *slope = append(*slope, _b)
            continue
        } else {
            const SampleDistance = 30.0
            i := 0
            var startx_tmp, length_tmp float64
            for SampleDistance*float64(i) < _length {
                var dis []float64
                startx_tmp = SampleDistance * float64(i)
                length_tmp = SampleDistance
                if SampleDistance*float64(i) > _length-SampleDistance {
                    length_tmp = _length - SampleDistance*float64(i)
                }
                dis = append(dis, startx_tmp)
                dis = append(dis, startx_tmp+length_tmp)

                var value []float64
                eleItr.SampleValue(dis, &value)
                slope_tmp := (value[1] - value[0]) / length_tmp
                *startx = append(*startx, _s+startx_tmp)
                *length = append(*length, length_tmp)
                *slope = append(*slope, slope_tmp)
                i++
            }
        }
    }
}

func (road *ODRoad) RoadControlPoint(controltype *string, points *[][]float64) {
    for _, geom_ptr := range road.ref_line {
        if geom_ptr.GetName() == "line" {
            var pt1 []float64
            pt1 = append(pt1, geom_ptr.StartX())
            pt1 = append(pt1, geom_ptr.StartY())
            pt1 = append(pt1, geom_ptr.GetHeading(0))
            *points = append(*points, pt1)
            var pt2 []float64
            var x, y float64
            geom_ptr.GetGeom(geom_ptr.Length(), &x, &y)
            pt2 = append(pt2, x)
            pt2 = append(pt2, y)
            pt2 = append(pt2, geom_ptr.GetHeading(geom_ptr.Length()))
            *points = append(*points, pt2)
            *controltype = "line"
        } else if geom_ptr.GetName() == "arc" {
            var pt1 []float64
            pt1 = append(pt1, geom_ptr.StartX())
            pt1 = append(pt1, geom_ptr.StartY())
            pt1 = append(pt1, geom_ptr.GetHeading(0))
            *points = append(*points, pt1)
            var pt2 []float64
            var x, y float64
            s := geom_ptr.Length() + geom_ptr.Offset()
            geom_ptr.GetGeom(s, &x, &y)
            pt2 = append(pt2, x)
            pt2 = append(pt2, y)
            pt2 = append(pt2, geom_ptr.GetHeading(s))
            *points = append(*points, pt2)
            *controltype = "arc"
        } else if geom_ptr.GetName() == "paramPoly3" {
            if len(*points) == 0 {
                var pt1 []float64
                pt1 = append(pt1, geom_ptr.StartX())
                pt1 = append(pt1, geom_ptr.StartY())
                pt1 = append(pt1, geom_ptr.GetHeading(0))
                *points = append(*points, pt1)
            }
            var pt2 []float64
            var x, y float64
            s := geom_ptr.Length() + geom_ptr.Offset()
            geom_ptr.GetGeom(s, &x, &y)
            pt2 = append(pt2, x)
            pt2 = append(pt2, y)
            pt2 = append(pt2, geom_ptr.GetHeading(s))
            *points = append(*points, pt2)
            *controltype = "catmullrom"
        } else {
            *controltype = "none"
        }
    }
    if *controltype == "catmullrom" {
        var pt1 []float64
        pt1 = append(pt1, 2*(*points)[0][0]-(*points)[1][0])
        pt1 = append(pt1, 2*(*points)[0][1]-(*points)[1][1])
        pt1 = append(pt1, (*points)[0][2])
        *points = append([][]float64{pt1}, *points...)
        var pt2 []float64
        pt2 = append(pt2, 2*(*points)[len(*points)-1][0]-(*points)[len(*points)-2][0])
        pt2 = append(pt2, 2*(*points)[len(*points)-1][1]-(*points)[len(*points)-2][1])
        pt2 = append(pt2, (*points)[len(*points)-1][2])
        *points = append(*points, pt2)
    }
}

func (road *ODRoad) Predecessor(links *[]Pair[lanepkid, lanepkid])  {
    if road.link_ptr == nil {
        return
    }
    if len(road.sections) == 0 {
        return
    }
    _front_sec := road.sections[0].second
    _from_rid := road.link_ptr.fromRoadId()

    if _from_rid == ROAD_PKID_INVALID {
        return
    }

    *links = []Pair[lanepkid, lanepkid]{}
    for _, lane_ptr := range _front_sec {
        if lane_ptr.fromLId() == LANE_PKID_INVALID {
            continue
        } else {
            *links = append(*links, Pair[lanepkid, lanepkid]{lane_ptr.fromLId(), lane_ptr.id()})
        }
    }
}

func (road *ODRoad) GetT(x, y, s float64, t *float64) {
    var ref_x, ref_y float64
    road.roadGeom(s, &ref_x, &ref_y)
    p1 := Point3d{ref_x, ref_y, 0}
    p2 := Point3d{x, y, 0}
    *t = map_util.DistanceBetweenPoints(p1, p2, false)
}

func (road *ODRoad) GetRoadType() string {
    return road.road_type
}

func (road *ODRoad) Successor(links *[]Pair[lanepkid, lanepkid])  {
    if road.link_ptr == nil {
        return
    }
    if len(road.sections) == 0 {
        return
    }
    _back_sec := road.sections[len(road.sections)-1].second
    _to_rid := road.link_ptr.toRoadId()

    if _to_rid == ROAD_PKID_INVALID {
        return
    }

    *links = []Pair[lanepkid, lanepkid]{}
    for _, lane_ptr := range _back_sec {
        if lane_ptr.toLId() == LANE_PKID_INVALID {
            continue
        } else {
            *links = append(*links, Pair[lanepkid, lanepkid]{lane_ptr.id(), lane_ptr.toLId()})
        }
    }
}

func (road *ODRoad) Links(links *[][]lanepkid)  {
    if road.link_ptr == nil {
        return
    }
    if len(road.sections) == 0 {
        return
    }
    if road.link_ptr.toRoadId() == ROAD_PKID_INVALID || road.link_ptr.fromRoadId() == ROAD_PKID_INVALID {
        return
    }
    _front_sec := road.sections[0].second
    for _, lane_ptr := range _front_sec {
        if lane_ptr.fromLId() == LANE_PKID_INVALID || lane_ptr.toLId() == LANE_PKID_INVALID {
            continue
        }
        var link []lanepkid
        link = append(link, lane_ptr.fromLId())
        link = append(link, lane_ptr.id())
        link = append(link, lane_ptr.toLId())

        for i := 1; i < len(road.sections); i++ {
            nx_sec := road.sections[i].second
            for _, nxlane_ptr := range nx_sec {
                if nxlane_ptr.fromLId() == LANE_PKID_INVALID || nxlane_ptr.toLId() == LANE_PKID_INVALID {
                    continue
                }
                if nxlane_ptr.fromLId() == link[len(link)-2] && nxlane_ptr.id() == link[len(link)-1] {
                    link = append(link, nxlane_ptr.toLId())
                    break
                }
            }
        }
        if len(link) == len(road.sections)+2 {
            *links = append(*links, link)
        }
    }
}

func (road *ODRoad) SectionSize() int {
    return len(road.sections)
}

func (road *ODRoad) GetSectionRange(index int, begin, end *float64) error {
    if index >= len(road.sections) {
        return errors.New("get section range error, index range error")
    }

    *begin = road.sections[index].first
    if index+1 < len(road.sections) {
        *end = road.sections[index+1].first
    } else {
        *end = road.len
    }
    return nil
}

func (r *ODRoad) getSection(index int, section *ODLaneSection) error {
    if index >= len(r.sections) {
        return errors.New("get section error, index range error")
    }
    *section = r.sections[index]
    return nil
}

func (r *ODRoad) preRoadId() roadpkid {
    if r.linkPtr == nil {
        return ROAD_PKID_INVALID
    }
    return r.linkPtr.fromRoadIdFunc()
}

func (r *ODRoad) clearPreRoadI() {
    if r.linkPtr == nil {
        return
    }
    r.linkPtr.clearFromRoadFunc()
}

func (r *ODRoad) preRoadType() ODLinkType {
    if r.linkPtr == nil {
        return ROAD
    }
    return r.linkPtr.fromRoadTypeFunc()
}

func (r *ODRoad) preRoadCont() ODConType {
    if r.linkPtr == nil {
        return START
    }
    return r.linkPtr.fromRoadContFunc()
}

func (r *ODRoad) succRoadId() roadpkid {
    if r.linkPtr == nil {
        return ROAD_PKID_INVALID
    }
    return r.linkPtr.toRoadIdFunc()
}

func (r *ODRoad) clearSuccRoadI() {
    if r.linkPtr == nil {
        return
    }
    r.linkPtr.clearToRoadFunc()
}

func (r *ODRoad) succRoadType() ODLinkType {
    if r.linkPtr == nil {
        return ROAD
    }
    return r.linkPtr.toRoadTypeFunc()
}

func (r *ODRoad) succRoadCont() ODConType {
    if r.linkPtr == nil {
        return START
    }
    return r.linkPtr.toRoadContFunc()
}

func (r *ODRoad) getRefGeo(s float64) ODGeomPtr {
    if len(r.refLine) == 0 {
        return nil
    }
    for _, geomPtr := range r.refLine {
        if s < geomPtr.offsetFunc()+geomPtr.lengthFunc() {
            return geomPtr
        }
    }
    return r.refLine[len(r.refLine)-1]
}

func (r *ODRoad) roadGeom(s float64, x *float64, y *float64) {
    geomPtr := r.getRefGeo(s)
    if geomPtr != nil {
        geomPtr.getGeomFunc(s, x, y)
    }
}

func (r *ODRoad) getHeading(s float64) float64 {
    geomPtr := r.getRefGeo(s)
    if geomPtr != nil {
        return geomPtr.getHeadingFunc(s)
    }
    return 0.0
}

func (r *ODRoad) roadNormal(s float64, x *float64, y *float64) {
    geomPtr := r.getRefGeo(s)
    if geomPtr != nil {
        geomPtr.getNormalFunc(s, x, y)
    }
}

func (r *ODRoad) getEle(s float64) float64 {
    if len(r.elevation) == 0 {
        return 0.0
    }
    var index int
    for i := 1; i < len(r.elevation); i++ {
        if s < r.elevation[i].offsetFunc() {
            break
        }
        index = i
    }
    dis := s - r.elevation[index].offsetFunc()
    return r.elevation[index].valueFunc(dis)
}

func (road *ODRoad) getObjects(objs *[]Object) {
    getP := func(s, t float64, P *ODXYZ, T *float64) {
        var x, y, z, dx, dy float64
        roadGeom(s, &x, &y)
        roadNormal(s, &dx, &dy)
        *T = getHeading(s)
        P.Z = getEle(s)
        P.X = x + t*dx
        P.Y = y + t*dy
    }

    *objs = []Object{}
    for _, obj_ptr := range road.objects {
        var obj Object
        obj.St = "OBJECT"
        {
            var P ODXYZ
            var T float64
            getP(obj_ptr.S, obj_ptr.T, &P, &T)
            P.Z += obj_ptr.Zoffset
            obj.X = P.X
            obj.Y = P.Y
            obj.Z = P.Z
        }
        obj.Id = obj_ptr.Id
        obj.S = obj_ptr.S
        obj.T = obj_ptr.T
        obj.Len = obj_ptr.Len
        obj.Wid = obj_ptr.Wid
        obj.Hei = obj_ptr.Hei
        obj.Pitch = obj_ptr.Pitch
        obj.Roll = obj_ptr.Roll
        obj.Yaw = obj_ptr.Hdg + getHeading(obj_ptr.S)
        obj.Hdg = obj_ptr.Hdg
        obj.Name = obj_ptr.Name
        obj.Type = obj_ptr.Type
        obj.Subtype = obj_ptr.Subtype
        obj.Zoffset = obj_ptr.Zoffset

        obj_ptr.getGeom(&obj.Geom, getP)
        obj_ptr.getRepeat(&obj.Repeat, getP)

        if len(obj_ptr.getRepeatData()) > 0 {
            tmp := obj_ptr.getRepeatData()[0]
            obj.RepetaData = ""
            obj.RepetaData += "s:" + strconv.FormatFloat(tmp.S, 'f', -1, 64) + ";"
            obj.RepetaData += "length:" + strconv.FormatFloat(tmp.Length, 'f', -1, 64) + ";"
            obj.RepetaData += "distance:" + strconv.FormatFloat(tmp.Distance, 'f', -1, 64) + ";"
            obj.RepetaData += "tStart:" + strconv.FormatFloat(tmp.TStart, 'f', -1, 64) + ";"
            obj.RepetaData += "tEnd:" + strconv.FormatFloat(tmp.TEnd, 'f', -1, 64) + ";"
            obj.RepetaData += "widthStart:" + strconv.FormatFloat(tmp.WidthStart, 'f', -1, 64) + ";"
            obj.RepetaData += "widthEnd:" + strconv.FormatFloat(tmp.WidthEnd, 'f', -1, 64) + ";"
            obj.RepetaData += "heightStart:" + strconv.FormatFloat(tmp.HeightStart, 'f', -1, 64) + ";"
            obj.RepetaData += "heightEnd:" + strconv.FormatFloat(tmp.HeightEnd, 'f', -1, 64) + ";"
            obj.RepetaData += "zOffsetStart:" + strconv.FormatFloat(tmp.ZOffsetStart, 'f', -1, 64) + ";"
            obj.RepetaData += "zOffsetEnd:" + strconv.FormatFloat(tmp.ZOffsetEnd, 'f', -1, 64) + ";"
            obj.RepetaData += "lengthStart:" + strconv.FormatFloat(tmp.LengthStart, 'f', -1, 64) + ";"
            obj.RepetaData += "lengthEnd:" + strconv.FormatFloat(tmp.LengthEnd, 'f', -1, 64) + ";"
        }
        if obj_ptr.getMarking() != nil && len(obj_ptr.getMarking().Markings) > 0 {
            obj.Markwidth = obj_ptr.getMarking().Markings[0].Width
            obj.Markcolor = obj_ptr.getMarking().Markings[0].Color
        }

        park := obj_ptr.getParkingSpace()
        if park != nil {
            obj.St = "PARKING"
            obj.Access = park.Access
            obj.Restrictions = park.Restrictions
            for _, mark := range park.Markings {
                var pmark ParkingMark
                pmark.Side = mark.Side
                pmark.Type = mark.Type
                pmark.Width = mark.Width
                pmark.Color = mark.Color
                obj.Parkingmark = append(obj.Parkingmark, pmark)
            }
            if obj_ptr.getIsOutLine() {
                if len(obj.Repeat) > 0 {
                    obj_ptr.getRepeateFromOutlines()
                    obj.Geom = nil
                    obj_ptr.getGeom(&obj.Geom, getP)
                }
            }
            if !obj_ptr.getIsOutLines() {
                if len(obj.Repeat) > 0 {
                    var geomDatas [][]ODXYZ
                    obj_ptr.getRepeateBoundarys(&geomDatas, getP)
                    obj.Geom = nil
                    for _, it := range geomDatas {
                        obj.Geom = append(obj.Geom, it)
                    }
                } else {
                    var boundary []ODXYZ
                    obj_ptr.getBoundary(&boundary, getP)
                    obj.Geom = nil
                    obj.Geom = append(obj.Geom, boundary)
                }
            }
        }
        obj.UserData = obj_ptr.UserData
        obj.ValidityLane = obj_ptr.ValidityLane

        *objs = append(*objs, obj)
    }
    for _, sign_ptr := range road.signals {
        var obj Object
        obj.St = sign_ptr.Dynamic
        obj.Id = sign_ptr.Id
        obj.Wid = sign_ptr.Width
        obj.Hei = sign_ptr.Height
        obj.Pitch = sign_ptr.Pitch
        obj.Roll = sign_ptr.Roll
        obj.Yaw = sign_ptr.HOffset + getHeading(sign_ptr.S)
        obj.S = sign_ptr.S
        obj.T = sign_ptr.T
        obj.Zoffset = sign_ptr.Zoffset
        obj.Hdg = sign_ptr.HOffset
        if sign_ptr.Orientation == "-" {
            obj.Yaw += 3.1415926535897932384626433832795
        }
        obj.Name = sign_ptr.Name
        obj.Type = sign_ptr.Type
        obj.Subtype = sign_ptr.Subtype
        sign_ptr.getGeom(&obj.Geom, getP)
        {
            var P ODXYZ
            var T float64
            getP(sign_ptr.S, sign_ptr.T, &P, &T)
            P.Z += sign_ptr.Zoffset
            obj.X = P.X
            obj.Y = P.Y
            obj.Z = P.Z
        }
        obj.UserData = sign_ptr.UserData
        obj.ValidityLane = sign_ptr.ValidityLane
        *objs = append(*objs, obj)
    }
}

func (ctl *ODController) parse(element *xml.Element) bool {
    ctl.Cid = element.Attr("id").Int64()
    ctl_elem := element.FirstChild("control")
    for ctl_elem != nil {
        id := ctl_elem.Attr("signalId").Int64()
        ctl.SignalIds = append(ctl.SignalIds, id)
        ctl_elem = ctl_elem.NextSibling("control")
    }
    return true
}

func (od *ODController) ID() controllerkid {
    return od.cid
}

func (od *ODController) GetSignals() []objectpkid {
    return od.signalIds
}


func (od *ODMarkings) Parse(element *xml.Element) bool {
    for _, marking := range element.FindAll("marking") {
        tmp := Marking{
            Width: marking.Float64Attr("width"),
            Color: marking.StringAttr("color"),
        }
        od.Markings = append(od.Markings, tmp)
    }
    return true
}

func (od *ODCrg) Parse(element *xml.Element) bool {
    if p := element.StringAttr("file"); p != "" {
        od.File = p
    }
    if p := element.StringAttr("orientation"); p != "" {
        od.Orientation = p
    }
    if p := element.StringAttr("mode"); p != "" {
        od.Mode = p
    }
    if p := element.StringAttr("purpose"); p != "" {
        od.Purpose = p
    }
    if p := element.StringAttr("sOffset"); p != "" {
        od.SOffset = p
    }
    if p := element.StringAttr("tOffset"); p != "" {
        od.TOffset = p
    }
    if p := element.StringAttr("zOffset"); p != "" {
        od.ZOffset = p
    }
    if p := element.StringAttr("hOffset"); p != "" {
        od.HOffset = p
    }
    if p := element.StringAttr("zScale"); p != "" {
        od.ZScale = p
    }
    return true
}

func (od *ODCrg) GetFile() string {
    return od.File
}

func (od *ODCrg) GetOrientation() string {
    return od.Orientation
}

func (od *ODCrg) GetMode() string {
    return od.Mode
}

func (od *ODCrg) GetPurpose() string {
    return od.Purpose
}

func (od *ODCrg) GetSOffset() string {
    return od.SOffset
}

func (od *ODCrg) GetTOffset() string {
    return od.TOffset
}

func (od *ODCrg) GetZOffset() string {
    return od.ZOffset
}

func (od *ODCrg) GetZScale() string {
    return od.ZScale
}

func (od *ODCrg) GetHOffset() string {
    return od.HOffset
}



// ===>?> odp
func ODPRoadInterval(road *openDrive.OpenDRIVERoad)[]float64{

    for i, geometry := range road.PlanView.Geometry {
        geometry.

    }

}
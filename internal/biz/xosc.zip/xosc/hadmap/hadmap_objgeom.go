package hadmap

import "unsafe"

type txObjectGeom struct {
    instancePtr *GeomData
}
type GeomData struct {
    data    tx_object_geom_t
    geomPtr *txLineCurve
    axisPtr *txLineCurve
}

type tx_object_geom_t struct {
    pkid      objectgeompkid
    Type      uint32 // OBJECT_GEOMETRY_TYPE
    srs       uint32
    dimension uint32
    style     uint32 // OBJECT_STYLE
    color     uint32
    text      [64]byte
    geom      Points5d
    image     []uint8
}

func newTxObjectGeomT() *tx_object_geom_t {
    t := &tx_object_geom_t{}
    size := unsafe.Sizeof(t.geom) - unsafe.Sizeof(t)
    for i := 0; i < int(size); i++ {
        *(*byte)(unsafe.Pointer(uintptr(unsafe.Pointer(t)) + uintptr(i))) = 0
    }
    t.pkid = OBJ_GEOM_PKID_INVALID
    return t
}

func (t *tx_object_geom_t) copyFrom(other *tx_object_geom_t) {
    t.pkid = other.pkid
    t.Type = other.Type
    t.srs = other.srs
    t.dimension = other.dimension
    t.style = other.style
    t.color = other.color
    copy(t.text[:], other.text[:])
    t.geom = other.geom
    t.image = make([]uint8, len(other.image))
    copy(t.image, other.image)
}

func (t *tx_object_geom_t) assignFrom(other *tx_object_geom_t) {
    t.pkid = other.pkid
    t.Type = other.Type
    t.srs = other.srs
    t.dimension = other.dimension
    t.style = other.style
    t.color = other.color
    copy(t.text[:], other.text[:])
    t.geom = make(Points5d, len(other.geom))
    copy(t.geom, other.geom)
    t.image = make([]uint8, len(other.image))
    copy(t.image, other.image)
}

func NewTxObjectGeom() *txObjectGeom {
    return &txObjectGeom{instancePtr: &GeomData{}}
}

func (g *txObjectGeom) GetTxData() txObjectGeomData {
    return g.instancePtr.data
}

func (g *txObjectGeom) GetId() objectGeomPKID {
    return g.instancePtr.data.pkid
}

func (g *txObjectGeom) GetType() OBJECT_GEOMETRY_TYPE {
    return OBJECT_GEOMETRY_TYPE(g.instancePtr.data.Type)
}

func (g *txObjectGeom) GetStyle() OBJECT_STYLE {
    return OBJECT_STYLE(g.instancePtr.data.style)
}

func (g *txObjectGeom) GetGeometry() *txCurve {
    return (*txCurve)(unsafe.Pointer(g.instancePtr.geomPtr))
}

func (g *txObjectGeom) GetMainAxis() *txCurve {
    return (*txCurve)(unsafe.Pointer(g.instancePtr.axisPtr))
}

func (g *txObjectGeom) GetColor() uint32 {
    return g.instancePtr.data.color
}

func (g *txObjectGeom) GetGeomText() string {
    return g.instancePtr.data.text
}

func (g *txObjectGeom) GetGeom5D() PointVec {
    var ret PointVec
    for _, it := range g.instancePtr.data.geom {
        ret = append(ret, txPoint{it.x, it.y, it.z})
    }
    return ret
}

func (g *txObjectGeom) SetId(id objectGeomPKID) *txObjectGeom {
    g.instancePtr.data.pkid = id
    return g
}

func (g *txObjectGeom) SetType(type_ OBJECT_GEOMETRY_TYPE) *txObjectGeom {
    g.instancePtr.data.Type = int(type_)
    return g
}

func (g *txObjectGeom) SetStyle(style OBJECT_STYLE) *txObjectGeom {
    g.instancePtr.data.style = int(style)
    return g
}

func (g *txObjectGeom) SetColor(color uint32) *txObjectGeom {
    g.instancePtr.data.color = color
    return g
}

func (g *txObjectGeom) SetGeomText(text string) *txObjectGeom {
    copy(g.instancePtr.data.text[:], text)
    return g
}

func (g *txObjectGeom) SetGeometry(curvePtr *txCurve) *txObjectGeom {
    if g.instancePtr.geomPtr == nil {
        g.instancePtr.geomPtr = NewTxLineCurve()
    }
    g.instancePtr.geomPtr.Clone(curvePtr)
    LineCurveToPoints5d(g.instancePtr.geomPtr, &g.instancePtr.data.geom)
    g.genMainAxis()
    return g
}

func (g *txObjectGeom) SetGeometryFromInstance(curveIns txCurve) *txObjectGeom {
    if g.instancePtr.geomPtr == nil {
        g.instancePtr.geomPtr = NewTxLineCurve()
    }
    g.instancePtr.geomPtr.Clone(&curveIns)
    LineCurveToPoints5d(g.instancePtr.geomPtr, &g.instancePtr.data.geom)
    g.genMainAxis()
    return g
}

func (g *txObjectGeom) SetGeometryFromPoints(points PointVec, ct CoordType) *txObjectGeom {
    if g.instancePtr.geomPtr == nil {
        g.instancePtr.geomPtr = NewTxLineCurve(ct)
    }
    g.instancePtr.geomPtr.SetCoordType(ct)
    g.instancePtr.geomPtr.SetCoords(points)
    LineCurveToPoints5d(g.instancePtr.geomPtr, &g.instancePtr.data.geom)
    g.genMainAxis()
    return g
}

func (g *txObjectGeom) Transfer(oldEnuC, newEnuC txPoint) *txObjectGeom {
    if g.instancePtr.geomPtr == nil || g.instancePtr.geomPtr.Empty() {
        return g
    }
    g.instancePtr.geomPtr.Transfer(oldEnuC, newEnuC)
    g.transferMainAxis(oldEnuC, newEnuC)
    return g
}

func (g *txObjectGeom) Transfer2ENU(enuCenter txPoint) *txObjectGeom {
    if g.instancePtr.geomPtr == nil || g.instancePtr.geomPtr.Empty() {
        return g
    }
    g.instancePtr.geomPtr.Transfer2ENU(enuCenter)
    g.transferMainAxis2ENU(enuCenter)
    return g
}

func (g *txObjectGeom) genMainAxis() bool {
    if g.instancePtr.data.Type != OBJECT_GEOMETRY_TYPE_Polygon || g.instancePtr.geomPtr == nil || g.instancePtr.geomPtr.Empty() {
        return false
    }
    var points PointVec
    g.instancePtr.geomPtr.GetPoints(&points)
    if len(points) < 2 {
        return false
    }
    if g.instancePtr.axisPtr != nil {
        g.instancePtr.axisPtr = nil
    }
    g.instancePtr.axisPtr = NewTxLineCurve(g.instancePtr.geomPtr.GetCoordType())
    axisPoints := points[:2]
    g.instancePtr.axisPtr.SetCoords(axisPoints)
    return true
}

func (g *txObjectGeom) transferMainAxis(oldEnuC, newEnuC txPoint) bool {
    if g.instancePtr.axisPtr == nil || g.instancePtr.axisPtr.Empty() {
        return false
    }
    return g.instancePtr.axisPtr.Transfer(oldEnuC, newEnuC)
}

func (g *txObjectGeom) transferMainAxis2ENU(enuCenter txPoint) bool {
    if g.instancePtr.axisPtr == nil || g.instancePtr.axisPtr.Empty() {
        return false
    }
    return g.instancePtr.axisPtr.Transfer2ENU(enuCenter)
}

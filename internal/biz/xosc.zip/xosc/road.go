package xosc

// 定义相关类型（这些可以是其他结构体或基础类型）
const ROAD_PKID_INVALID = -1

type txSlope struct {
    m_starts float64 // Start distance
    m_length float64 // Length of the slope segment
    m_slope  float64 // Slope value
}
type txRoadLink struct {
    Id           string
    Type         string
    ContactPoint string
}
type txControlPoint struct {
    m_type   string
    m_points []TxPoint
}
type TxOpenCrg struct {
    File        string
    Orientation string
    Mode        string
    Purpose     string
    SOffset     string
    TOffset     string
    ZOffset     string
    ZScale      string
    HOffset     string
}
type RoadT struct {
    Pkid            uint64
    TaskPkid        uint64
    ID              [32]byte
    Name            [32]byte
    Srs             uint32
    JunctionPkid    uint64
    Ground          float64
    SpeedLimit      uint32
    SectionNum      uint32
    RoadType        uint32
    Direction       uint8
    Toll            uint8
    FuncClass       uint8
    Urban           bool
    Paved           bool
    TransitionType  uint8
    LaneMark        bool
    Material        uint32
    Curvature       Point3D
    Slope           Point3D
    Heading         Point3D
    SuperElevation  Point3D
    Geom            Point3D
    Curvaturesss    CurveData
    SlopeVec        []txSlope
    PreLink         txRoadLink
    EndLink         txRoadLink
    ControlPoint    txControlPoint
    EleControlPoint txControlPoint
    Opencrg         []TxOpenCrg
}

type Point2D struct {
    X float64
    Y float64
}
type Point3D struct {
    X float64
    Y float64
    Z float64
}
type TXCenter struct {
    X   float64
    Y   float64
    Z   float64
    W   float64
    H   float64
    Hdg float64
}
type TxPoint struct {
    X   float64
    Y   float64
    Z   float64
    W   float64
    H   float64
    Hdg float64
}
type CurveData struct {
    disFromBegin []float64
    pointsYaw    []float64
    pointsNormal []Point2D
    slRefInfo    []Point3D
    center       TXCenter
}
type tx_lane_t struct {
    RoadPkid            uint64
    SectionId           uint64
    LaneId              uint64
    Name                [32]byte
    Srs                 uint32
    LeftBoundary        uint64
    RightBoundary       uint64
    LaneType            uint32
    LaneArrow           uint32
    SpeedLimit          uint32
    LaneSurface         uint32
    LaneFriction        float64
    LaneMaterialSOffset float64
    Geom                Point3D
}
type tx_laneboundary_t struct {
    Pkid           uint64
    Srs            uint32
    LaneMark       uint32
    LaneWidth      float64
    DoubleInterval float64
    DotSpace       float64
    DotOffset      float64
    DotLen         float64
    Geom           Point3D
}
type BoundaryData struct {
    Data tx_laneboundary_t
    geom CurveData
}

type LaneData struct {
    Data             tx_lane_t
    Geom             *CurveData
    LeftBoundaryPtr  *BoundaryData
    RightBoundaryPtr *BoundaryData
    DistanceToEnd    float64
    AveWidth         float64
    Valid4Driving    bool
    SectionPtr       *SectionData // Using a normal pointer instead of weak_ptr for simplicity
    GeomDense        *CurveData
}
type RoadData struct {
    Data RoadT
    Geom CurveData
}

type SectionData struct {
    Id                 uint64
    Lanes              []LaneData
    DistanceToJunction float64
    meanSlope          float64
    meanCurvature      float64
    startPercent       float64
    endPercent         float64
    roadPtr            *RoadData
}

package xosc

type HadMapHandler interface {
    GetSearchInter() Search
}
type Search interface {
    connSuccess() bool
    GetHeader() *TxOdHeader
    GetRoads() ([]*RoadData, error)
}
type txMapHandle struct {
}

func (t txMapHandle) GetSearchInter() Search {
    //TODO implement me
    panic("implement me")
}

func newHadMapHandler(dt MAP_DATA_TYPE, searchInter Search) HadMapHandler {
    return &txMapHandle{}
}

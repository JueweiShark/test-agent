package xosc

type HeaderData struct {
    Date         string
    Name         string
    East         float64
    North        float64
    South        float64
    West         float64
    RevMajor     string
    RevMinor     string
    Georeference string
    Vendor       string
}
type TxOdHeader struct {
    Date         string
    Name         string
    East         float64
    North        float64
    South        float64
    West         float64
    RevMajor     string
    RevMinor     string
    Georeference string
    Vendor       string
}
